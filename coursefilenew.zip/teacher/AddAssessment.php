<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
require "db27.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
<style>
li:hover {
  background-color: white;
}
</style>
</head>
<body>
    
<?php
require "teachmenu.php";
require "addinfosidenav27.php";
?>
  <?php
   $tid=$_SESSION["tid"];
  ?>

<div class="container">
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title">Course Outcome</h1>
					</div>

  <div class="panel-body">
                     
						
<form class="form-horizontal" method="post" action="AddAssessment_action.php" enctype="multipart/form-data">
<br>

<div class="form-group">
  <label class="col-md-4 control-label" for="classsel"> select Subject</label>
  <div class="col-md-4">
    <select id="subsel" name="subject" class="form-control" style="height:35px">
	<?php
	
    $query = "select * from subject";
    $results = mysqli_query($con,$query);

    while ($rows = mysqli_fetch_assoc(@$results)){ 
    ?>
      <option value="<?php echo $rows['subjectname'];?>"><?php echo $rows['subjectname'];?></option>
	  <?php
    } 
    ?>
    </select>
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label" for="classsel"> select CO</label>
  <div class="col-md-4">
    <select id="classsel" name="cono" class="form-control" style="height:30px" required>
      <option value="CO1">CO1</option>
      <option value="CO2">CO2</option>
      <option value="CO3">CO3</option>
      <option value="CO4">CO4</option>
      <option value="CO5">CO5</option>
      <option value="CO6">CO6</option>
      <option value="CO7">CO7</option>
      <option value="CO8">CO8</option>
      <option value="CO9">CO9</option>
      <option value="CO10">CO10</option>
    </select> 
  </div>
</div>
                                                

<div class="form-group">
<label  class="col-md-4 control-label" for="subject" style="text-align:center">Select tools</label>
 <div class="col-md-4">
<input type="checkbox" name="check_list[]" value="MSE"><label>MSE</label>
<input type="checkbox" name="check_list[]" value="ESE"><label>ESE</label>
<input type="checkbox" name="check_list[]" value="Quiz1"><label>Quiz 1</label>
<input type="checkbox" name="check_list[]" value="Quiz2"><label>Quiz 2</label>
<input type="checkbox" name="check_list[]" value="Quiz3"><label>Quiz 3</label>
<input type="checkbox" name="check_list[]" value="Quiz4"><label>Quiz 4</label>
<input type="checkbox" name="check_list[]" value="Assignment1"><label>Assignment 1</label>
<input type="checkbox" name="check_list[]" value="Assignment2"><label>Assignment 2</label>
<input type="checkbox" name="check_list[]" value="Assignment3"><label>Assignment 3</label>
<input type="checkbox" name="check_list[]" value="Assignment4"><label>Assignment 4</label>
<input type="checkbox" name="check_list[]" value="Presentation1"><label>Presentation 1</label>
<input type="checkbox" name="check_list[]" value="Presentation2"><label>Presentation 2</label>
<input type="checkbox" name="check_list[]" value="Presentation3"><label>Presentation 3</label>
<input type="checkbox" name="check_list[]" value="Presentation4"><label>Presentation 4</label>
 </div>
</div>

<div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">Class</label>

                            <div class="col-md-6">
                                <select class="form-control" id="LoginType" name="class">
                                    <option value="Fy">Fy</option>
                                    <option value="Sy">Sy</option>
                                    <option value="Ty">Ty</option>
                                </select>

                                
                                    <span class="help-block">
                                       <strong></strong>
                                    </span>
                                
                            </div>
</div>

 <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">Year</label>

                            <div class="col-md-6">
                                <select class="form-control" id="LoginType" name="year">
                                    <option value="2018">2018</option>
                                    <option value="2017">2017</option>
                                    
                                </select>

                                
                                    <span class="help-block">
                                       <strong></strong>
                                    </span>
                                
                            </div>
</div>

<br>
<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" class="btn btn-primary">Submit</button>
  </div>
</div>
</form>
      <a href="ShowAssessment.php">Show</a>
</div>  
   
</div>
</div><br><br>

   
       
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>


</body>
</html> 

