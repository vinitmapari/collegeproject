<?php
session_start();
include 'db27.php';
$uname=$_SESSION['user_id'];
$tid=$_SESSION['tid'];

$class = $_POST['classsel'];  // Storing Selected Value In Variable
$semester = $_POST['semester'];  // Storing Selected Value In Variable
//$s = $_POST['subcodesel'];  // Storing Selected Value In Variable
$subjectid=$_POST['subject'];
 $yr=$_POST['yr'];
 
 echo $class;
 echo $semester;
 echo $subjectid;
 echo $yr;
 echo $tid;
 
 if(isset($_FILES['files-input-upload']))
        {
$extension = pathinfo($_FILES["files-input-upload"]["name"], PATHINFO_EXTENSION);
		$UploadName = "$class-$yr-$semester-$subjectid.".$extension;
		$UploadTmp = $_FILES['files-input-upload']['tmp_name'];
		$UploadType = $_FILES['files-input-upload']['type'];
		$FileSize = $_FILES['files-input-upload']['size'];
		$UploadName = preg_replace("#[^a-z0-9.]#i", "", $UploadName);
		echo $UploadTmp;
                
		// Checks a File has been Selected and Uploads them into a Directory on your Server
		
		if(!$UploadTmp){
			die("No File Selected, Please Upload Again");
		}else{
                    
                    
 
                    move_uploaded_file($UploadTmp,"../Upload/$uname/$selected_val1/$yr-$selected_val1-$selected_val2-$selected_val3-$sub-$UploadName");
                    $query7 = "Insert into attendance (year,class,semester,subjectid,attendancefile,tid)values($yr,'$class','$semester',$subjectid,'/Upload/$uname/$selected_val1/$yr-$selected_val1-$selected_val2-$selected_val3-$sub-$UploadName',$tid);";
                    mysqli_query($con, $query7);
                    
                    Header('Location: attendance.php');
		}
		}
		
?>