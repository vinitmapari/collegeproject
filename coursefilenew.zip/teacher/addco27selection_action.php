<?php  
session_start();

$addsubject = $_POST['subsel'];

$_SESSION["subjectname"]=$addsubject;


header('Location: addco27.php');

 
?>  