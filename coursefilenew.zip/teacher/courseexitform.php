<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<?php
require "theader.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
<style>
li:hover {
  background-color: white;
}
</style>
</head>
<body>

<?php
require "teachmenu.php";
require "addinfosidenav27.php";
?>
  <div class="container">
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title">Course Exit Form</h1>
					</div>

  <div class="panel-body">
  
  <form class="form-horizontal" method="post" action="courseexit_action.php">
						<br>
  
  <!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="subsel">co</label>
  <div class="col-md-4">
    <select id="subsel" name="cosel" class="form-control" style="height:35px">
	<?php
	require "../db.php";
    $query = "select * from co";
    $results = mysqli_query($con,$query);

    while ($rows = mysqli_fetch_assoc(@$results)){ 
    ?>
      <option value="<?php echo $rows['idco'];?>"><?php echo $rows['cono'];?></option>
	  <?php
    } 
    ?>
    </select>
  </div>
</div>
  
    <div class="form-group">
  <label class="col-md-4 control-label" for="fives" style="text-align:center">No Of 5s</label>  
  <div class="col-md-4">
  <input id="fives" name="fives" type="text" placeholder="No Of 5s" class="form-control input-md" required>
    
  </div>
</div>

 <div class="form-group">
  <label class="col-md-4 control-label" for="threes" style="text-align:center">No Of 3s</label>  
  <div class="col-md-4">
  <input id="threes" name="threes" type="text" placeholder="No Of 3s" class="form-control input-md" required>
    
  </div>
</div>

 <div class="form-group">
  <label class="col-md-4 control-label" for="ones" style="text-align:center">No Of 1s</label>  
  <div class="col-md-4">
  <input id="ones" name="ones" type="text" placeholder="No Of 1s" class="form-control input-md" required>
    
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label" for="entries" style="text-align:center">Total No of entries</label>  
  <div class="col-md-4">
  <input id="entries" name="entries" type="text" placeholder="Total No of entries" class="form-control input-md" required>
    
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" class="btn btn-default">Submit</button><br><br>
    <a href="courseexitshow.php">Show course exit</a>
  </div>
</div><br>
</form>
						
</div>
</div><br><br>
</div>
						
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>

</body>
</html> 
