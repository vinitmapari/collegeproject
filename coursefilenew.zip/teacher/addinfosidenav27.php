<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="addco27selection.php">Add CO</a>
  <a href="addpo27selection.php">Add PO</a>
  <!--<a href="AddJustification.php">Add Justification</a>-->
  <!--<a href="selectionJustification.php">Add COPOJustification</a>
   <a href="AddAssessment.php">Add COPOAssessment</a>-->
  <a href="attainment/selection.php">Add attainment</a>
  <!--<a href="courseexitform.php"> course exit form</a>-->
  <a href="attainment/SetMseQuestionPaperSelection.php"> Add MSE question paper</a>
  <a href="attainment/SetEseQuestionPaperSelection.php"> Add ESE question paper</a>
  <!--<a href="attainment/selectionFinal.php">Add Final attainment</a>-->
</div>

<div id="main">
  <span style="font-size:20px;cursor:pointer" onclick="openNav()">&#9776;</span>