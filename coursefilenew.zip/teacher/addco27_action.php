 <?php  
session_start();
//include('db.php');
require('db27.php');

$tid=$_SESSION["tid"];
$subjectname=$_SESSION["subjectname"];


 //$t_id=mysqli_query($con,"select idteacher from  where email='$teacheremail'");
    $sql1="select * from subject where subjectname='$subjectname'";
    
    //if (mysqli_query($con, $subject_id)) {
   // output data of each row
   //$resulttid = mysqli_query($con,$t_id);
    $result1 = mysqli_query($con,$sql1);
    
   while($row1 = mysqli_fetch_assoc($result1) ) {
      
   //$tid=$rowtid['idteacher'];
   $subjectid=$row1['idsubject'];
 
   }
    //}
    //$subjectid=1;


//echo $teachername;


$codescription = $_POST['codescription'];
$cono = $_POST['cono'];
 

$sql = "INSERT INTO co (tid,subjectid,cono,description) VALUES('$tid','$subjectid','$cono','$codescription');";
if(mysqli_query($con, $sql)){  
 echo "Record inserted successfully"; ?>
<a href="addco27.php">click</a>
 <?Php
// header('Location: addco27.php');
}else{  
echo "Could not insert record: ". mysqli_error($con);  
}  
  
mysqli_close($con); 
 
 
?>  