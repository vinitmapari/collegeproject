<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
$tid=$_SESSION['tid'];
require('db27.php');
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
</head>
<body>

<?php
require "teachmenu.php";
require "addinfosidenav27.php";
?>
<div class="container">
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title">Add justification</h1>
					</div>

  <div class="panel-body">
                    
      <form class="form-horizontal" method="post" action="AddJustificationAction.php" enctype="multipart/form-data">
<br>
						<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="classsel">verb</label>
  <div class="col-md-4">
    <input type="text" name="verb">
  </div>
</div>
                                               
  
 <div class="form-group">
  <label class="col-md-4 control-label" for="subject" style="text-align:center">Justification</label>  
  <div class="col-md-4">
 <textarea  name="Justification" rows="5" cols="40"></textarea>
    
  </div>
</div>


<br>
<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" class="btn btn-default">Submit</button>
  </div>
</div>
  
</form>
  
</div>
</div><br><br>
</div>

<script>
// syllabus file upload
document.getElementById('file-button-browse').addEventListener('click', function() {
	document.getElementById('files-input-upload').click();
});

document.getElementById('files-input-upload').addEventListener('change', function() {
	document.getElementById('file-input-name').value = this.files[0].name;
	
	document.getElementById('file-button-upload').removeAttribute('disabled');
	
});
</script>


<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>


<?php
require "footer.php";
?> 
</body>
</html> 

