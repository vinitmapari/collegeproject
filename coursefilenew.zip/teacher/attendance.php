<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
</head>
<body>

<?php
require "teachmenu.php";
require "teachsidenav.php";
?>
  <div class="container">
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title">Upload Attendance Record</h1>
					</div>

  <div class="panel-body">
                    
						
			<form class="form-horizontal" method="post" action="attendance_action.php" enctype="multipart/form-data">
						<br>
						<div class="form-group">
  <label class="col-md-4 control-label" for="subcode">Year</label>  
  <div class="col-md-4">
  <input id="yr" name="yr" type="text" placeholder="" class="form-control input-md" required="">
  </div>
</div>
						<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="classsel">Class</label>
  <div class="col-md-4">
    <select id="classsel" name="classsel" class="form-control" style="height:30px" required>
      <option value="FY">FY</option>
      <option value="SY">SY</option>
      <option value="TY">TY</option>
    </select>
  </div>
</div>

<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="semester">Semester</label>
  <div class="col-md-4">
    <select id="semester" name="semester" class="form-control" style="height:30px" required>
      <option value="1">1</option>
      <option value="2">2</option>
      <option value="3">3</option>
      <option value="4">4</option>
      <option value="5">5</option>
      <option value="6">6</option>
    </select>
  </div>
</div>

  <!-- Select Basic -->
<div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Subject</label>

                            <div class="col-md-6">
                               
                                    <select name="subject" size="1" class="form-control">
                                        <?Php 
 require "db27.php";
 $query = "select * from subject";
 $results = mysqli_query($con,$query);

    while ($rows = mysqli_fetch_assoc(@$results)){ 
    ?>
                                        
      <option value="<?php echo $rows['idsubject'];?>"><?php echo $rows['subjectname'];?></option>
	 
 <?php
 
    } 
    
 ?>
                                    </select>
                              
                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>


<label class="col-md-4 control-label" for="file-button-browse">Upload</label>
<div class="input-group">
    <span class="input-group-btn">
		<button id="file-button-browse" type="button" class="btn btn-default">
			<span class="glyphicon glyphicon-file"></span>
		</button>
	</span>
	<input type="file" id="files-input-upload" name="files-input-upload" style="display:none">
	<input type="text" id="file-input-name" name="file-input-name" disabled="disabled" placeholder="File not selected" class="form-control">
	<span class="input-group-btn">
		<button type="submit" class="btn btn-default" disabled="disabled" id="file-button-upload">
			<span class="glyphicon glyphicon-upload"></span>
		</button>
	</span>
	<br>
</div>
<br>
  <?php
		require "viewpreview.php";
		?>
</form>
  
</div>
</div><br><br>
</div>

<script>
// syllabus file upload
document.getElementById('file-button-browse').addEventListener('click', function() {
	document.getElementById('files-input-upload').click();
});

document.getElementById('files-input-upload').addEventListener('change', function() {
	document.getElementById('file-input-name').value = this.files[0].name;
	
	document.getElementById('file-button-upload').removeAttribute('disabled');
});
</script>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>
<?php
require "footer.php";
?> 
</body>
</html> 
