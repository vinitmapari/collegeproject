<?php
  session_start();
  require('db27.php');
  require "theader.php";
  require "teachmenu.php";
  require "addinfosidenav27.php";
  $cono=$_POST['cono'];
  $subjectname=$_POST["subject"];  
  $class=$_POST["class"];  
  $year=$_POST["year"];  
  $tid=$_SESSION["tid"];
$_SESSION["year"]=$year;
$_SESSION["class"]=$class;
  
  
    $sql1="select * from subject where subjectname='$subjectname'";
    
    $result1 = mysqli_query($con,$sql1);
    
   while($row1 = mysqli_fetch_assoc($result1) ) {
      
   $subjectid=$row1['idsubject'];

   }      
   
$_SESSION["subjectid"]=$subjectid;

    $sql3="select * from co where subjectid=$subjectid and tid=$tid and cono='$cono'";
    
   

   $result3 = mysqli_query($con,$sql3);
    
   while($row3 = mysqli_fetch_assoc($result3)) {
      
   $coid=$row3['idco'];
   }
  
    

foreach($_POST['check_list'] as $selected){
    
"</br>";
                       
$sql6 = "INSERT INTO assessment (coid,tool,tid,class,year,subjectid) VALUES($coid,'$selected',$tid,'$class','$year',$subjectid);";
if(mysqli_query($con, $sql6)){  
 echo "Record inserted successfully";
 header('Location: AddAssessment.php');
}else{  
echo "Could not insert record: ". mysqli_error($con);  
}
 }
?>

