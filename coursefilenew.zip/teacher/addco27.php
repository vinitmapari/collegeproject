<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
</head>
<body>

<?php
require "teachmenu.php";
require "addinfosidenav27.php";
?>
  <div class="container">
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title">Add CO</h1>
		</div>

  <div class="panel-body">
                    
						
<form class="form-horizontal" name="coform" method="post" action="addco27_action.php" enctype="multipart/form-data">
<table border="0" align="center" >
  <tr>
      <td>Enter CO Description:</td>
      <td> <textarea class="form-control" Name ='codescription' id="question"  maxlength="40"></textarea></td>
        <td>
			
            <SELECT name="cono" class="form-control"  size="1">
                        <OPTION value="CO1" SELECTED>CO1</option>
			<OPTION value="CO2">CO2</option>
                        <OPTION value="CO3">CO3</option>
                        <OPTION value="CO4">CO4</option>
                        <OPTION value="CO5">CO5</option>
                        <OPTION value="CO6">CO6</option>
                        <OPTION value="CO7">CO7</option>
                        <OPTION value="CO8">CO8</option>
                        <OPTION value="CO9">CO9</option>
                        <OPTION value="CO10">CO10</option>
		</SELECT>
			
    </td>
  </tr>
  <br>
   <tr colspan="3">
   
   <td>
           <INPUT TYPE = "Submit" Name = "Sub1"  VALUE = "Save" class="btn-primary">
         
   </td>

        </tr>
 
</table>
 
    
<script>
function myFunction() {
    document.getElementById("coform").reset();
}
</script>


</form>
</div>
</div><br><br>
</div>


<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>


<?php
require "footer.php";
?> 
</body>
</html> 
