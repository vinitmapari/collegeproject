<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<?php
//require "theader.php";
require "db27.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
</head>
<?php   
   $class = $_SESSION["class"];
  $subjectname=$_SESSION["subject"];
  $year=$_SESSION["year"];
  $semno=$_SESSION["semno"];
  $tid=$_SESSION["tid"];
  $sql1="select * from subject where subjectname='$subjectname'";
   
  $result1 = mysqli_query($con,$sql1);
    
   while($row1 = mysqli_fetch_assoc($result1) ) {
      
   $subjectid=$row1['idsubject'];
   //echo $subjectid;
   }      
   $_SESSION["subjectid"]=$subjectid;
?>

<!DOCTYPE html>
  <body>
     
    <div class="container">
         <form method="POST" action="pdfconversioncorelation.php">
           <center><a href="actualcoplan27.php" class="btn btn-info" role="button">Previous</a>
                     <input type="submit" name="exportpdf" value="PDF" class="btn btn-success" />
                     <a href="selectionJustification.php" class="btn btn-info" role="button">Next</a></center>
      <div class="row">
          
        <div class="col-md-offset-1 col-md-9">

          <h3>Course Outcome - <?php echo $subjectname; ?></h3>
    <!---------------------------------------------------------------course outcome----------->
                    <table class="table table-striped">
                        <thead>             
            <tr>
              <th>CO</th>
              <th>Course Outcome</th>
              <th>Cognitive level</th>
              <th>Class Session</th>
            </tr>
                        </thead>
                        <tbody>
            <?php
            
   $f1="select * from transteacher where  subjectid='$subjectid' and semester='$semno' and year='$year' and tid='$tid'";
   
   $result81= mysqli_query($con,$f1);
    
   while($row81=mysqli_fetch_assoc($result81) )
  {
      
        $transactionteacherid1=$row81['idtransteacher'];
   
        
   //echo $transactionteacherid1;
  //////////////////////////////////////////////////////////////////////////////////////////////// 
   
   $c1 = "SELECT * FROM transcoposubject WHERE transactionteacherid='$transactionteacherid1'";
            
   $result11 = mysqli_query($con,$c1);
   
    while($row = mysqli_fetch_assoc($result11))
    {
      $cono=$row['cono'];
      $d1 = "select * from co where  subjectid='$subjectid' and cono='$cono' and tid='$tid'";
      $result2 = mysqli_query($con,$d1);
      $row22 = mysqli_fetch_assoc($result2);
      
 ?>
             <tr>
                <td><?php echo $row['cono']; ?></td>
                <td><?php echo $row22['description']; ?></td>
                <td><?php echo $row['cognitivelevel']; ?></td>
                <td><?php echo $row['class_session']; ?></td>
             </tr>
            <?Php
    }
  }
            ?>
                        </tbody>
                    </table>
    <!--------------------------------------------------------------------------------->
          <table class="table table-striped">
            <thead>
              <tr>
              <th>CO</th>
              <th>CO Desc</th>
              <th>PO</th>
              <th>Session</th>
              <th>Target</th>
            </tr>
            </thead>
            <tbody>
            <?php
            
   $f="select * from transteacher where  subjectid='$subjectid' and semester='$semno' and year='$year' and tid='$tid'";
   
   $result8= mysqli_query($con,$f);
    
   while($row8=mysqli_fetch_assoc($result8) )
  {
      
        $transactionteacherid=$row8['idtransteacher'];
   
        
   //echo $transactionteacherid;
  //////////////////////////////////////////////////////////////////////////////////////////////// 
   
   $c = "SELECT * FROM transcoposubject WHERE transactionteacherid='$transactionteacherid'";
            
   $result = mysqli_query($con,$c);
   
    while($row = mysqli_fetch_assoc($result))
    {
      $cono=$row['cono'];
      $d = "select * from co where  subjectid='$subjectid' and cono='$cono' and tid='$tid'";
      $result2 = mysqli_query($con,$d);
      $row2 = mysqli_fetch_assoc($result2);
      
            ?>
              <tr>
                <td><?php echo $row['cono']; ?></td>
                <td><?php echo $row2['description']; ?></td>
<?php
                
   $sql12="select * from transcoposubject where transactionteacherid='$transactionteacherid' and cono='$cono'";
   
   $result12 = mysqli_query($con,$sql12);
    
   while($row12 = mysqli_fetch_assoc($result12) )
   {   
        $idcoposubject=$row12['idcoposubject'];
        //echo $idcoposubject;
   }      
   
   $e = "SELECT * FROM idaddpotoco WHERE idcoposubject='$idcoposubject'";
   $result3 = mysqli_query($con,$e);
   ?>
                <td>
   <?Php
   while($row3 = mysqli_fetch_assoc($result3))
   {
 ?>
                <?php echo $row3['pono']; ?>
                <?php 
    }
                ?>
                    </td>
                <td><?php echo $row['class_session']; ?></td>
                <td><?php echo $row['target']; ?></td>
              </tr>
            <?php
              }
            }
            ?>
            </tbody>
      </table>
    
    
 </div>
      
      <!--/////////////////////////correlation matrix///////////////////////////////////////////////////-->
      
      <div class="row">
        <div class="">
         
            
            <table class="table table-striped">
                <?Php
                 $po1[]="";$po2[]=""; $po4[]=""; $po5[]=""; $po6[]=""; $po7[]=""; $po8[]=""; $po9[]=""; $po10[]="";
                  $po11[]=""; $po12[]="";
                // $po2=array();
                ?>
             <thead>   
              <tr>
                <th>Course Outcome</th>
                <?php
                  for($i=1;$i<13;$i++)
                  {
                    if($i<10)
                      echo "<th>P0".$i."</th>";
                    else
                      echo "<th>P".$i."</th>";
                  }
                ?>
              </tr>
             </thead>
              <?php
              $po = new SplFixedArray(13);
              $f="select * from transteacher where  subjectid='$subjectid' and semester='$semno' and year='$year' and tid='$tid'";
   
              $result8= mysqli_query($con,$f);
    
   while($row8=mysqli_fetch_assoc($result8))
  {
      
        $transactionteacherid=$row8['idtransteacher'];
        //echo $transactionteacherid;
  //echo "hello";
   $c = "SELECT * FROM transcoposubject WHERE transactionteacherid='$transactionteacherid'";
            
   $res = mysqli_query($con,$c);
   
   while($row22 = mysqli_fetch_array($res))
   {
       $cono1=$row22['cono'];
      //echo $cono1;  
       //echo $transactionteacherid;
        echo "<tr>";
       echo "<td>".$cono1."</td>";
       
  $sql12="select * from transcoposubject where transactionteacherid='$transactionteacherid' and cono='$cono1'";
   
  $result12 = mysqli_query($con,$sql12);
    
            while($row12 = mysqli_fetch_assoc($result12) )
            {   
                        $idcoposubject=$row12['idcoposubject'];
                        //echo $idcoposubject;
         
            }
            //echo $idcoposubject;
            //echo"hi";
            
            
          $e = "SELECT * FROM idaddpotoco WHERE idcoposubject='$idcoposubject'";
          $result22 = mysqli_query($con,$e);
                 $i=1; 
                  // echo "<td></td>";
              while($row4 = mysqli_fetch_assoc($result22))
              {
                  $po[$i] = substr($row4['pono'],2);
                  //echo $po[$i];
                  $i++;
              }
            
                 //echo "POs";
                for($i=1;$i<13;$i++)
                { 
                    
                 //echo $po[$i];
                }
                 if($po!=NULL)
                 {
                     //echo "Hi";
                   // $a=array('$c'=>0,'$i'=>0);
                    //$c=0;
                   
                 for($i=1;$i<13;$i++)
                      {
                               //echo $i;
                       ?>
              <td>
              <?Php
                        for($j=1;$j< sizeof($po);$j++)
                        {
                      
                            //echo $po[$j];
                            //echo $i;
                           
                            if($i==$po[$j])
                            {
                               
                               echo $row22['class_session'];
                               //echo substr("po1",2);
                       if($i== substr("po1",2))
                       {
                            //$po1="";
                           //echo "hi1";
                           @$po1[$i]+=$row22['class_session'];
                          // echo $po1;
                       }
                       else if($i== substr("po2",2))
                       {
                            @$po2[$i]+=$row22['class_session'];
                           //echo "hi1";
                           //$po2= array_sum($po2);
                          // echo $po1;
                       }
                       else if($i== substr("po3",2))
                       {
                            //$po3="";
                           //echo "hi1";
                           @$po3[$i]=$po3+$row22['class_session'];
                          // echo $po1;`
                       }
                       else if($i== substr("po4",2))
                       {
                            //$po4="";
                           //echo "hi1";
                           @$po4[$i]+=$row22['class_session'];
                          // echo $po1;
                       }
                       else if($i== substr("po5",2))
                       {
                            //$po5="";
                           //echo "hi1";
                           @$po5[$i]+=$row22['class_session'];
                          // echo $po1;
                       }
                       else if($i== substr("po6",2))
                       {
                            //$po6="";
                           //echo "hi1";
                           @$po6[$i]+=$row22['class_session'];
                          // echo $po1;
                       }
                       else if($i== substr("po7",2))
                       {
                            //$po7=0;
                           //echo "hi1";
                           @$po7[$i]+=$row22['class_session'];
                          // echo $po1;
                       }
                       if($i== substr("po8",2))
                       {
                            //$po8="";
                           //echo "hi1";
                           @$po8[$i]+=$row22['class_session'];
                          // echo $po1;
                       }
                       if($i== substr("po9",2))
                       {
                            //$po9="";
                           //echo "hi1";
                           @$po9[$i]+=$row22['class_session'];
                          // echo $po1;
                       }
                       if($i== substr("po10",2))
                       {
                            //$po10="";
                           //echo "hi1";
                           @$po10[$i]+=$row22['class_session'];
                          // echo $po1;
                       }
                       if($i== substr("po11",2))
                       {
                            //$po11="";
                           //echo "hi1";
                           @$po11[$i]+=$row22['class_session'];
                          // echo $po1;
                       }
                       if($i== substr("po12",2))
                       {
                            //$po12="";
                           //echo "hi1";
                           @$po12[$i]+=$row22['class_session'];
                          // echo $po1;
                       }
                  //break;
                            }
                            else
                            {
                                echo " ";
                                
                            }
                           
                      }
                      ?>
              </td>
                  <?Php
                  }
                 }
                      else
                      {
                            //echo "<td></td>";
                             
                      }
                       
           
              
                echo "</tr>";
               
               } 
           
  }
  
              ?>
              <tr>
                  <td>PO Tot. session</td>
                  <td><?Php  echo array_sum($po1); ?></td>
                   <td><?Php  echo array_sum($po2); ?></td>
                    <td><?Php  echo array_sum($po3); ?></td>
                     <td><?Php  echo array_sum($po4); ?></td>
                      <td><?Php  echo array_sum($po5); ?></td>
                     <td><?Php  echo array_sum($po6); ?></td>
                      <td><?Php  echo array_sum($po7); ?></td>
                       <td><?Php  echo array_sum($po8); ?></td>
                        <td><?Php  echo array_sum($po9); ?></td>
                         <td><?Php  echo array_sum($po10); ?></td>
                          <td><?Php  echo array_sum($po11); ?></td>
                           <td><?Php  echo array_sum($po12); ?></td>
              </tr>
               <tr>
                  <td>Level</td>
              <?Php
              $sql = "SELECT * from cognitive where year='$year' and class='".$class."' and semester='$semno' and subjectid='$subjectid'";
              $result = mysqli_query($con,$sql);
   
 while($row = mysqli_fetch_assoc($result))
 {
     $session=$row["session"];
 }
 
if($session==48)
{
   
    if(array_sum($po1)>=19)
    {
        $a1=3;
    }
  else if(array_sum($po1)>=12 && array_sum($po1)<19)
  {
       $a1=2;
  }   
    else if(array_sum($po1)<12)
  {
       $a1=1;
  } 
  ////////////////////////////
    if(array_sum($po2)>=19)
    {
        $a2=3;
    }
  else if(array_sum($po2)>=12 && array_sum($po2)<19)
  {
       $a2=2;
  }   
    else if(array_sum($po2)<12)
  {
       $a2=1;
  } 
////////////////////////////////////////////  
  if(array_sum($po3)>=19)
    {
        $a3=3;
    }
  else if(array_sum($po3)>=12 && array_sum($po3)<19)
  {
       $a3=2;
  }   
    else if(array_sum($po3)<12)
  {
       $a3=1;
  }   
  ///////////////////////////////////////
    if(array_sum($po4)>=19)
    {
        $a4=3;
    }
  else if(array_sum($po4)>=12 && array_sum($po4)<19)
  {
       $a4=2;
  }   
    else if(array_sum($po4)<12)
  {
       $a4=1;
  }   
  /////////////////////////////////////
    if(array_sum($po5)>=19)
    {
        $a5=3;
    }
  else if(array_sum($po5)>=12 && array_sum($po5)<19)
  {
       $a5=2;
  }   
    else if(array_sum($po5)<12)
  {
       $a5=1;
  }   
  ///////////////////////////////////////////////
    if(array_sum($po6)>=19)
    {
        $a6=3;
    }
  else if(array_sum($po6)>=12 && array_sum($po6)<19)
  {
       $a6=2;
  }   
    else if(array_sum($po6)<12)
  {
       $a6=1;
  }   
  ////////////////////////////////////////////
    if(array_sum($po7)>=19)
    {
        $a7=3;
    }
  else if(array_sum($po7)>=12 && array_sum($po7)<19)
  {
       $a7=2;
  }   
    else if(array_sum($po7)<12)
  {
       $a7=1;
  }   
  /////////////////////////////////////////////
  if(array_sum($po8)>=19)
    {
        $a8=3;
    }
  else if(array_sum($po8)>=12 && array_sum($po8)<19)
  {
       $a8=2;
  }   
    else if(array_sum($po8)<12)
  {
       $a8=1;
  }
  /////////////////////////////////////////////////////////////////////////
  if(array_sum($po9)>=19)
    {
        $a9=3;
    }
  else if(array_sum($po9)>=12 && array_sum($po9)<19)
  {
       $a9=2;
  }   
    else if(array_sum($po9)<12)
  {
       $a9=1;
  }
  ////////////////////////////////////////////////////////////////////////
  if(array_sum($po10)>=19)
    {
        $a10=3;
    }
  else if(array_sum($po10)>=12 && array_sum($po10)<19)
  {
       $a10=2;
  }   
    else if(array_sum($po10)<12)
  {
       $a10=1;
  }
  ////////////////////////////////////////////////////////////////////////
  if(array_sum($po11)>=19)
    {
        $a11=3;
    }
  else if(array_sum($po11)>=12 && array_sum($po11)<19)
  {
       $a11=2;
  }   
    else if(array_sum($po11)<12)
  {
       $a11=1;
  }
  ////////////////////////////////////////////////////////////////////////
  if(array_sum($po12)>=19)
    {
        $a12=3;
    }
  else if(array_sum($po12)>=12 && array_sum($po12)<19)
  {
       $a12=2;
  }   
    else if(array_sum($po12)<12)
  {
       $a12=1;
  }
  ////////////////////////////////////////////////////////////////////////
}
else if($session==42)
{
   
    if(array_sum($po1)>=17)
    {
        $a1=3;
    }
  else if(array_sum($po1)>=11 && array_sum($po1)<17)
  {
       $a1=2;
  }   
    else if(array_sum($po1)<11)
  {
       $a1=1;
  } 
  ////////////////////////////
    if(array_sum($po2)>=17)
    {
        $a2=3;
    }
  else if(array_sum($po2)>=11 && array_sum($po2)<17)
  {
       $a2=2;
  }   
    else if(array_sum($po2)<11)
  {
       $a2=1;
  } 
////////////////////////////////////////////  
  if(array_sum($po3)>=17)
    {
        $a3=3;
    }
  else if(array_sum($po3)>=11 && array_sum($po3)<17)
  {
       $a3=2;
  }   
    else if(array_sum($po3)<11)
  {
       $a3=1;
  }   
  ///////////////////////////////////////
    if(array_sum($po4)>=17)
    {
        $a4=3;
    }
  else if(array_sum($po4)>=11 && array_sum($po4)<17)
  {
       $a4=2;
  }   
    else if(array_sum($po4)<11)
  {
       $a4=1;
  }   
  /////////////////////////////////////
    if(array_sum($po5)>=17)
    {
        $a5=3;
    }
  else if(array_sum($po5)>=11 && array_sum($po5)<17)
  {
       $a5=2;
  }   
    else if(array_sum($po5)<11)
  {
       $a5=1;
  }   
  ///////////////////////////////////////////////
    if(array_sum($po6)>=17)
    {
        $a6=3;
    }
  else if(array_sum($po6)>=11 && array_sum($po6)<17)
  {
       $a6=2;
  }   
    else if(array_sum($po6)<11)
  {
       $a6=1;
  }   
  ////////////////////////////////////////////
    if(array_sum($po7)>=17)
    {
        $a7=3;
    }
  else if(array_sum($po7)>=11 && array_sum($po7)<17)
  {
       $a7=2;
  }   
    else if(array_sum($po7)<11)
  {
       $a7=1;
  }   
  /////////////////////////////////////////////
  if(array_sum($po8)>=17)
    {
        $a8=3;
    }
  else if(array_sum($po8)>=11 && array_sum($po8)<17)
  {
       $a8=2;
  }   
    else if(array_sum($po8)<11)
  {
       $a8=1;
  }
  /////////////////////////////////////////////////////////////////////////
  if(array_sum($po9)>=17)
    {
        $a9=3;
    }
  else if(array_sum($po9)>=11 && array_sum($po9)<17)
  {
       $a9=2;
  }   
    else if(array_sum($po9)<11)
  {
       $a9=1;
  }
  ////////////////////////////////////////////////////////////////////////
  if(array_sum($po10)>=17)
    {
        $a10=3;
    }
  else if(array_sum($po10)>=11 && array_sum($po10)<17)
  {
       $a10=2;
  }   
    else if(array_sum($po10)<11)
  {
       $a10=1;
  }
  ////////////////////////////////////////////////////////////////////////
  if(array_sum($po11)>=17)
    {
        $a11=3;
    }
  else if(array_sum($po11)>=11 && array_sum($po11)<17)
  {
       $a11=2;
  }   
    else if(array_sum($po11)<11)
  {
       $a11=1;
  }
  ////////////////////////////////////////////////////////////////////////
  if(array_sum($po12)>=17)
    {
        $a12=3;
    }
  else if(array_sum($po12)>=11 && array_sum($po12)<17)
  {
       $a12=2;
  }   
    else if(array_sum($po12)<11)
  {
       $a12=1;
  }
  ////////////////////////////////////////////////////////////////////////
}
else if($session==39)
{
   
    if(array_sum($po1)>=16)
    {
        $a1=3;
    }
  else if(array_sum($po1)>=10 && array_sum($po1)<16)
  {
       $a1=2;
  }   
    else if(array_sum($po1)<10)
  {
       $a1=1;
  } 
  ////////////////////////////
    if(array_sum($po2)>=16)
    {
        $a2=3;
    }
  else if(array_sum($po2)>=10 && array_sum($po2)<16)
  {
       $a2=2;
  }   
    else if(array_sum($po2)<10)
  {
       $a2=1;
  } 
////////////////////////////////////////////  
  if(array_sum($po3)>=16)
    {
        $a3=3;
    }
  else if(array_sum($po3)>=10 && array_sum($po3)<16)
  {
       $a3=2;
  }   
    else if(array_sum($po3)<10)
  {
       $a3=1;
  }   
  ///////////////////////////////////////
    if(array_sum($po4)>=16)
    {
        $a4=3;
    }
  else if(array_sum($po4)>=10 && array_sum($po4)<16)
  {
       $a4=2;
  }   
    else if(array_sum($po4)<10)
  {
       $a4=1;
  }   
  /////////////////////////////////////
    if(array_sum($po5)>=16)
    {
        $a5=3;
    }
  else if(array_sum($po5)>=10 && array_sum($po5)<16)
  {
       $a5=2;
  }   
    else if(array_sum($po5)<10)
  {
       $a5=1;
  }   
  ///////////////////////////////////////////////
    if(array_sum($po6)>=16)
    {
        $a6=3;
    }
  else if(array_sum($po6)>=10 && array_sum($po6)<16)
  {
       $a6=2;
  }   
    else if(array_sum($po6)<10)
  {
       $a6=1;
  }   
  ////////////////////////////////////////////
    if(array_sum($po7)>=16)
    {
        $a7=3;
    }
  else if(array_sum($po7)>=10 && array_sum($po7)<16)
  {
       $a7=2;
  }   
    else if(array_sum($po7)<10)
  {
       $a7=1;
  }   
  /////////////////////////////////////////////
  if(array_sum($po8)>=16)
    {
        $a8=3;
    }
  else if(array_sum($po8)>=10 && array_sum($po8)<16)
  {
       $a8=2;
  }   
    else if(array_sum($po8)<10)
  {
       $a8=1;
  }
  /////////////////////////////////////////////////////////////////////////
  if(array_sum($po9)>=16)
    {
        $a9=3;
    }
  else if(array_sum($po9)>=10 && array_sum($po9)<16)
  {
       $a9=2;
  }   
    else if(array_sum($po9)<10)
  {
       $a9=1;
  }
  ////////////////////////////////////////////////////////////////////////
  if(array_sum($po10)>=16)
    {
        $a10=3;
    }
  else if(array_sum($po10)>=10 && array_sum($po10)<16)
  {
       $a10=2;
  }   
    else if(array_sum($po10)<10)
  {
       $a10=1;
  }
  ////////////////////////////////////////////////////////////////////////
  if(array_sum($po11)>=16)
    {
        $a11=3;
    }
  else if(array_sum($po11)>=10 && array_sum($po11)<16)
  {
       $a11=2;
  }   
    else if(array_sum($po11)<10)
  {
       $a11=1;
  }
  ////////////////////////////////////////////////////////////////////////
  if(array_sum($po12)>=16)
    {
        $a12=3;
    }
  else if(array_sum($po12)>=10 && array_sum($po12)<16)
  {
       $a12=2;
  }   
    else if(array_sum($po12)<10)
  {
       $a12=1;
  }
  ////////////////////////////////////////////////////////////////////////
}



              ?>
                <td><?Php echo $a1; ?></td>  
                <td><?Php echo $a2; ?></td>
                <td><?Php echo $a3; ?></td>
                <td><?Php echo $a4; ?></td>
                <td><?Php echo $a5; ?></td>
                <td><?Php echo $a6; ?></td>
                <td><?Php echo $a7; ?></td>
                <td><?Php echo $a8; ?></td>
                <td><?Php echo $a9; ?></td>
                <td><?Php echo $a10; ?></td>
                <td><?Php echo $a11; ?></td>
                <td><?Php echo $a12; ?></td>
              </tr>
            </table>
          <?Php
          
           
            
          ?>
        </div>
      </div>
      </div>
             
      </form>
    </div>
              
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>

<br><br>

</body>
</html> 

