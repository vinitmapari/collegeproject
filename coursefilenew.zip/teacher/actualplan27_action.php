<?php
  session_start();
  require('db27.php');
  $cono=$_POST['cono'];
  $cognitivelevel=$_POST['Cognitivelevel'];
  $classsession=$_POST['classsession'];
  $target=$_POST['target'];
  
  $class = $_SESSION["class"];
  $subjectname=$_SESSION["subject"];
  $year=$_SESSION["year"];
  $semno=$_SESSION["semno"];
    
  $tid=$_SESSION["tid"];
//$subjectname=$_SESSION["subjectname"];

 //$t_id=mysqli_query($con,"select idteacher from  where email='$teacheremail'");
    $sql1="select * from subject where subjectname='$subjectname'";
    
    //if (mysqli_query($con, $subject_id)) {
   // output data of each row
   //$resulttid = mysqli_query($con,$t_id);
    $result1 = mysqli_query($con,$sql1);
    
   while($row1 = mysqli_fetch_assoc($result1) ) {
      
   //$tid=$rowtid['idteacher'];
   $subjectid=$row1['idsubject'];
 
   }      
   
   
$sql2 = "INSERT INTO transteacher (year,semester,subjectid,tid) VALUES('$year','$semno','$subjectid','$tid');";
if(mysqli_query($con, $sql2)){  
 
 //header('Location: assignment.php');
}else{  
mysqli_error($con);  
}  
//trasactionteacherid

    $sql3="select * from transteacher where subjectid='$subjectid' and tid='$tid'";
    
    if (mysqli_query($con,$sql3)) {
   // output data of each row
   $result3 = mysqli_query($con,$sql3);
    
   while($row3 = mysqli_fetch_assoc($result3)) {
      
   $transactionteacherid=$row3['idtransteacher'];
   }
    }
   
//trasactionteacherid
$sql4 = "INSERT INTO  transcoposubject  (cognitivelevel,class_session,target,cono,transactionteacherid) VALUES('$cognitivelevel','$classsession','$target','$cono','$transactionteacherid');";
if(mysqli_query($con,$sql4)){  
 echo "Record inserted successfully";
 //header('Location: assignment.php');
}else{  
 mysqli_error($con);  
}
//idcoposubject
 $sql5="select * from transcoposubject where transactionteacherid='$transactionteacherid'";
    
    if (mysqli_query($con, $sql5)) {
   // output data of each row
   $result5 = mysqli_query($con,$sql5);
    
    
   while($row5 = mysqli_fetch_assoc($result5)) {
      
 
   $idcoposubject=$row5['idcoposubject']; 
   }
    }
    
 //idcoposubject
foreach($_POST['check_list'] as $selected){
    
   "</br>";
                       
$sql6 = "INSERT INTO idaddpotoco (idcoposubject,pono) VALUES($idcoposubject,'$selected');";
if(mysqli_query($con, $sql6)){  

 header('Location: actualcoplan27.php');
}else{  
 mysqli_error($con);  
}
 }
?>

