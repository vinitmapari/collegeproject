<?php
session_start();
require "../db.php";
    $class = $_SESSION["class"];
    $subjectname=$_SESSION["subject"];
    $year=$_SESSION["year"];
    $semno=$_SESSION["semno"];
   $tid=$_SESSION["tid"];

   /*echo $class;
   echo $subjectname;
   echo $year;
   echo $semno;
   echo $tid;*/
   
   $sql2="select * from subject where subjectname='$subjectname'";
$result2 = mysqli_query($con,$sql2);
while($row2 = mysqli_fetch_assoc($result2) ) {
   $subjectid=$row2['idsubject'];
}
           
           ?>
<!DOCTYPE html>
<html lang="en">
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Course Exit Surveys ( Indirect Method)</h2>
          
  <table class="table table-hover">
    <thead>
      <tr>
        <th>CO</th>
        <th>No of 5s</th>
        <th>No of 3s</th>
        <th>No of 1s</th>
        <th>Average</th>
      </tr>
    </thead>   
    <tbody>
<?php
$sql4="select * from courseexitsurvey where class='$class' and year='$year' and semester='$semno' and tid=$tid ";
$result4 = mysqli_query($con,$sql4);
while($row4 = mysqli_fetch_assoc($result4) ) {
      
   $cono=$row4['cono'];
   $NoOf5=$row4['NoOf5'];
   $NoOf3=$row4['NoOf3'];
   $NoOf1=$row4['NoOf1'];
   $average=$row4['average'];
   
$sql5="select * from co where tid=$tid and subjectid=$subjectid and idco=$cono";
$result5 = mysqli_query($con,$sql5);
while($row5 = mysqli_fetch_assoc($result5) ) {
   $coname=$row5['cono'];
}
?>
      <tr>
        <td><?Php echo $coname; ?></td>
        <td><?Php echo $NoOf5; ?></td>
        <td><?Php echo $NoOf3 ?></td>
        <td><?Php echo $NoOf1 ?></td>
        <td><?Php echo $average; ?></td>
      </tr>
<?php
}
?>      
    </tbody>
  </table>
  
  <center><a href="courseexitform.php" class="btn btn-info" role="button">Previous</a>
                     <input type="submit" name="exportpdf" value="PDF" class="btn btn-success" />
                     <a href="addinfo27.php" class="btn btn-info" role="button">Finish</a></center>
</div>

</body>
</html>
