<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
<style>
li:hover {
  background-color: white;
}
</style>

</head>
<body>

<?php
require "teachmenu.php";
require "addinfosidenav27.php";
?>
<div class="container">
  <div class="panel panel-default">
                <div class="panel-heading">
                    <h3><b>Instructions</b></h3>
                    
		</div>

  <div class="panel-body">
            <h4>Please read the instructions carefully before proceed</h4>
            <h5>1. please insert the details properly before proceding further</h5>
                    <h5>2. before creating obe you have to fill co,po,attainment etc</h5>
                    <h5>3.while uploading file dont change the file convension</h5>
                    <h5>4.please upload only the excel file</h5>
            <center><a href="obeselection27.php"><button type="button" class="btn btn-primary">Create OBE</button></a></center>          
   
</div>
</div><br><br>
</div>

<script>
// syllabus file upload
document.getElementById('file-button-browse').addEventListener('click', function() {
	document.getElementById('files-input-upload').click();
});

document.getElementById('files-input-upload').addEventListener('change', function() {
	document.getElementById('file-input-name').value = this.files[0].name;
	
	document.getElementById('file-button-upload').removeAttribute('disabled');
	
});
</script>


<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>

</body>
</html> 
