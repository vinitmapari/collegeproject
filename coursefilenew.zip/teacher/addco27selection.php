<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
</head>
<body>

<?php
require "teachmenu.php";
require "addinfosidenav27.php";
?>
  <div class="container">
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title">Add PO</h1>  
		</div>

  <div class="panel-body">
                    
						
      <form class="form-horizontal" method="post" action="addco27selection_action.php" enctype="multipart/form-data">
<table border="0" align="center" >
    <tr>
      <td>Add subject:</td>
        <td>
        <div style="float:right;">
		<select id="subsel" name="subsel" class="form-control" style="height:35px">
	<?php
	require "../db.php";
    $query = "select * from subject";
    $results = mysqli_query($con,$query);

    while ($rows = mysqli_fetch_assoc(@$results)){ 
    ?>
      <option value="<?php echo $rows['subjectname'];?>"><?php echo $rows['subjectname'];?></option>
	  <?php
    } 
    ?>
    </select>
			
    </td>
  </tr>
  <br>
   <tr>
  
   <td colspan="2">
           <INPUT TYPE = "Submit" Name = "Sub1"  VALUE = "Next" class="btn-primary">
           
   </td>

        </tr>
 
</table>
 
    
            <script>
function myFunction() {
    document.getElementById("myForm").reset();
}
</script>


</form>
</div>
</div><br><br>
</div>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>


<?php
require "footer.php";
?> 
</body>
</html> 
