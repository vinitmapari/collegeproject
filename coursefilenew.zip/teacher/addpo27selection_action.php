<?php  
session_start();

$addsubject = $_POST['subsel'];

$_SESSION["subjectname"]=$addsubject;


 header('Location: addpo27.php');

 
?>  