<?php
session_start();
require('db27.php');
$tid=$_SESSION['tid'];
$verb=$_POST['verb'];
$justification=$_POST['Justification'];
	

$sql="Insert into justification(verb,justification,tid)values('$verb','$justification','$tid')";

if(mysqli_query($con,$sql))
{
         Header('Location: AddJustification.php');        
}
	
?>