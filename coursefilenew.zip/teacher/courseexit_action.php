<?php
session_start();
$user=$_SESSION['tid'];
require "../db.php";

	if(isset($_POST['cosel']))
{
    $class = $_SESSION["class"];
    $subjectname=$_SESSION["subject"];
    $year=$_SESSION["year"];
    $semno=$_SESSION["semno"];
   $tid=$_SESSION["tid"];
   
$cono=$_POST['cosel'];
$NoOf5=$_POST['fives'];
$NoOf3=$_POST['threes'];
$NoOf1=$_POST['ones'];
$entries=$_POST['entries'];
$a=5;
$b=3;
$c=1;
$d=100;

$average=((($NoOf5 * $a+ $NoOf3 * $b + $NoOf1 * $c ) / $entries)/ $a)* $d;

echo $average;
$query="insert into courseexitsurvey(cono,NoOf5,NoOf3,NoOf1,average,class,year,semester,tid)values($cono,$NoOf5,$NoOf3,$NoOf1,$average,'$class','$year','$semno',$tid)";
mysqli_query($con,$query);
}
else
{
	echo "Could not insert";
}
Header('location:courseexitform.php');


?>
