<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<?php
//require "theader.php";
require "db27.php";
?>

<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
<style>
li:hover {
  background-color: white;
}
</style>

</head>
<body>
  <form method="post" action="pdfconversion.php">    
<?php
//require "teachmenu.php";
//require "addobesidenav27.php";
?>
  <?php
    $class = $_SESSION["class"];
    $subjectname=$_SESSION["subject"];
    $year=$_SESSION["year"];
    $semno=$_SESSION["semno"];
    
   $tid=$_SESSION["tid"];
//$subjectname=$_SESSION["subjectname"];
//echo $tid;
//echo $subjectname;
//echo $semno;
//echo $year;
 //$t_id=mysqli_query($con,"select idteacher from  where email='$teacheremail'");
    $sql1="select * from subject where subjectname='$subjectname'";
    
    //if (mysqli_query($con, $subject_id)) {
   // output data of each row
   //$resulttid = mysqli_query($con,$t_id);
    $result1 = mysqli_query($con,$sql1);
    
   while($row1 = mysqli_fetch_assoc($result1) ) {
      
   //$tid=$rowtid['idteacher'];
   $subjectid=$row1['idsubject'];
   //echo $subjectid;
   }
   $_SESSION["subjectid"]=$subjectid;
  ?>
      <center> <h3><b>Phase I - Planning</b></h3></center>  
<center>
    <div class="tableborder" style="padding: 2px;">
    <table class="table table-hover" style="padding: 2px;">
       
 <tbody>
 <?Php

  $sql = "SELECT * from cognitive where year='$year' and class='".$class."' and semester='$semno' and subjectid='$subjectid'";
  $sql1 = "SELECT * from subject where semester='$semno' and idsubject='$subjectid'";
  //if (mysqli_query($con, $sql) && mysqli_query($con, $sql1)) {
   // output data of each row
   $result = mysqli_query($con,$sql);
   
 while($row = mysqli_fetch_assoc($result))
 {
     $session=$row["session"];
     $semseter=$row["semester"];
     $credit=$row["credit"];
     $L=$row["L"];
     $T=$row["T"];
     $P=$row["P"];
 }

  $result1 = mysqli_query($con,$sql1);
 while($row1 = mysqli_fetch_assoc($result1))
 {
     $coursename=$row1["subjectname"];
     $coursecode=$row1["subjectcode"];
 }
 ?>
   <tr>
       <td><b>COURSE NAME</b></td>
       <td><?Php echo $coursename; ?></td>
   </tr>
   <tr>
       <td><b>COURSE CODE</b></td>
       <td><?Php echo $coursecode ?></td>
   </tr>
   <tr>
       <td><b>SESSIONS OF COURSE</b></td>
       <td><?Php echo $session ?></td>
   </tr>
   <tr>
       <td><b>SEMESTER</b></td>
       <td><?Php echo $semseter ?></td>
   </tr>
   <tr>
       <td><b>CREDITS</b></td>
       <td><?Php echo $credit ?></td>
   </tr>
   <tr>
       <td><b>L : T : P</b></td>
       <td><?Php echo $L .":".$T .":". $P ?></td>
   </tr>
<?Php
//} 
?>

        </tbody>
        
</table>
    </div>
                    <a href="obeselection27.php" class="btn btn-info" role="button">Previous</a>
                     <input type="submit" name="exportpdf" value="PDF" class="btn btn-success" />
                     <a href="actualcoplan27.php" class="btn btn-info" role="button">Next</a>
                  
 </form>
</center>		

    
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>

</body>
</html> 
