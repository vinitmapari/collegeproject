<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
require "db27.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
<style>
li:hover {
  background-color: white;
}
</style>
</head>
<body>
    
<?php
require "teachmenu.php";
//require "addobesidenav27.php";
?>
  <?php
   $tid=$_SESSION["tid"];
$subjectname=$_SESSION["subject"];
//echo $tid;
//echo $subjectname;
 //$t_id=mysqli_query($con,"select idteacher from  where email='$teacheremail'");
    $sql1="select * from subject where subjectname='$subjectname'";
    
    //if (mysqli_query($con, $subject_id)) {
   // output data of each row
   //$resulttid = mysqli_query($con,$t_id);
    $result1 = mysqli_query($con,$sql1);
    
   while($row1 = mysqli_fetch_assoc($result1) ) {
      
   //$tid=$rowtid['idteacher'];
   $subjectid=$row1['idsubject'];
   //echo $subjectid;
   }
  ?>

   <div class="container">
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title">Course Outcome</h1>
					</div>

  <div class="panel-body">
                    
						
      <form class="form-horizontal" method="post" action="actualplan27_action.php" enctype="multipart/form-data">
<br>
						<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="classsel"> select CO</label>
  <div class="col-md-4">
    <select id="classsel" name="cono" class="form-control" style="height:30px" required>
      <option value="CO1">CO1</option>
      <option value="CO2">CO2</option>
      <option value="CO3">CO3</option>
      <option value="CO4">CO4</option>
      <option value="CO5">CO5</option>
      <option value="CO6">CO6</option>
      <option value="CO7">CO7</option>
      <option value="CO8">CO8</option>
      <option value="CO9">CO9</option>
      <option value="CO10">CO10</option>
    </select> 
  </div>
</div>
                                                
<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="semester">Cognitive level</label>
  <div class="col-md-4">
    <select id="Cognitive_level" name="Cognitivelevel" class="form-control" style="height:30px" required>
      <option value="Applying">Applying</option>
      <option value="Analyzing">Analyzing</option>
      <option value="Creating">Creating</option>
      <option value="Design">Design</option>
      <option value="Develop">Develop</option>
    </select>
  </div>
</div>

  <!-- Select Basic -->
  
  <div class="form-group">
  <label class="col-md-4 control-label" for="subject" style="text-align:center">Class Session</label>  
  <div class="col-md-4">
  <input id="session" name="classsession" type="text" placeholder="class_session" class="form-control input-md" required>
    
  </div>
</div>

 <div class="form-group">
  <label class="col-md-4 control-label" for="subject" style="text-align:center">Target</label>  
  <div class="col-md-4">
  <input id="session" name="target" type="text" placeholder="Target" class="form-control input-md" required>
    
  </div>
</div>

<div class="form-group">
<label  class="col-md-4 control-label" for="subject" style="text-align:center">Select POS</label>
<input type="checkbox" name="check_list[]" value="PO1"><label>PO1</label>
<input type="checkbox" name="check_list[]" value="PO2"><label>PO2</label>
<input type="checkbox" name="check_list[]" value="PO3"><label>PO3</label>
<input type="checkbox" name="check_list[]" value="PO4"><label>PO4</label>
<input type="checkbox" name="check_list[]" value="PO5"><label>PO5</label>
<input type="checkbox" name="check_list[]" value="PO6"><label>PO6</label>
<input type="checkbox" name="check_list[]" value="PO7"><label>PO7</label>
<input type="checkbox" name="check_list[]" value="PO8"><label>PO8</label>
<input type="checkbox" name="check_list[]" value="PO9"><label>PO9</label>
<input type="checkbox" name="check_list[]" value="PO10"><label>PO10</label>
<br>
<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" class="btn btn-primary">Submit</button>
  </div>
</div>
</div>  
</form>
   <a href="copocorrleation27.php">correlation</a>
</div>
</div><br><br>
</div>
   
       
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>

</body>
</html> 

