<?php
 //session_start();
$conn = mysqli_connect("localhost", "root", "", "mca");
  // Check connection
  if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
  } 
  
$email=$_SESSION["email"];
$year=$_SESSION["year"];
$class=$_SESSION["class"];
$semno=$_SESSION["semno"];
$assignment_no=$_SESSION["assignment_no"];
$subject=$_SESSION["subject"];
?>
<center>
    <div class="tableborder" style="padding: 2px;">
    <table class="table" style="padding: 2px;">
        <thead>
        <font size="5"> 
           year=<?Php echo "$year"; ?>
           class=<?Php echo "$class"; ?>
           semno=<?Php echo "$semno"; ?>
           subject=<?Php echo "$subject"; ?>
           </font>
       </thead>
        <thead>
 <tr>
  <th>Qno</th> 
  <th>question</th> 
  <th>co_no</th>
 </tr>
        </thead>
        <tbody>
 <?Php
//echo "$email";
//echo "$year";
//echo "$class";
//echo "$semno";
//echo "$subject";

  
  $sql = "SELECT * from addmseques where email='$email' and year='$year' and class='$class' and semno='$semno' and subject='$subject'";
  
  if (mysqli_query($conn, $sql)) {
   // output data of each row
   $result = mysqli_query($conn,$sql);
   $count=0;
   while($row = mysqli_fetch_assoc($result)) {
       $count++;
       $sql1="Update addassignques set qno='$count' where email='$email' and year='$year' and class='$class' and semno='$semno' and subject='$subject';";
       mysqli_query($conn,$sql1);
    echo "<tr><td>" .$count. "</td><td>" . $row["question"] . "</td><td>" . $row["co_no"]. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
        </tbody>
        
</table>
    </div>
 <form method="post" action="exportprocess2.php">  
                     <input type="submit" name="export" value="CSV Export" class="btn btn-success" />
 </form>
</center>		
