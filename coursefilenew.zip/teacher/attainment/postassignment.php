
<form id="myForm" NAME ="form1" METHOD ="POST" ACTION ="setassignques.php">				
<table border="0" align="center" >
  <tr>
      <td>Enter a question:</td>
      <td> <INPUT TYPE = 'TEXT' class="form-control" Name ='question' id="question"  maxlength="40"></td>
        <td>
        <div style="float:right;">
			
			<SELECT name="co_no" class="form-control"  size="1">
                            <OPTION value="" id="co_no" name="co_no" SELECTED>CO</option>
			<OPTION>1</option>
			<OPTION>2</option>
			<OPTION>3</option>
			<OPTION>4</option>
			</SELECT>
			
    </td>
  </tr>
  <br>
   <tr>
   <P align = center>
   <td colspan="2">
           <INPUT TYPE = "Submit" Name = "Sub1"  VALUE = "Set this Question" class="btn-primary">
           <input type="button" onclick="myFunction()" value="Add Another Question" class="btn-default">
   </td>
</P> 
        </tr>
 
</table>
 
    
            <script>
function myFunction() {
    document.getElementById("myForm").reset();
}
</script>
	</form>
	
                   