<?php
        session_start();
	include('db.php');
        $name=$_SESSION['user_id'];
        $tid=$_SESSION['tid'];
        echo $tid;
        $class=$_POST['class'];
        echo $class;
        $subject=$_POST['subject'];
        echo $subject;
        $year=$_POST['year'];
        echo $year;
        $semester=$_POST['semester'];
         
        
        //echo $class;
        //echo $subject;
        //echo $year;
        echo $semester;
        //echo $quizno;
        //echo $attainment;
        
     $sql1="select * from msequestionpaper where class='$class' and subjectid=$subject and year=$year and semester=$semester and tid=$tid ";
     $result=mysqli_query($con, $sql1);
    while($row = mysqli_fetch_assoc($result)) {
		$msequestionpaperid = $row['Idmsequestionpaper'];
		}
        
        $_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
        //$_SESSION['quizno']=$quizno;
        //$_SESSION['attainment']=$;
	$_SESSION['msequestionpaperid']=$msequestionpaperid;
		
        echo $_SESSION['msequestionpaperid'];
        
        
        header("Location: studentlistuploadMSE.php");
?>