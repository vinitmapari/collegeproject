<html lang="en">
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/Home.css">
  <script src="js/Home.js"></script>
  <style>
  .jumbotron {
      background-image:url("http://advantagecpr.org/wp-content/uploads/2014/09/blurred-background-office.jpg");
      color:#003333;
  }
  </style>
  <script>
$(document).ready(function(){
  
    $(".candidate").click(function(){
        $(".collapse").collapse('candidate');
    });
    $(".candidate").click(function(){
        $(".collapse in").collapse('candidate');
    });
   
});
</script>
</head>
<body>
