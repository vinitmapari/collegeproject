<center><h1></h1></center>
<div class="container">
    <div class="col-md-1">
    </div>
    <div class="col-md-10">
        <div class="panel">
            <ul class="nav nav-tabs" role="tablist">
                <li class="tablinks" onclick="openCity(event, 'PostJD')" id="defaultOpen"><a href="#">Post Job Description</a></li>
                <li class="tablinks" onclick="openCity(event, 'SaveJD')"><a href="#">Saved Job Description</a></li>
                <li class="tablinks" onclick="openCity(event, 'SaveProfile')"><a href="#">Saved Profile</a></li>
                <li class="tablinks" onclick="openCity(event, 'Skills')"><a href="#">Skills</a></li>
                <li class="tablinks" onclick="openCity(event, 'Account')"><a href="#">Account</a></li>
            </ul>
<br>
                <div id="PostJD" class="tabcontent">
                    <center>
                        <?php include 'postESE.php';?>
                    </center>
                </div>

<div id="SaveJD" class="tabcontent" style="padding: 2px">
                    <center>
                        <?php include 'displayesedata.php';?>
                    </center>
                </div>

                <div id="SaveProfile" class="tabcontent">
                    <center>
                        Coming soon 3
                        
                    </center>
                </div>

                <div id="Skills" class="tabcontent">
                    <center>
                         Coming soon 4
                    </center>
                </div>

                <div id="Account" class="tabcontent">
                    <center>
                        Coming soon 5
                    </center>
                </div>

            </div>
    </div>
                <div class="col-md-1">
                </div>
</div>
<script>
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}
document.getElementById("defaultOpen").click();
</script>
