<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            
           <div class="panel panel-default">
                <div class="panel-heading">Please select following </div>

                <div class="panel-body">
                   
                   
                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="attainment" class="col-md-4 control-label">Type of attainment</label>

                            <div class="col-md-6">
                               <form method="POST" name="mapform1">
                                    <select name="jump1" size="1" class="form-control">
                                        <option selected="selected" value="">Type Of Aattenment</option>
                                        <option value="quizselection.php">Quiz</option>
										<option value="assignmentselection.php">Assignment</option>
										<option value="MSEselection.php">MSE</option>
										<option value="ESEselection.php">ESE</option>
                                        
                                    </select>

                               </form>
                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>

                        

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                               
                                <INPUT type=button class="btn btn-primary" onClick= "location = '' + document.mapform1.jump1.options[ document.mapform1.jump1.selectedIndex ].value;" value="Submit">
                                                                
                            </div>
                        </div>
                    
                </div>
            </div>
       
        </div>
    </div>
</div>
