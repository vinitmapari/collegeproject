<?php
        session_start();
	include('db.php');
        $name=$_SESSION['user_id'];
        
        $class=$_POST['class'];
        $subject=$_POST['subject'];
        $year=$_POST['year']; 
        $semester=$_POST['semester'];
        $assignmentno=$_POST['assignmentno'];
        //$attainment=$_POST['attainment'];
	$co=$_POST['co'];  
        
        //echo $class;
        //echo $subject;
        //echo $year;
        //echo $semester;
        //echo $assignmentno;
        //echo $attainment;
        
        $_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
        $_SESSION['assignmentno']=$assignmentno;
        //$_SESSION['attainment']=$;
	$_SESSION['co']=$co;
		
        
        header("Location: studentlistuploadassign.php");
?>