<?php
include("auth.php"); 
require 'db.php';
$email=$_SESSION["email"];
$sql=mysqli_query($con,"select *from user where email='$email'");

$s=mysqli_fetch_array($sql);



 ?>
 
<html>
<head>
<link href="css/style12.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <!-- Topper w/ logo -->
  <div class="row hidden-xs topper">
    <div class="col-xs-7 col-sm-7">
      <a href="//convertify.io"><img am-TopLogo alt="SECUREVIEW"  src="SPIT_Logo.gif" class="img-responsive"></a>
    </div>
    <div class="col-xs-5 col-xs-offset-1 col-sm-5 col-sm-offset-0 text-right ">
      
    </div>
  </div> <!-- End Topper -->
  <!-- Navigation -->
  <div class="row">
    <nav class="navbar navbar-inverse" role="navigation">
      <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand visible-xs-inline-block nav-logo" href="/"><img src="/images/logo-dark-inset.png" class="img-responsive" alt=""></a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav js-nav-add-active-class">
            <li><a href="/McaSem2/index1.php">Home</a></li>
            <li><a href="/svstrike.html">FyMca</a></li>
            <li><a href="/training.html">SyMca</a></li>
            <li><a href="/contact.html">TyMca</a></li>
         
          </ul>
		   <div class="pull-right">
                <ul class="nav pull-right">
                    <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span>Welcome, <?php echo $s['LoginType']; echo " !";?></span> <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="/user/preferences"><i class="icon-cog"></i> Student List</a></li>
              
                            <li class="divider"></li>
                            <li><a href="logout.php"><i class="icon-off"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
              </div>
          <!--<ul class="nav navbar-nav navbar-right hidden-xs">
            <a type="button" class="navbar-btn btn btn-gradient-blue" am-latosans="bold" href="login.php">LOGIN</a>
          </ul>-->
        </div><!-- /.navbar-collapse -->
		
      </div>
    </nav>
  </div>
</div>
<div>
<!-- Main Content -->
<table border="2" align="center">
<tr>
<th>

<div>
<!--<FORM name="mapform" method="POST">
<select name="jump" size="1">
<option selected="selected" value="">Class</option>
<option value="http://www.fe dri.com/posting.php?mode=post&amp;f=1">FyMca</option>
<option value="http://www.fe dri.com/posting.php?mode=post&amp;f=4">SyMca</option>
<option value="http://www.fe dri.com/posting.php?mode=post&amp;f=4">TyMca</option>
</select>
</form>
</div>-->
<span>Class, <?php echo $s['LoginType']; echo " !";?></span> 
</th>
<th>

<div>
<form method="POST" name="mapform2">
<select name="jump2" size="1">
<option selected="selected" value="">Subject</option>
<option value="http://www.fe dri.com/discuss">DS</option>
<option value="http://www.fe dri.com/discuss">CN</option>
<option value="http://www.fe dri.com/discuss">PP</option>
</select>
</form>
</div>

</th>
</tr>
<tr>
<th colspan="2">
<div>
<form method="POST" name="mapform1"><select name="jump1" size="1">
<option selected="selected" value="">Type Of Aattenment</option>
<option value="quiz1.php">Quiz</option>
<option value="http://www.fe dri.com/posting.php?mode=post&amp;f=28">Assignment</option>
</select>
<INPUT type=button onClick= "location = '' + document.mapform1.jump1.options[ document.mapform1.jump1.selectedIndex ].value;" value="View Page">
</FORM>
</div> 
</th>
</tr>

</table>
<script language="javascript">
function myChangeHandler() {
window.open(this.options[this.selectedIndex].value, '_parent');
this.form.submit(); }
</script>
				
</body>
</html>