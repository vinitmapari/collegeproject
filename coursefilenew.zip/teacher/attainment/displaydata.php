<?php
 //session_start();
$conn = mysqli_connect("localhost:3308", "root", "", "mca");
  // Check connection
  if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
  } 
  
$email=$_SESSION["email"];
$year=$_SESSION["year"];
$class=$_SESSION["class"];
$semno=$_SESSION["semno"];
$quizno=$_SESSION["quizno"];
$subject=$_SESSION["subject"];
?>
<center>
    <div class="tableborder" style="padding: 2px;">
    <table class="table" style="padding: 2px;">
        <thead>
        <font size="5"> quizno=<?Php echo "$quizno"; ?>
           year=<?Php echo "$year"; ?>
           class=<?Php echo "$class"; ?>
           semno=<?Php echo "$semno"; ?>
           subject=<?Php echo "$subject"; ?>
           </font>
       </thead>
        <thead>
 <tr>
  <th>Qno</th> 
  <th>question</th> 
  <th>optionA</th>
  <th>optionB</th>
  <th>optionC</th>
  <th>optionD</th>
  <th>co_no</th>
 </tr>
        </thead>
        <tbody>
 <?Php


  
  $sql = "SELECT * from addquestion where email='$email' and year='$year' and class='$class' and semno='$semno' and quizno='$quizno' and subject='$subject'";
  
  if (mysqli_query($conn, $sql)) {
   // output data of each row
   $result = mysqli_query($conn,$sql);
   $count=0;
   while($row = mysqli_fetch_assoc($result)) {
       $count++;
       $sql1="Update addquestion set qno='$count' where email='$email' and year='$year' and class='$class' and semno='$semno' and quizno='$quizno' and subject='$subject';";
       mysqli_query($conn,$sql1);
    echo "<tr><td>" .$count. "</td><td>" . $row["question"] . "</td><td>" . $row["optionA"] . "</td><td>" . $row["optionB"] . "</td><td>" . $row["optionC"] . "</td><td>" . $row["optionD"] . "</td><td>" . $row["co_no"]. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
        </tbody>
        
</table>
    </div>
 <form method="post" action="exortprocess.php">  
                     <input type="submit" name="export" value="CSV Export" class="btn btn-success" />
 </form>
</center>		
