<div id="Home" class="container-fluid">
  <div class="row">
    <div class="col-sm-8"><br>
      <h2>Welcome</h2><br>
      <h4>
      Welcome MCA Department of Sardar Patel Institute of Technology
      Right from it’s first year in 2009, S.P.I.T. has been one of the 
      sought college by students for MCA and is renown for its ongoing courses.
      Even though starting in year 2009 it has managed to excel quickly and with 
      the highest cutoff this year it has shown a growth among the students all over
      </h4>
     </div>
    <div class="col-sm-4">
    <br><br><span class="glyphicon glyphicon-signal logo"></span>
    </div>
  </div>
</div>
