 <?php  
session_start();
//include('db.php');
require('db27.php');

$tid=$_SESSION["tid"];

                
$questionno=$_POST['questionno'];
$subquestion=$_POST['subquestion'];
$question=$_POST['question'];
$questionmarks=$_POST['questionmarks'];
$msequestionpaperid=$_SESSION["msequestionpaperid"];

$sql = "INSERT INTO  msepaperdescription(Questionno,subquestion,Question,QuestionMarks,msequestionpaperid)VALUES($questionno,'$subquestion','$question',$questionmarks,$msequestionpaperid);";
if(mysqli_query($con, $sql)){  
 echo "Record inserted successfully"; 
}else{  
echo "Could not insert record: ". mysqli_error($con);  
}  
  
mysqli_close($con); 
 
 
?>  