<?php include 'db.php';?>
<?php include 'Header.php';?>
<?php
include("auth.php"); 
require 'db.php';
$email=$_SESSION["email"];

$sql=mysqli_query($con,"select *from user where email='$email'");

$s=mysqli_fetch_array($sql);
$_SESSION['name']=$s['name'];

 ?>
<?php include 'navbarUser.php';?>
<?php
	include('db.php');
      
        $class=$_POST['class'];
        $subject=$_POST['subject'];
        $year=$_POST['year'];
        $semester=$_POST['semester'];
        $attainment=$_POST['quizno'];
        //=$_POST['attainment'];
        
        $_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
        //$_SESSION['quizno']=$quizno;
        $_SESSION['attainment']=$attainment;
        
$connect = mysqli_connect("localhost", "root", "", "mca");
$sql = "SELECT * FROM sdetail where class='$class' and subject='$subject' and year='$year' and semester='$semester'";
$result = mysqli_query($connect, $sql);
?>

<br><br><br><br><br> 
  <div class="container">  
   <br />  
   <br />  
   <br />  
   <div class="table-responsive">  
       <table border="0">
           <tr>
               <td><img src="img/spitlogo.png" width="100"></td>
               <td colspan="4"> <h1>______Sardar Patel Institute of Technology_____ </h1></td>
       </tr>
       <tr>
           <?php
          echo' 
           <td></td>
           <td>Subject='.$subject.'</td><td>  Class='.$class.'</td>
           <td>year='.$year.'</td>
           <td>attainment='.$attainment.'</td>'?>
       </tr>
       </table>
    <h2 align="center">Student Deatils </h2><br /> 
    <table class="table table-bordered">
     <tr>  
                         <th>Name</th>  
                         <th>UCID</th>  
                         <th>quiz1</th> 
						 <th>quiz2</th>
						 <th>quiz3</th>
						 <th>quiz4</th>
                                                 <th>Total</th>
                                                 
                    </tr>
     
    <?php
    //row addition
     $count=0;
     $quiztotal=0;
     while($row = mysqli_fetch_array($result))  
     {  
         
         $quiz1=$row["quiz1"]+$row["quiz2"]+$row["quiz3"]+$row["quiz4"];
        echo '  
       <tr>  
         <td>'.$row["name"].'</td>  
         <td>'.$row["UCID"].'</td>  
         <td>'.$row["quiz1"].'</td>  
		 <td>'.$row["quiz2"].'</td> 
		 <td>'.$row["quiz3"].'</td> 
		 <td>'.$row["quiz4"].'</td> 
                 <td>'.$quiz1.'</td> 
   
       </tr>  
        ';  
        if($quiz1!=0)
        {
            $count++;
        }
        $quiztotal=$quiztotal+$quiz1;
     }
     ?>
                   
    </table>
     <h4>RESULT ANALYSIS FOR ATTAINMENT USING STANDARD DEVIATION				
</h4>
    <?php 
    //column addtion
        $sql = "SELECT quiz1,quiz2,quiz3,quiz4 FROM sdetail where class='$class' and subject='$subject' and year='$year' and semester='$semester'";
        $result = mysqli_query($connect, $sql);
    ?>
    <?php
    //row addition
     $quiz1=0;
     $quiz3=0;
     $quiz5=0;
     $quiz7=0;
      $countquiz1=0;
       $countquiz2=0;
        $countquiz3=0;
         $countquiz4=0;
         
     while($row = mysqli_fetch_array($result))  
     {  
         
         $quiz2=$row["quiz1"];
        
         if($quiz2!=0)
         {
             $countquiz1= $countquiz1+1;
         }
         $quiz1=$quiz1+$quiz2;
         
          $quiz4=$row["quiz2"];
         
         if($quiz4!=0)
         {
             $countquiz2++;
         }
         $quiz3=$quiz3+$quiz4;
         
          $quiz6=$row["quiz3"];
         
         if($quiz6!=0)
         {
             $countquiz3++;
         }
         $quiz5=$quiz5+$quiz6;
         
          $quiz8=$row["quiz4"];
         
         if($quiz8!=0)
         {
             $countquiz4++;
         }
         $quiz7=$quiz7+$quiz8;
        
     }
     ?>
    <table class="table table-bordered">
         <tr>  
                         			 <th>sum</th>
						 <th>quiz1</th>
						 <th>quiz2</th>
                                                 <th>quiz3</th>
                                                 <th>quiz4</th>
                                                 <th>total</th>
                    </tr>
  <?php
     echo '  
       <tr>  
         <td>Sum</td>  
         <td>'.$quiz1.'</td>
             <td>'.$quiz3.'</td>
                 <td>'.$quiz5.'</td>
                     <td>'.$quiz7.'</td>
         <td>'.$quiztotal.'</td>  
   
       </tr>  
       <tr>  
         <td>No of students</td>  
         <td>'.$countquiz1.'</td>
             <td>'.$countquiz2.'</td>
                 <td>'.$countquiz3.'</td>
                     <td>'.$countquiz4.'</td>
         <td>'.$count.'</td>  
   
       </tr>  
       
       <tr>  
         <td>Avg</td>  
         <td>'.$quiz1/$countquiz1.'</td>
             <td>'.$quiz3/$countquiz2.'</td>
                 <td>'.$quiz5/$countquiz3.'</td>
                     <td>'.$quiz7/$countquiz4.'</td>
         <td>'.$quiztotal/$count.'</td>  
   
       </tr>  
        ';  
     
     
     ?>
    </table>
    <br />
    <!--<form method="post" action="export-student.php">
     <input type="submit" name="export" class="btn btn-success" value="Export" />
    </form>-->
   </div>  
  </div>  
<br>

<a href="..//Mcadepartment/pdfoop.php">Click here to download PDF</a>


 <?php include 'Footer.php';?>
 