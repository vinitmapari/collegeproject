<?php include 'Header.php';?>
<?php include 'login.php';?>
<?php include 'Registration.php';?>
<?php include 'navbarHome.php';?><br><br>
<?php include 'About.php';?>

<?php //include 'Review.php';?> 
<?php //include 'contact.php';?> 
<?php include 'Footer.php';?>

       
        