<?php include 'db27.php';?>

<br><br><br><br><br><br><br><br><br><br>
<?php $output = '<center><label class="text-danger">Data inserted successfully</label></center>';
 echo $output;
 ?>
<br><br><br><br><br><br><br><br><br><br>

 