<?php include 'db.php';?>
<?php include 'Header.php';?>
<?php
include("auth.php"); 
require 'db.php';
$email=$_SESSION["email"];

$sql=mysqli_query($con,"select *from user where email='$email'");

$s=mysqli_fetch_array($sql);
$_SESSION['name']=$s['name'];

 ?>
<?php include 'navbarMSE.php';?>
<br><br><br><br><br><br><br><br><br><br>
<?php $output = '<center><label class="text-danger">Data inserted successfully</label></center>';
 echo $output;
 ?>
<br><br><br><br><br><br><br><br><br><br>
<?php include 'Footer.php';?>
 