<?php
        
        
        //require "theader.php";
        session_start();
	include('db.php');
        $name=$_SESSION['user_id'];
        $tid=$_SESSION['tid'];
        //echo $tid;
        $class=$_POST['class'];
        //echo $class;
        $subject=$_POST['subject'];
        //echo $subject;
        $year=$_POST['year'];
        //echo $year;
        $semester=$_POST['semester'];
        
     $sql1="select * from msequestionpaper where class='$class' and subjectid=$subject and year=$year and semester=$semester and tid=$tid ";
     $result=mysqli_query($con, $sql1);
    while($row = mysqli_fetch_assoc($result)) {
		$msequestionpaperid = $row['Idmsequestionpaper'];
		}
        
        $_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
  
	$_SESSION['msequestionpaperid']=$msequestionpaperid;
        
        

?>
  

<html lang="en">
<head>
 
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>

</head>
<body>

<div class="container">
  <h3>Mse question paper</h3>

  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Add question</a></li>
    <li><a data-toggle="tab" href="#menu1">Question Paper</a></li>
   
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
        <br><br>
<form class="form-horizontal" METHOD ="POST" ACTION ="setmsequestions.php">
  
<div class="form-group">
    <label class="control-label col-sm-2" for="email">CO</label>
    <div class="col-sm-10">
        <select name="cono" size="1" class="form-control">
                                        <?Php 
 require "db27.php";
 $query = "select * from co";
 $results = mysqli_query($con,$query);

    while ($rows = mysqli_fetch_assoc(@$results)){ 
    ?>
                                        
      <option value="<?php echo $rows['idco'];?>"><?php echo $rows['cono'];?></option>
	 
 <?php
    } 
    
 ?>
                                    </select>
    </div>
  </div>
  
<div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Question No</label>
    <div class="col-sm-10"> 
      <SELECT name="questionno" class="form-control"  size="1">
                          
                        <OPTION value="1">1</option>
			<OPTION value="2">2</option>
			<OPTION value="3">3</option>
			<OPTION value="4">4</option>
     </SELECT>
    </div>
  </div>

<div class="form-group">
    <label class="control-label col-sm-2" for="pwd">SubQuestion No</label>
    <div class="col-sm-10"> 
      <SELECT name="subquestion" class="form-control"  size="1">
                          <OPTION value=""></option>
			<OPTION value="a">a</option>
			<OPTION value="b">b</option>
			<OPTION value="c">c</option>
			<OPTION value="d">d</option>
	</SELECT>
    </div>
  </div>

<div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Question</label>
    <div class="col-sm-10"> 
      <input type="text" class="form-control" name="question">
    </div>
  </div>

<div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Marks</label>
    <div class="col-sm-10"> 
      <input type="text" class="form-control" name="questionmarks">
    </div>
  </div>

  <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default">Submit</button>
	<input type="button" onclick="myFunction()" value="Add Another Question" class="btn-default">
    </div>
<script>
function myFunction() {
    document.getElementById("myForm").reset();
}
</script>
  </div>
</form>
    </div>
      
      
      
    <div id="menu1" class="tab-pane fade">
       <table class="table" style="padding: 2px;">

        <thead>
 <tr>
  <th>Qno</th> 
  <th>question no</th> 
  <th>subquestion</th>
  <th>question</th>
  <th>total marks</th>
  <th>Co</th>
 </tr>
        </thead>
        <tbody>
 <?Php
  
  $sql = "SELECT * from msepaperdescription where msequestionpaperid='$msequestionpaperid'";
  
  if (mysqli_query($con, $sql)) {
   // output data of each row
   $result = mysqli_query($con,$sql);
   $count=0;
   while($row = mysqli_fetch_assoc($result)) {
       $count++;
       $coid=$row["coid"];
       //echo $coid;
       $sql5="select * from co where idco=$coid";
       $result5 = mysqli_query($con,$sql5);
        while($row5 = mysqli_fetch_assoc($result5)) {
            $coname=$row5['cono'];
        }
       
           echo "<tr><td>" .$count. "</td><td>" . $row["Questionno"] . "</td><td>" . $row["subquestion"]. "</td><td>" . $row["Question"] . "</td><td>" . $row["QuestionMarks"]. "</td><td>" . $coname. "</td></tr>";
}
echo "</table>";
} else { echo "no questions"; }
$con->close();
?>
        </tbody>
        
</table>
    </div>
 <form method="post" action="exportprocess1.php">  
                     <input type="submit" name="export" value="CSV Export" class="btn btn-success" />
 </form>
    <a href="../addinfo27.php" class="btn btn-info" role="button">Back</a>
    
  </div>
</div>

</body>
</html>