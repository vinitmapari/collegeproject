<footer id="footer" class="text-center">
    <nav class="navbar text-center">
        <div class="col-sm-3">
        </div>
        <div class="col-sm-6">
            <center>
            <div class="container-fluid text-center">
                <div class="pad1">
                <font color="white" style="align-content: left;">
                Follow Us on Social Media
                </font>
                </div>
                <br>
                
        <ul class="nav navbar-nav text-center">
              <li class="pad"><i class="fa fa-facebook-official" style="font-size:36px; color: #00b3b3;"></i></li>
            <li class="pad"><i class="fa fa-google-plus-official" style="font-size:36px;color: #00b3b3;"></i></li>
            <li class="pad"><i class="fa fa-instagram" style="font-size:36px;color: #00b3b3;"></i></li>
            <li class="pad"><i class="fa fa-linkedin" style="font-size:36px;color: #00b3b3;"></i></li>
            <li class="pad"><i class="fa fa-twitter" style="font-size:36px;color: #00b3b3;"></i></li>
            <li class="pad"><i class="fa fa-youtube-play" style="font-size:36px;color: #00b3b3;"></i></li>
        </ul>        
            </div>
                </center>
       
        </div>
        <div class="col-sm-3">
             <br><br><br><br><br><br><br><br>
             <a href="#myPage" title="To Top">
                 <span class="glyphicon glyphicon-chevron-up" style="font-size: 50px;border:12px red; border-radius:50%;padding: 7px 12px 4px 7px;">
                 </span>
             </a>
        </div>
    </nav>
</footer>
</body>
</html>
