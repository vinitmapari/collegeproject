
<script type="text/javascript">
  
function myfunction()
{
	alert("Registered Successful");
}
	  function goToNewPage()
    {
        var url = document.getElementById('list').value;
        if(url != 'none') {
            window.location = url;
        }
    }
	
	var check = function() {
	

  if (document.getElementById('password').value ==
    document.getElementById('password-confirm').value) {

    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = 'matching';
  } else {
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'not matching';
  }
}
	</script>

<div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <br><br><br>
         <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Registration</h4>
        </div>
        <div class="modal-body">
           
            <form class="form-horizontal" method="POST" action="regprocess.php">
        
                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Stream</label>

                            <div class="col-md-6">
                               <select name="stream" required="required">
                                    <option value="MCA">MCA</option>
                                    <option value="Engineering"> Engineering</option>
                                </select>

                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>
        
                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" placeholder="Enter your name" name="name" value="" required autofocus>

                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" placeholder="Enter your email" name="email" value="" required>

                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                                
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" placeholder="Enter your password" name="password" onkeyup='check();' required>
                            </div>
                        </div>

                       <!-- <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" placeholder="Re-enter your password" name="password_confirmation" onkeyup='check();' required>
                           <span class="help-block">
                                        <strong><span id='message'></span></strong>
                                    </span>
                               
                            </div>
                        </div>
-->
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Register
                                </button>
                            </div>
                        </div>
                    </form>
            
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

