<?php
        session_start();
	include('db.php');
        include('Header.php');
        $name=$_SESSION['user_id'];
        $tid=$_SESSION['tid'];
        echo $tid;
        $class=$_POST['class'];
        echo $class;
        $subject=$_POST['subject'];
        echo $subject;
        $year=$_POST['year'];
        echo $year;
        $semester=$_POST['semester'];
        
        
     $sql1="select * from msequestionpaper where class='$class' and subjectid=$subject and year=$year and semester=$semester and tid=$tid ";
     $result=mysqli_query($con, $sql1);
    while($row = mysqli_fetch_assoc($result)) {
		$msequestionpaperid = $row['Idmsequestionpaper'];
		}
        
        $_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
  
	$_SESSION['msequestionpaperid']=$msequestionpaperid;
        
        
      
?>

        
    
<div class="container">
    <div class="col-md-1">
    </div>
    <div class="col-md-10">
        <div class="panel">
            <ul class="nav nav-tabs" role="tablist">
                <li class="tablinks" onclick="openCity(event, 'PostJD')" id="defaultOpen"><a href="#">create ESE question paper</a></li>
                <li class="tablinks" onclick="openCity(event, 'SaveJD')"><a href="#">Actual question paper</a></li>
                <li class="tablinks" onclick="openCity(event, 'SaveProfile')"><a href="#">Saved Profile</a></li>
                <li class="tablinks" onclick="openCity(event, 'Skills')"><a href="#">Skills</a></li>
                <li class="tablinks" onclick="openCity(event, 'Account')"><a href="#">Account</a></li>
            </ul>
<br>
                <div id="PostJD" class="tabcontent">
                    <center>
 <!------------------------------------------post questions----------------------------------->  
 <form id="myForm" NAME ="form1" METHOD ="POST" ACTION ="setesequestions.php">				
<table border="0" align="center" >
  <tr>
      <td>Question No</td>
      
        <td>
        <div style="float:right;">
			
			<SELECT name="questionno" class="form-control"  size="1">
                          
                        <OPTION value="1">1</option>
			<OPTION value="2">2</option>
			<OPTION value="3">3</option>
			<OPTION value="4">4</option>
			</SELECT>
        </div>		
    </td>
  </tr>
  
  <tr>
      <td>Sub Question No</td>
      
        <td>
        <div style="float:right;">
			
			<SELECT name="questionno" class="form-control"  size="1">
                          
			<OPTION value="a">a</option>
			<OPTION value="b">b</option>
			<OPTION value="c">c</option>
			<OPTION value="d">d</option>
			</SELECT>
        </div>		
    </td>
  </tr>
  
  <tr>
      <td>Question</td>
      <td><input type="text" class="form-control" name="question"></td>
  </tr>
  <tr>
      <td>Question Marks</td>
      <td><input type="text" class="form-control" name="questionmarks"></td>
  </tr>

  <br>
   <tr>
   <P align = center>
   <td colspan="2">
           <INPUT TYPE = "Submit" Name = "Sub1"  VALUE = "Set this Question" class="btn-primary">
           <input type="button" onclick="myFunction()" value="Add Another Question" class="btn-default">
   </td>
    </P> 
   </tr>
 
</table>
 
    
            <script>
function myFunction() {
    document.getElementById("myForm").reset();
}
</script>
	</form>
	

 <!------------------------------------------post questions----------------------------------->
                    </center>
                </div>

<div id="SaveJD" class="tabcontent" style="padding: 2px">
                    <center>
<!------------------------------------data display---------------------------------------------> 
<center>
    <div class="tableborder" style="padding: 2px;">
    <table class="table" style="padding: 2px;">
        <thead>
        <font size="5"> assignment_no=<?Php echo "$assignment_no"; ?>
           year=<?Php echo "$year"; ?>
           class=<?Php echo "$class"; ?>
           semno=<?Php echo "$semno"; ?>
           subject=<?Php echo "$subject"; ?>
           </font>
       </thead>
        <thead>
 <tr>
  <th>Qno</th> 
  <th>question</th> 
  <th>co_no</th>
 </tr>
        </thead>
        <tbody>
 <?Php
//echo "$email";
//echo "$year";
//echo "$class";
//echo "$semno";
//echo "$subject";

  
  $sql = "SELECT * from addassignques where email='$email' and year='$year' and class='$class' and semno='$semno' and assignment_no='$assignment_no' and subject='$subject'";
  
  if (mysqli_query($conn, $sql)) {
   // output data of each row
   $result = mysqli_query($conn,$sql);
   $count=0;
   while($row = mysqli_fetch_assoc($result)) {
       $count++;
       $sql1="Update addassignques set qno='$count' where email='$email' and year='$year' and class='$class' and semno='$semno' and assignment_no='$assignment_no' and subject='$subject';";
       mysqli_query($conn,$sql1);
    echo "<tr><td>" .$count. "</td><td>" . $row["question"] . "</td><td>" . $row["co_no"]. "</td></tr>";
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
        </tbody>
        
</table>
    </div>
 <form method="post" action="exportprocess1.php">  
                     <input type="submit" name="export" value="CSV Export" class="btn btn-success" />
 </form>
</center>		

<!-----------------------------------data display----------------------------------------------->
                    </center>
                </div>

                <div id="SaveProfile" class="tabcontent">
                    <center>
                        Coming soon 3
                        
                    </center>
                </div>

                <div id="Skills" class="tabcontent">
                    <center>
                         Coming soon 4
                    </center>
                </div>

                <div id="Account" class="tabcontent">
                    <center>
                        Coming soon 5
                    </center>
                </div>

            </div>
    </div>
                <div class="col-md-1">
                </div>
</div>
<script>
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}
document.getElementById("defaultOpen").click();
</script>

</body>
</html>