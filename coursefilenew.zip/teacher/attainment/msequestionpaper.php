<?php
session_start();
require('db27.php');
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
</head>
<body>

<?php
require "teachmenu.php";
require "teachsidenav.php";
?>
  <div class="container">
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title"> MSE QUESTION PAPER </h1>
					</div>

  <div class="panel-body">
                    
						
<form class="form-horizontal" method="post" action="msequestionpaper_action.php" enctype="multipart/form-data">
<br>
<div class="form-group">
 <select id="subsel" name="subjectid" class="form-control" style="height:35px">
	<?php
    $query = "select * from subject";
    $results = mysqli_query($con,$query);

    while ($rows = mysqli_fetch_assoc(@$results)){ 
    ?>
      <option value="<?php echo $rows['idsubject'];?>"><?php echo $rows['subjectname'];?></option>
	  <?php
    } 
    ?>
    </select>
</div>
  
  
<div class="form-group">
  <label class="col-md-4 control-label" for="subcode">Year</label>  
  <div class="col-md-4">
      <input id="yr" name="yr" type="number" placeholder="" class="form-control input-md" required="">
  </div>
</div>
						<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="classsel">Class</label>
  <div class="col-md-4">
    <select id="classsel" name="classsel" class="form-control" style="height:30px" required>
      <option value="FY">FY</option>
      <option value="SY">SY</option>
      <option value="TY">TY</option>
    </select>
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label" for="subject" style="text-align:center">Total Marks</label>  
  <div class="col-md-4">
      <input name="totalmarks" type="number" placeholder="Subject" class="form-control input-md" required>
    
  </div>
</div>
                                                
<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" class="btn btn-default">Submit</button>
  </div>
</div>

<br>

</form>
  
</div>
</div><br><br>
</div>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>


<?php
require "footer.php";
?>
</body>
</html> 
