<?php  
//export.php  
session_start();
include('db.php');

 $class=$_SESSION['class'];
 $subject=$_SESSION['subject'];
 $year=$_SESSION['year'];
 $semester=$_SESSION['semester'];
 $quizno=$_SESSION['quizno'];
 $attainment=$_SESSION['attainment'];

$connect = mysqli_connect("localhost", "root", "", "mca");
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT * FROM sdetail where class='$class' and subject='$subject' and year='$year' and semester='$semester'";
 $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                         <th>name</th>  
                         <th>UCID</th>  
                         <th>quiz1</th>  
						 <th>quiz2</th>
						 <th>quiz3</th>
						 <th>quiz4</th>
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
                         <td>'.$row["name"].'</td>  
                         <td>'.$row["UCID"].'</td>  
                         <td>'.$row["quiz1"].'</td>  
						 <td>'.$row["quiz2"].'</td> 
						 <td>'.$row["quiz3"].'</td> 
						 <td>'.$row["quiz4"].'</td> 
                    </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}
?>
