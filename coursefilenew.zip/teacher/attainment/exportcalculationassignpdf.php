<?php include 'db.php';?>
<?php include 'Header.php';?>
<?php
include("auth.php"); 
require 'db.php';
$email=$_SESSION["email"];

$sql=mysqli_query($con,"select *from user where email='$email'");

$s=mysqli_fetch_array($sql);
$_SESSION['name']=$s['name'];

 ?>
<?php include 'navbarAssign.php';?>
<?php
	include('db.php');
      
        $class=$_POST['class'];
        $subject=$_POST['subject'];
        $year=$_POST['year'];
        $semester=$_POST['semester'];
        $quizno=$_POST['quizno'];
        $attainment=$_POST['attainment'];
        
        $_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
        $_SESSION['quizno']=$quizno;
        $_SESSION['attainment']=$attainment;
        
$connect = mysqli_connect("localhost", "root", "", "mca");
$sql = "SELECT * FROM assigndetail where class='$class' and subject='$subject' and year='$year' and semester='$semester'";
$result = mysqli_query($connect, $sql);
?>

<br><br><br><br><br> 
  <div class="container">  
   <br />  
   <br />  
   <br />  
   <div class="table-responsive">  
       <img src="img/spitlogo.png" width="100">
    <h2 align="center">Student Deatils </h2><br /> 
    <table class="table table-bordered">
     <tr>  
                         <th>Name</th>  
                         <th>UCID</th>  
                         <th>Assignment1</th> 
						 <th>Assignment2</th>
						 <th>Assignment3</th>
						 <th>Assignment4</th>
                                                 <th>Total</th>
                                                 
                    </tr>
     
    <?php
    //row addition
     $count=0;
     $quiztotal=0;
     while($row = mysqli_fetch_array($result))  
     {  
         
         $quiz1=$row["assign1"]+$row["assign2"]+$row["assign3"]+$row["assign4"];
        echo '  
       <tr>  
         <td>'.$row["name"].'</td>  
         <td>'.$row["UCID"].'</td>  
         <td>'.$row["assign1"].'</td>  
		 <td>'.$row["assign2"].'</td> 
		 <td>'.$row["assign3"].'</td> 
		 <td>'.$row["assign4"].'</td> 
                 <td>'.$quiz1.'</td> 
   
       </tr>  
        ';  
        if($quiz1!=0)
        {
            $count++;
        }
        $quiztotal=$quiztotal+$quiz1;
     }
     ?>
                   
    </table>
     <h4>RESULT ANALYSIS FOR ATTAINMENT USING STANDARD DEVIATION				
</h4>
    <?php 
    //column addtion
        $sql = "SELECT assign1,assign2,assign3,assign4 FROM assigndetail where class='$class' and subject='$subject' and year='$year' and semester='$semester'";
        $result = mysqli_query($connect, $sql);
    ?>
    <?php
    //row addition
     $quiz1=0;
     $quiz3=0;
     $quiz5=0;
     $quiz7=0;
      $countquiz1=0;
       $countquiz2=0;
        $countquiz3=0;
         $countquiz4=0;
         
     while($row = mysqli_fetch_array($result))  
     {  
         
         $quiz2=$row["assign1"];
        
         if($quiz2!=0)
         {
             $countquiz1= $countquiz1+1;
         }
         $quiz1=$quiz1+$quiz2;
         
          $quiz4=$row["assign2"];
         
         if($quiz4!=0)
         {
             $countquiz2++;
         }
         $quiz3=$quiz3+$quiz4;
         
          $quiz6=$row["assign3"];
         
         if($quiz6!=0)
         {
             $countquiz3++;
         }
         $quiz5=$quiz5+$quiz6;
         
          $quiz8=$row["assign4"];
         
         if($quiz8!=0)
         {
             $countquiz4++;
         }
         $quiz7=$quiz7+$quiz8;
        
     }
     ?>
    <table class="table table-bordered">
         <tr>  
                         			 <th>sum</th>
						 <th>Assignment1</th>
						 <th>Assignment2</th>
                                                 <th>Assignment3</th>
                                                 <th>Assignment4</th>
                                                 <th>total</th>
                    </tr>
  <?php
     echo '  
       <tr>  
         <td>Sum</td>  
         <td>'.$quiz1.'</td>
             <td>'.$quiz3.'</td>
                 <td>'.$quiz5.'</td>
                     <td>'.$quiz7.'</td>
         <td>'.$quiztotal.'</td>  
   
       </tr>  
       <tr>  
         <td>No of students</td>  
         <td>'.$countquiz1.'</td>
             <td>'.$countquiz2.'</td>
                 <td>'.$countquiz3.'</td>
                     <td>'.$countquiz4.'</td>
         <td>'.$count.'</td>  
   
       </tr>  
       
       <tr>  
         <td>Avg</td>  
         <td>'.$quiz1/$countquiz1.'</td>
             <td>'.$quiz3/$countquiz2.'</td>
                 <td>'.$quiz5/$countquiz3.'</td>
                     <td>'.$quiz7/$countquiz4.'</td>
         <td>'.$quiztotal/$count.'</td>  
   
       </tr>  
        ';  
     
     
     ?>
    </table>
    <br />
    <form method="post" action="export-student.php">
     <input type="submit" name="export" class="btn btn-success" value="Export" />
    </form>
   </div>  
  </div>  
<br>
 <?php include 'Footer.php';?>
 