<?php
include("auth.php"); 
require 'db.php';
$email=$_SESSION["email"];

$sql=mysqli_query($con,"select *from user where email='$email'");

$s=mysqli_fetch_array($sql);
$_SESSION['name']=$s['name'];
 ?>
<?php include 'Header.php';?>
<?php include 'navbarMSE.php';?>
<br><br><br><br><br>
<form class="form-horizontal" action="MSEuploadrawselectionaction.php" method="POST">
    
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            
           <div class="panel panel-default">
                <div class="panel-heading">Please select following </div>

                <div class="panel-body">
                   
                      
                        
                        

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">Class</label>

                            <div class="col-md-6">
                                <select class="form-control" id="LoginType" name="class">
                                    <option value="Fy">Fy</option>
                                    <option value="Sy">Sy</option>
                                    <option value="Ty">Ty</option>
                                </select>

                                
                                    <span class="help-block">
                                       <strong></strong>
                                    </span>
                                
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Subject</label>

                            <div class="col-md-6">
                               
                                    <select name="subject" size="1" class="form-control">
                                        <option selected="selected" value="">Subject</option>
                                        <option value="DS">DS</option>
                                        <option value="CN">CN</option>
                                        <option value="PP">PP</option>
                                    </select>
                              
                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>


                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">Year</label>

                            <div class="col-md-6">
                                <select class="form-control" id="LoginType" name="year">
                                    <option value="2018">2018</option>
                                    <option value="2017">2017</option>
                                    
                                </select>

                                
                                    <span class="help-block">
                                       <strong></strong>
                                    </span>
                                
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Semester</label>

                            <div class="col-md-6">
                               
                                    <select name="semester" size="1" class="form-control">
                                        <option selected="selected" value="">Semno</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                    </select>
                             
                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="attainment" class="col-md-4 control-label">Attainment no</label>

                            <div class="col-md-6">
                               
                                    <select name="quiz" size="1" class="form-control">
                                        <option selected="selected" value="">attainmnet  no</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                    </select>

                              
                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>
                    
                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <!--<label for="password" class="col-md-4 control-label">Type of attainment</label>-->

                            <div class="col-md-6">
                               
                                  <!--<select name="attainment" size="1" class="form-control">
                                        <option selected="selected" value="">attainment</option>
                                        <option value="Quiz">Quiz</option>
                                        <option value="Assignment">Assignment</option>
                                  
                                    </select>-->
                             
                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>
                    
                   
                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                               
                                <input type="submit" class="btn-primary">
                                                                
                            </div>
                        </div>
                   
                </div>
            </div>
       
        </div>
    </div>
</div>
</form>
<br>
 <?php include 'Footer.php';?>
