<?php
                        session_start();
                        $class=$_POST['class'];
                        $subject=$_POST['subject'];
                        $year=$_POST['year'];
                        $semester=$_POST['semester'];
                        $quizno=$_POST['quizno'];

                         
                        echo $class;
                        echo $subject;
                        echo $year;
                        echo $semester;
                        echo $quizno;
                        

                        $_SESSION["class"] = "$class";
                        $_SESSION["subject"] = "$subject";
                        $_SESSION["year"] = "$year";
                        $_SESSION["semno"] = "$semester";
                        $_SESSION["quizno"] = "$quizno";

                        header('Location: quiz.php');
 ?>
