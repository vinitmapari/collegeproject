<?php  
//export.php  
session_start();
include('db.php');

 $class=$_SESSION['class'];
 $subject=$_SESSION['subject'];
 $year=$_SESSION['year'];
 $semester=$_SESSION['semester'];
 $quizno=$_SESSION['assignment_no'];
 $attainment=$_SESSION['attainment'];

$connect = mysqli_connect("localhost", "root", "", "mca");
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT * FROM assigndetail where class='$class' and subject='$subject' and year='$year' and semester='$semester'";
 $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                         <th>name</th>  
                         <th>UCID</th>  
                         <th>assign1</th>  
						 <th>assign2</th>
						 <th>assign3</th>
						 <th>assign4</th>
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
                         <td>'.$row["name"].'</td>  
                         <td>'.$row["UCID"].'</td>  
                         <td>'.$row["assign1"].'</td>  
						 <td>'.$row["assign2"].'</td> 
						 <td>'.$row["assign3"].'</td> 
						 <td>'.$row["assign4"].'</td> 
                    </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}
?>
