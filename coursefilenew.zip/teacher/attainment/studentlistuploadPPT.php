<?php
include("auth.php"); 
require 'db.php';
$email=$_SESSION["email"];

$sql=mysqli_query($con,"select *from user where email='$email'");

$s=mysqli_fetch_array($sql);
$_SESSION['name']=$s['name'];
 ?>
<?php include 'Header.php';?>
<?php include 'navbarPresentation.php';?>
<br><br><br><br><br>
<?php

$name1=$_SESSION['name'];
        
        $class=$_SESSION['class'];
        $subject=$_SESSION['subject'];
        $year=$_SESSION['year'];
        $semester=$_SESSION['semester'];
        $attainment=$_SESSION['attainment'];
		$co=$_SESSION['co'];
        
       /* echo $class;
        echo $subject;
        echo $year;
        echo $semester;
        echo $quizno;
        echo $attainment; 
		echo $co; 
*/


$connect = mysqli_connect("localhost:3308", "root", "", "mca");
$output = '';
if(isset($_POST["import"]))
{
 $extension = end(explode(".", $_FILES["excel"]["name"])); // For getting Extension of selected file
 $allowed_extension = array("xls", "xlsx", "csv"); //allowed extension
 if(in_array($extension, $allowed_extension)) //check selected file extension is present in allowed extension array
 {
  $file = $_FILES["excel"]["tmp_name"]; // getting temporary source of excel file
  include("PHPExcel/IOFactory.php"); // Add PHPExcel Library in this code
  $objPHPExcel = PHPExcel_IOFactory::load($file); // create object of PHPExcel library by using load() method and in load method define path of selected file

  $output .= "<label class='text-success'>Data Inserted</label><br /><table class='table table-bordered'>";
  foreach ($objPHPExcel->getWorksheetIterator() as $worksheet)
  {
   $highestRow = $worksheet->getHighestRow();
   for($row=2; $row<=$highestRow; $row++)
   {
    $output .= "<tr>";
    $name = mysqli_real_escape_string($connect, $worksheet->getCellByColumnAndRow(0, $row)->getValue());
    $UID = mysqli_real_escape_string($connect, $worksheet->getCellByColumnAndRow(1, $row)->getValue());
    $quiz1 = mysqli_real_escape_string($connect, $worksheet->getCellByColumnAndRow(2, $row)->getValue());
    $quiz2= mysqli_real_escape_string($connect, $worksheet->getCellByColumnAndRow(3, $row)->getValue());
    $quiz3 = mysqli_real_escape_string($connect, $worksheet->getCellByColumnAndRow(4, $row)->getValue());
    $quiz4 = mysqli_real_escape_string($connect, $worksheet->getCellByColumnAndRow(5, $row)->getValue());
    $query = "update sdetail set quiz1='$quiz1',quiz2='$quiz2',quiz3='$quiz3',quiz4='$quiz4' where class='$class' and subject='$subject' and year='$year' and semester='$semester' and email='$email' and name='$name' and UCID='$UID'";
    mysqli_query($connect, $query);
    
    $output .= '<td>'.$name.'</td>';
    $output .= '<td>'.$email.'</td>';
    $output .= '</tr>';
    
    //echo $name;
    //echo $quiz1;
    
   
    
   }
  } 
  $output .= '</table>';
  $output = '<label class="text-danger">Data inserted successfully</label>'; 
   $file = $subject.$semester.$attainment.$class.$year.$co.".".$extension;
    //echo $file;
    $UploadTmp = $_FILES['excel']['tmp_name'];
    $sql = "INSERT INTO file (filename) VALUES ('$file')"; 
    mysqli_query($con, $sql);
		
    move_uploaded_file($UploadTmp,"Upload/$name1/$file");
    $output = '<label class="text-danger">File Uploaded</label>'; 
    
 }
 else
 {
  $output = '<label class="text-danger">Invalid File</label>'; //if non excel file then
 }
}
?>

  <div class="container box">
   <h3 align="center">Import Excel to Mysql using PHPExcel in PHP</h3><br />
   <form method="post" enctype="multipart/form-data">
    <label>Select Excel File</label>
    <input type="file" name="excel" />
    <br />
    <input type="submit" name="import" class="btn btn-info" value="Import" />
   </form>
   <br />
   <br />
   <?php
   echo $output;
   ?>
  </div>
<br>
 <?php include 'Footer.php';?>
 

