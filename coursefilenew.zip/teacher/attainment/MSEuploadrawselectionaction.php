<?php

session_start();
include("auth.php"); 
require 'db.php';
$email=$_SESSION["email"];

$sql=mysqli_query($con,"select *from user where email='$email'");

$s=mysqli_fetch_array($sql);
$_SESSION['name']=$s['name'];

$class=$_POST['class'];
$subject=$_POST['subject'];
$year=$_POST['year'];
$semester=$_POST['semester'];
$attainment=$_POST['attainment'];

		$_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
        $_SESSION['attainment']=$attainment;
        
        header('Location: MSEreUpload.php');

 ?>
 
 
 