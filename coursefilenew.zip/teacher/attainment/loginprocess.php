<?php
	require('db.php');
	session_start();
    // If form submitted, insert values into the database.
    if (isset($_POST['email'])){
		$email = stripslashes($_REQUEST['email']); // removes backslashes
		$email = mysqli_real_escape_string($con,$email); //escapes special characters in a string
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($con,$password);
		
	//Checking is user existing in the database or not
        $query = "SELECT * FROM `user` WHERE  email='$email' and password='".md5($password)."'";
		$result = mysqli_query($con,$query) or die(mysql_error());
		$rows = mysqli_num_rows($result);
        if($rows==1){
			$_SESSION['email'] = $email;
                        //$_SESSION['name'] = $row["name"];
			header("Location: selection.php"); // Redirect user to index.php
            }else{
				header( "refresh:4;url=login.php" ); 
 echo "<div class='form'><h3 align='center' style='color:#009900'>Username/password is incorrect.</h3><br/></div>";
  echo "<h4 align='center'> You will be redirected in about 4 secs. If not, click <a href='login.php'>here</a></h4>";
          
				//echo "<div class='form'><h3>Username/password is incorrect.</h3><br/>Click here to <a href='login.php'>Login</a></div>";
				}
    }else{
        header('Location: Home.php'); 
    }
?>

   
