<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
    
<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
      <div class="row">
          <div class="col-md-4">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
        <div id="logobox">
            <img width="200" height="100" 
                 src="img/spitlogo.png" 
        class="custom-logo" alt="cropped-logo-with-caption.png" itemprop="logo"/>
        </div>
    </div>
          </div>
          <div class="col-md-8">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
          <li><a href="#Home">Home</a></li>
          <li><a href="#About">About</a></li>
         </ul>
        <ul class="nav navbar-nav navbar-right">
            <li><a href=""  data-toggle="modal" data-target="#myModal1">Sign Up</a></li>
        <li><a href="" data-toggle="modal" data-target="#myModal">Sign In</a></li>
      </ul>
    </div>
      </div>
      </div>
  </div>
</nav>
