<?php
session_start(); 
require('db27.php');
$tid=$_SESSION['tid'];
//$user=$_SESSION['user_id'];

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
<style>
.button {
  padding: 15px 45px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color:#D3D3D3;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
  
}

.button:hover {background-color:#B0C4DE; }

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
td{
    padding: 20px;
}
th{
    font-size: 24px;
    text-align: center;
}
</style>
  

</head>
<body>

<?php
require "teachmenu.php";
//require "addinfosidenav27.php";
?>

<?php
	
        $class=$_POST['class'];
        $subject=$_POST['subject'];
        $year=$_POST['year'];
        $semester=$_POST['semester'];
        
        $_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
        
//sql = "Insert into msequestionpaper(tid,class,subjectid,year,semester)values($tid,'$class','$subject','$year','$semester');";
//result = mysqli_query($con, $sql);

$sql1="select * from studentlist where class='$class' and year='$year';";
$result1 = mysqli_query($con, $sql1);


///////////////////////////////////////////////////////////////////////////////////////////////////////////

        
$query="select * from msequestionpaper where class='$class' and year='$year' and subjectid='$subject' and semester='$semester' and tid='$tid';";
$result2 = mysqli_query($con, $query);
while($row = mysqli_fetch_array($result2))  
{ 
$msequestionpaperid=$row["Idmsequestionpaper"];
}

//echo $msequestionpaperid;
$co=array(); 
$sql3="select * from msepaperdescription where msequestionpaperid='$msequestionpaperid';";
$result3 = mysqli_query($con, $sql3);
$i=0;
while($row = mysqli_fetch_array($result3))  
{ 
$Questionno=$row["Questionno"];
$subquestion=$row["subquestion"];
$coid=$row["coid"];
echo $coid;
$sql4="select * from CO where idco='$coid' and tid='$tid';";
$result4 = mysqli_query($con, $sql4);
while($row = mysqli_fetch_array($result4))  
{ 
$cono=$row["cono"];
}
$co[$i]=$cono;
$questionarray[$i]="$Questionno"."-"."$subquestion";
$i++;
}

for($i=0;$i<sizeof($co);$i++){ 
    echo $co[$i], "\n"; 
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////
$Header = array('UCID', 'Name');
$total=array("total","revise marks"); 
$Header= array_merge($Header, $questionarray);
$Header= array_merge($Header, $total);
foreach ($Header as $value) { 
    echo $value . "\n"; 
}

//$Header = array('UCID', 'Name')+array('hi');
$data = array();

while($row = mysqli_fetch_array($result1))  
{ 
array_push($data, array($row["ucid"],$row["studentname"]));
}

$filename = write_excel1($data, $Header, $co);

function write_excel1($data, $Header, $co)
{
	//We are using PHPExcel Library for creating the Microsoft Excel file
	require_once  './PHPExcel1/Classes/PHPExcel.php';
	
	$objPHPExcel = new PHPExcel();
	//Activate the First Excel Sheet
	$ActiveSheet = $objPHPExcel->setActiveSheetIndex(0);
	
	
	//Write the Header
	$i=0;
	foreach($Header as $ind_el)
	{
		//Convert index to Excel compatible Location
		$Location = PHPExcel_Cell::stringFromColumnIndex($i) . '1';
		$ActiveSheet->setCellValue($Location, $ind_el);
		$i++;
	}
        
        
        $rowIndex=2;
	//$Column = $worksheet->getHighestDataColumn();
        $columnIndex=2; //Column A
        echo $columnIndex;		
 
		foreach($co as $ind_el){ 
			$Location = PHPExcel_Cell::stringFromColumnIndex($columnIndex) . $rowIndex;
			//var_dump($Location);
			$ActiveSheet->setCellValue($Location, $ind_el); 	//Insert the Data at the specific cell specified by $Location
			$columnIndex++;
		}
		
	
	//Insert that data from Row 2, Column A (index 0)
	$rowIndex=3;
	$columnIndex=0; //Column A
	foreach($data as $row)
	{			
		foreach($row as $ind_el)
		{
			$Location = PHPExcel_Cell::stringFromColumnIndex($columnIndex) . $rowIndex;
			//var_dump($Location);
			$ActiveSheet->setCellValue($Location, $ind_el); 	//Insert the Data at the specific cell specified by $Location
			$columnIndex++;
		}
		
		$rowIndex++;
		$columnIndex = 0;
	}		
	
        
	$Range = 'A1:B1';
	$color = 'FFFF0000';
	$ActiveSheet->getStyle($Range)->getFill($Range)->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB($color);
	
	//2. Set the Column Width
	
	for($i=0; $i<count($Header);$i++)
	{
		$Location = PHPExcel_Cell::stringFromColumnIndex($i) ;
		$ActiveSheet->getColumnDimension($Location)->setAutoSize(true);	
	}
	
	
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	
	
	
	
	//Pre-requisites - Optional - Modify it as per your requirement
	$properties =  $objPHPExcel->getProperties();
	$properties->setCreator("SapnaEdu"); //Creator Name
	$properties->setLastModifiedBy("SapnaEdu");
	
	//Pre-requisites - Optional - Modify it as per your requirement
	$properties->setTitle("Report Generated by Sapnaedu");
	$properties->setSubject("Report Generated by Sapnaedu");
	$properties->setDescription("Report Generated by Sapnaedu");
	$properties->setKeywords("Excel Member Report");
	$properties->setCategory("Member Report");

	

	//Result File name
        //$name1=$_SESSION['name'];
	$randno = rand(100000, 999999);

	$fileName = $randno . ".xlsx";
	$folder = "ResultMSE";

	//Create the Result Directory if Directory is not created already
	if (!file_exists($folder))
		mkdir($folder);

	$fullpath = $folder . '/' . $fileName;

	$objWriter->save($fullpath);
	
	return $fullpath;
	
}


	
//header('Location: exportrawmsg.php');

?>
 

<?php
//require "footer.php";
?> 
</body>
</html> 
 