
<?php
include("auth.php"); 
require 'db.php';
$email=$_SESSION["email"];
$sql=mysqli_query($con,"select *from user where email='$email'");

$s=mysqli_fetch_array($sql);

 ?>
 
<?php include 'Header.php';?>
<?php include 'navbarESE.php';?>
<br><br><br><br><br>
<?php include 'ESESelectionform.php';?>
<br>
<?php include 'Footer.php';?>				
