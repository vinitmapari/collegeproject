<?php
include("auth.php"); 
require 'db.php';
$email=$_SESSION["email"];

$sql=mysqli_query($con,"select *from user where email='$email'");

$s=mysqli_fetch_array($sql);
$_SESSION['name']=$s['name'];
 ?>
<?php include 'Header.php';?>
<?php include 'navbarUser.php';?>
<br><br><br><br><br>
<form action="FileUpload.php" method="post" enctype="multipart/form-data" name="FileUploadForm" id="FileUploadForm">

    <label for="UploadFileField"></label>
    <input type="file" name="UploadFileField" id="UploadFileField" />
    <input type="submit" name="UploadButton" id="UploadButton" value="Upload" />                             
                                   
  </form>
<br>
 <?php include 'Footer.php';?>
