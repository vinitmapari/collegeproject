<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
      <div class="row">
          <div class="col-md-4">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
        <div id="logobox">
            <img width="200" height="100" 
                 src="img/spitlogo.png" 
        class="custom-logo" alt="cropped-logo-with-caption.png" itemprop="logo" href="selection.php"/>
        </div>
    </div>
          </div>
          <div class="col-md-8">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
          <li><a href=""></a></li>
         </ul>
         
   <ul class="nav navbar-nav navbar-right">
             <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span> <?php echo $s['name'];?></span> <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                             <li><a href="selection.php"><i class="icon-cog"></i><font color="black"> Selection home</font></a></li>
                            <li><a href="FileUploadSelection1.php"><i class="icon-cog"></i><font color="black"> Student List</font></a></li>
                            <li><a href="Folderview1.php"><i class="icon-cog"></i><font color="black">Folder View</font></a></li>
                            <li><a href="uploadrawselection1.php"><i class="icon-cog"></i><font color="black">upload raw</font></a></li>
                            <li><a href="exportrawselection1.php"><i class="icon-cog"></i><font color="black">Export raw</font></a></li>
                            <li><a href="exportcalculationselectionassign.php"><i class="icon-cog"></i><font color="black">Export attainment</font></a></li>
                            <li class="divider"></li>
                            <li><a href="logout.php"><i class="icon-off"></i><font color="black"> Logout</font></a></li>
                        </ul>
                    </li>
      </ul>
                  
                  
                   
               
              </div>
                
  </div>
          
      </div>
  </div>
</nav>
