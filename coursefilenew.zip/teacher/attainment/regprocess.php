<?php
	include('db.php');	
    // If form submitted, insert values into the database.
    if (isset($_REQUEST['email'])){
                $email = stripslashes($_REQUEST['email']);
		$email = mysqli_real_escape_string($con,$email);
		$stream = stripslashes($_REQUEST['stream']); // removes backslashes
		$stream = mysqli_real_escape_string($con,$stream); //escapes special characters in a string
		$name = stripslashes($_REQUEST['name']);
		$name = mysqli_real_escape_string($con,$name);
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($con,$password);
		$que=mysqli_query($con,"select * from users where email='$email'");
	if(mysqli_num_rows($que))
	{
	
	header( "refresh:3;url=Home.php" ); 
 echo "<div class='form'><h3 align='center' style='color:#009900'>This user already exists.</h3><br/></div>";
  echo "<h4 align='center'> You will be redirected in about 3 secs. If not, click <a href='Home.php'>here</a></h4>";
	
	//echo "<p style='color:red'>This user already exists</p>";
	}
	else
	{
		

		$trn_date = date("Y-m-d H:i:s");
        $query = "INSERT into `user` (name, password, email, trn_date,stream) VALUES ('$name', '".md5($password)."', '$email', '$trn_date','$stream')";
        $result = mysqli_query($con,$query);
        if($result){
		mkdir("Upload/$name");
		header( "refresh:5;url=Home.php" ); 
 echo "<div class='form'><h3 align='center' style='color:#009900'>You are registered successfully.</h3><br/></div>";
  echo "<h4 align='center'> You will be redirected in about 5 secs. If not, click <a href='login.php'>here</a></h4>";
          
		}	
        }
    }else{
       header('Location: Home.php'); 
    }
?>

    
