<?php
                        session_start();
                        $class=$_POST['class'];
                        $subject=$_POST['subject'];
                        $year=$_POST['year'];
                        $semester=$_POST['semester'];
                        $assignment_no=$_POST['assignment_no'];

                        

                        $_SESSION["class"] = "$class";
                        $_SESSION["subject"] = "$subject";
                        $_SESSION["year"] = "$year";
                        $_SESSION["semno"] = "$semester";
                        $_SESSION["assignment_no"] = "$assignment_no";

                        header('Location: assignment.php');
 ?>
