
 
<?php  
session_start();
//include('db.php');
$host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'mca';  
//$count=0;  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
echo 'Connected successfully<br/>';  

$email=$_SESSION["email"];
$year=$_SESSION["year"];
$class=$_SESSION["class"];
$semno=$_SESSION["semno"];
$subject=$_SESSION["subject"];

echo $class;
echo $email;
echo $subject;
echo $year;
echo $semno;

/*
$question = $_POST['question'];
$optionA = $_POST['optionA'];
$optionB = $_POST['optionB'];
$optionC = $_POST['optionC'];
$optionD = $_POST['optionD'];
$co_no = $_POST['co_no'];*/
$question = mysqli_real_escape_string($conn, $_REQUEST['question']);

$co_no = mysqli_real_escape_string($conn, $_REQUEST['co_no']);


$sql = "INSERT INTO addeseques (question,co_no,email,year,class,semno,subject) VALUES('$question','$co_no','$email','$year','$class','$semno','$subject');";
if(mysqli_query($conn, $sql)){  
 echo "Record inserted successfully";
 header('Location: MSE.php');
}else{  
echo "Could not insert record: ". mysqli_error($conn);  
}  
  
mysqli_close($conn); 
 
 
?>  



 
		
		


