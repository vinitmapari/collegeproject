<?php
session_start(); 
require('db27.php');
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
<style>
.button {
  padding: 15px 45px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color:#D3D3D3;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
  
}

.button:hover {background-color:#B0C4DE; }

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
td{
    padding: 20px;
}
th{
    font-size: 24px;
    text-align: center;
}
</style>
  

</head>
<body>

<?php
require "teachmenu.php";
//require "addinfosidenav27.php";
?>

<?php
	
      
        $class=$_POST['class'];
        $subject=$_POST['subject'];
        $year=$_POST['year'];
        $semester=$_POST['semester'];
        $attainment=$_POST['assignmentno'];
        //=$_POST['attainment'];
        
        $_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
        //$_SESSION['assignmentno']=$assignmentno;
        $_SESSION['attainment']=$attainment;
        $tid= $_SESSION['tid'];

$sql = "SELECT * FROM  assignment where class='$class' and subject='$subject' and year='$year' and semester='$semester' and tid='$tid'";
$result = mysqli_query($con, $sql);

while($row = mysqli_fetch_assoc($result))
        {
				
             $assignmentid=$row['idassignment'];
	}

$sql1 = "SELECT * FROM  assignmentmarks where assignid='$assignmentid'";
$result1 = mysqli_query($con, $sql1);

?>

<br><br><br><br><br> 
  <div class="container">  
   <br />  
   <br />  
   <br />  
   <div class="table-responsive">  
       <table border="0">
           <tr>
               <td><img src="img/spitlogo.png" width="100"></td>
               <td colspan="4"> <h3>______Sardar Patel Institute of Technology_____ </h3></td>
               
       </tr>
       <tr>
           <?php
          echo' 
           <td></td>
           <td>Subject='.$subject.'</td><td>  Class='.$class.'</td>
           <td>year='.$year.'</td>
           <td>attainment='.$attainment.'</td>'?>
       </tr>
       </table>
    <h2 align="center">Student Deatils </h2><br /> 
    <table class="table table-bordered">
     <tr>  
                         <th>Name</th>  
                         <th>UCID</th>  
                         <th>assignment1</th> 
						 <th>assignment2</th>
						 <th>assignment3</th>
						 <th>assignment4</th>
                                                 <th>Total</th>
                                                 
                    </tr>
     
    <?php
    //row addition
     $count=0;
     $assignmenttotal=0;
     while($row = mysqli_fetch_array($result1))  
     {  
         
         $assignment1=$row["assign1"]+$row["assign2"]+$row["assign3"]+$row["assign4"];
        echo '  
       <tr>  
         <td>'.$row["studentname"].'</td>  
         <td>'.$row["ucid"].'</td>  
         <td>'.$row["assign1"].'</td>  
		 <td>'.$row["assign2"].'</td> 
		 <td>'.$row["assign3"].'</td> 
		 <td>'.$row["assign4"].'</td> 
                 <td>'.$assignment1.'</td> 
   
       </tr>  
        ';  
        if($assignment1!=0)
        {
            $count++;
        }
        $assignmenttotal=$assignmenttotal+$assignment1;
     }
     ?>
                   
    </table>
     <h4>RESULT ANALYSIS FOR ATTAINMENT USING STANDARD DEVIATION				
</h4>
    <?php 
    //column addtion
        $sql = "SELECT * FROM assignmentmarks where assignid='$assignmentid'";
        $result = mysqli_query($con, $sql);
    ?>
    <?php
    //row addition
     $assignment1=0;
     $assignment3=0;
     $assignment5=0;
     $assignment7=0;
      $countassignment1=0;
       $countassignment2=0;
        $countassignment3=0;
         $countassignment4=0;
         
     while($row = mysqli_fetch_array($result))  
     {  
         
         $assignment2=$row["assign1"];
        
         if($assignment2!=0)
         {
             $countassignment1= $countassignment1+1;
         }
         $assignment1=$assignment1+$assignment2;
         
          $assignment4=$row["assign2"];
         
         if($assignment4!=0)
         {
             $countassignment2++;
         }
         $assignment3=$assignment3+$assignment4;
         
          $assignment6=$row["assign3"];
         
         if($assignment6!=0)
         {
             $countassignment3++;
         }
         $assignment5=$assignment5+$assignment6;
         
          $assignment8=$row["assign4"];
         
         if($assignment8!=0)
         {
             $countassignment4++;
         }
         $assignment7=$assignment7+$assignment8;
        
         
     }
     $temp1=0;
     $temp2=0;
     $temp3=0;
     $temp4=0;
     $temp5=0;
     
     for($i=1;$i<=$countassignment1;$i++)
     {
         $temp1=$temp1+pow(($i-$assignment1),2);
     }
     for($i=1;$i<=$countassignment2;$i++)
     {
     
     $temp2=$temp2+pow(($i-$assignment3),2);
      }   
     for($i=1;$i<=$countassignment3;$i++)
     {
     
     $temp3=$temp3+pow(($i-$assignment5),2);
     }
     for($i=1;$i<=$countassignment4;$i++)
     {
     
     $temp4=$temp4+pow(($i-$assignment7),2);
     }
     
     for($i=1;$i<=$count;$i++)
     {
     
     $temp5=$temp5+pow(($i-$assignmenttotal),2);
     }
     
     $variance1=(float)sqrt($temp1/$countassignment1);
     $variance2=(float)sqrt($temp2/$countassignment2);
     $variance3=(float)sqrt($temp3/$countassignment3);
     $variance4=(float)sqrt($temp4/$countassignment4);
     $variance5=(float)sqrt($temp5/$count);
     
     $upperrange1=(float)($assignment1/$countassignment1)+$variance1;
     $upperrange2=(float)($assignment3/$countassignment2)+$variance2;
     $upperrange3=(float)($assignment5/$countassignment3)+$variance3;
     $upperrange4=(float)($assignment7/$countassignment4)+$variance4;
     $upperrange5=(float)($assignmenttotal/$count)+$variance5;
     
     $lowerrange1=(float)($assignment1/$countassignment1)-$variance1;
     $lowerrange2=(float)($assignment3/$countassignment2)-$variance2;
     $lowerrange3=(float)($assignment5/$countassignment3)-$variance3;
     $lowerrange4=(float)($assignment7/$countassignment4)-$variance4;
     $lowerrange5=(float)($assignmenttotal/$count)-$variance5;
     
     
     ?>
    <table class="table table-bordered">
         <tr>  
                         			 <th>sum</th>
						 <th>assignment1</th>
						 <th>assignment2</th>
                                                 <th>assignment3</th>
                                                 <th>assignment4</th>
                                                 <th>total</th>
                    </tr>
  <?php
     echo '  
       <tr>  
         <td>Sum</td>  
         <td>'.$assignment1.'</td>
             <td>'.$assignment3.'</td>
                 <td>'.$assignment5.'</td>
                     <td>'.$assignment7.'</td>
         <td>'.$assignmenttotal.'</td>  
   
       </tr>  
       <tr>  
         <td>No of students</td>  
         <td>'.$countassignment1.'</td>
             <td>'.$countassignment2.'</td>
                 <td>'.$countassignment3.'</td>
                     <td>'.$countassignment4.'</td>
         <td>'.$count.'</td>  
   
       </tr>  
       
       <tr>  
         <td>Avg</td>  
         <td>'.$assignment1/$countassignment1.'</td>
             <td>'.$assignment3/$countassignment2.'</td>
                 <td>'.$assignment5/$countassignment3.'</td>
                     <td>'.$assignment7/$countassignment4.'</td>
         <td>'.$assignmenttotal/$count.'</td>  
   
       </tr>  
       <tr>
            <td>Std dev</td>
            <td>'.$variance1.'</td>
            <td>'.$variance2.'</td>
            <td>'.$variance3.'</td>
            <td>'.$variance4.'</td>
             <td>'.$variance5.'</td>
        </tr>
        <tr>
            <td>Upper range</td>
            <td>'.$upperrange1.'</td>
            <td>'.$upperrange2.'</td>
            <td>'.$upperrange3.'</td>
            <td>'.$upperrange4.'</td>
             <td>'.$upperrange5.'</td>
        </tr>    
      <tr>
            <td>Lower range</td>
            <td>'.$lowerrange1.'</td>
            <td>'.$lowerrange2.'</td>
            <td>'.$lowerrange3.'</td>
            <td>'.$lowerrange4.'</td>
             <td>'.$lowerrange5.'</td>
        </tr>    
      
        ';  
     $query1 = "Insert into assignmentattainment(sum,noofstudentpresent,average,stddev,upperrange,lowerrange,assignmentid)values($assignmenttotal,$count,$average,$variance5,$upperrange5,$lowerrange5,$assignmentid)";
     mysqli_query($con, $query1);
     
     $sql1 = "SELECT * FROM assignmentattainment where assignmentid='$assignmentid'";
     $result1 = mysqli_query($con, $sql1);
     
     while($row1 = mysqli_fetch_array($result1))  
     {  
         $idassignmentattainment=$row1['idassignmentattainment'];
        
     }
     
     $_SESSION['assignment']=$idassignmentattainment;
     
     $query3 = "Insert into ISEattainmentAssignment(CO1,CO2,CO3,CO4,idassignmentattainment)values('$co1','$co1','$co1','$co1',$idassignmentattainment)";
     mysqli_query($con, $query3);
     
     ?>
    </table>
    <br />
    <input id="pdf-button" type="button" value="Download PDF" onclick="downloadPDF()" />
    <!--<form method="post" action="export-student.php">
     <input type="submit" name="export" class="btn btn-success" value="Export" />
    </form>-->
   </div>  
  </div>  
<br>
<?php
require "footer.php";
?> 
</body>
</html> 
 