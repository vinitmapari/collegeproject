<?php
        session_start();
	include('db.php');
        $name=$_SESSION['name'];
        
        $class=$_POST['class'];
        $subject=$_POST['subject'];
        $year=$_POST['year'];
        $semester=$_POST['semester'];
        $quizno=$_POST['quizno'];
        $attainment=$_POST['attainment'];
		$co=$_POST['co'];
        
        //echo $class;
        //echo $subject;
        //echo $year;
        //echo $semester;
        //echo $quizno;
        //echo $attainment;
        
        $_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
        $_SESSION['quizno']=$quizno;
        $_SESSION['attainment']=$attainment;
		 $_SESSION['co']=$co;
		
        
        header("Location: studentlistupload.php");
?>