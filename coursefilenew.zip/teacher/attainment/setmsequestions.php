<?php  
session_start();
  
$msequestionpaperid=$_SESSION['msequestionpaperid'];
include('db.php');

//$count=0;  
//$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$con){  
  die('Could not connect: '.mysqli_connect_error());  
}  
echo 'Connected successfully<br/>';  




$questionno = $_POST['questionno'];
$subquestion = $_POST['subquestion'];
$question = $_POST['question'];
$questionmarks = $_POST['questionmarks'];
$coid = $_POST['cono'];




$sql = "INSERT INTO msepaperdescription (Questionno,subquestion,Question,QuestionMarks,msequestionpaperid,coid) VALUES($questionno,'$subquestion','$question',$questionmarks,$msequestionpaperid,$coid);";
if(mysqli_query($con, $sql)){  
 echo "Record inserted successfully";
 header('Location: setMseQuestionPaperSelectionaction.php');
}else{  
echo "Could not insert record: ". mysqli_error($con);  
}  
  
mysqli_close($con); 
 
 
?>  



 
		
		


