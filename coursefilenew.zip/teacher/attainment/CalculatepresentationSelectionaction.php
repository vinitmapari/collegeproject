<?php
session_start(); 
require('db27.php');
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
<style>
.button {
  padding: 15px 45px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color:#D3D3D3;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
  
}

.button:hover {background-color:#B0C4DE; }

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
td{
    padding: 20px;
}
th{
    font-size: 24px;
    text-align: center;
}
</style>
  

</head>
<body>

<?php
require "teachmenu.php";
//require "addinfosidenav27.php";
?>

<?php
	
      
        $class=$_POST['class'];
        $subject=$_POST['subject'];
        $year=$_POST['year'];
        $semester=$_POST['semester'];
        $attainment=$_POST['presentationno'];
        //=$_POST['attainment'];
        
        $_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
        //$_SESSION['presentationno']=$presentationno;
        $_SESSION['attainment']=$attainment;
        $tid= $_SESSION['tid'];

$sql = "SELECT * FROM  presentation where class='$class' and subject='$subject' and year='$year' and semester='$semester' and tid='$tid'";
$result = mysqli_query($con, $sql);

while($row = mysqli_fetch_assoc($result))
        {
				
             $presentationid=$row['idpresentation'];
	}

$sql1 = "SELECT * FROM  presentationmarks where presentationid='$presentationid'";
$result1 = mysqli_query($con, $sql1);

?>

<br><br><br><br><br> 
  <div class="container">  
   <br />  
   <br />  
   <br />  
   <div class="table-responsive">  
       <table border="0">
           <tr>
               <td><img src="img/spitlogo.png" width="100"></td>
               <td colspan="4"> <h3>______Sardar Patel Institute of Technology_____ </h3></td>
               
       </tr>
       <tr>
           <?php
          echo' 
           <td></td>
           <td>Subject='.$subject.'</td><td>  Class='.$class.'</td>
           <td>year='.$year.'</td>
           <td>attainment='.$attainment.'</td>'?>
       </tr>
       </table>
    <h2 align="center">Student Deatils </h2><br /> 
    <table class="table table-bordered">
     <tr>  
                         <th>Name</th>  
                         <th>UCID</th>  
                         <th>presentation1</th> 
						 <th>presentation2</th>
						 <th>presentation3</th>
						 <th>presentation4</th>
                                                 <th>Total</th>
                                                 
                    </tr>
     
    <?php
    //row addition
     $count=0;
     $presentationtotal=0;
     while($row = mysqli_fetch_array($result1))  
     {  
         
         $presentation1=$row["presentation1"]+$row["presentation2"]+$row["presentation3"]+$row["presentation4"];
        echo '  
       <tr>  
         <td>'.$row["studentname"].'</td>  
         <td>'.$row["ucid"].'</td>  
         <td>'.$row["presentation1"].'</td>  
		 <td>'.$row["presentation2"].'</td> 
		 <td>'.$row["presentation3"].'</td> 
		 <td>'.$row["presentation4"].'</td> 
                 <td>'.$presentation1.'</td> 
   
       </tr>  
        ';  
        if($presentation1!=0)
        {
            $count++;
        }
        $presentationtotal=$presentationtotal+$presentation1;
     }
     ?>
                   
    </table>
     <h4>RESULT ANALYSIS FOR ATTAINMENT USING STANDARD DEVIATION				
</h4>
    <?php 
    //column addtion
        $sql = "SELECT * FROM presentationmarks where presentationid='$presentationid'";
        $result = mysqli_query($con, $sql);
    ?>
    <?php
    //row addition
     $presentation1=0;
     $presentation3=0;
     $presentation5=0;
     $presentation7=0;
      $countpresentation1=0;
       $countpresentation2=0;
        $countpresentation3=0;
         $countpresentation4=0;
         
     while($row = mysqli_fetch_array($result))  
     {  
         
         $presentation2=$row["presentation1"];
        
         if($presentation2!=0)
         {
             $countpresentation1= $countpresentation1+1;
         }
         $presentation1=$presentation1+$presentation2;
         
          $presentation4=$row["presentation2"];
         
         if($presentation4!=0)
         {
             $countpresentation2++;
         }
         $presentation3=$presentation3+$presentation4;
         
          $presentation6=$row["presentation3"];
         
         if($presentation6!=0)
         {
             $countpresentation3++;
         }
         $presentation5=$presentation5+$presentation6;
         
          $presentation8=$row["presentation4"];
         
         if($presentation8!=0)
         {
             $countpresentation4++;
         }
         $presentation7=$presentation7+$presentation8;
        
         
     }
     $temp1=0;
     $temp2=0;
     $temp3=0;
     $temp4=0;
     $temp5=0;
     
     for($i=1;$i<=$countpresentation1;$i++)
     {
         $temp1=$temp1+pow(($i-$presentation1),2);
     }
     for($i=1;$i<=$countpresentation2;$i++)
     {
     
     $temp2=$temp2+pow(($i-$presentation3),2);
      }   
     for($i=1;$i<=$countpresentation3;$i++)
     {
     
     $temp3=$temp3+pow(($i-$presentation5),2);
     }
     for($i=1;$i<=$countpresentation4;$i++)
     {
     
     $temp4=$temp4+pow(($i-$presentation7),2);
     }
     
     for($i=1;$i<=$count;$i++)
     {
     
     $temp5=$temp5+pow(($i-$presentationtotal),2);
     }
     
     $variance1=(float)sqrt($temp1/$countpresentation1);
     $variance2=(float)sqrt($temp2/$countpresentation2);
     $variance3=(float)sqrt($temp3/$countpresentation3);
     $variance4=(float)sqrt($temp4/$countpresentation4);
     $variance5=(float)sqrt($temp5/$count);
     
     $upperrange1=(float)($presentation1/$countpresentation1)+$variance1;
     $upperrange2=(float)($presentation3/$countpresentation2)+$variance2;
     $upperrange3=(float)($presentation5/$countpresentation3)+$variance3;
     $upperrange4=(float)($presentation7/$countpresentation4)+$variance4;
     $upperrange5=(float)($presentationtotal/$count)+$variance5;
     
     $lowerrange1=(float)($presentation1/$countpresentation1)-$variance1;
     $lowerrange2=(float)($presentation3/$countpresentation2)-$variance2;
     $lowerrange3=(float)($presentation5/$countpresentation3)-$variance3;
     $lowerrange4=(float)($presentation7/$countpresentation4)-$variance4;
     $lowerrange5=(float)($presentationtotal/$count)-$variance5;
     
     
     ?>
    <table class="table table-bordered">
         <tr>  
                         			 <th>sum</th>
						 <th>presentation1</th>
						 <th>presentation2</th>
                                                 <th>presentation3</th>
                                                 <th>presentation4</th>
                                                 <th>total</th>
                    </tr>
  <?php
     echo '  
       <tr>  
         <td>Sum</td>  
         <td>'.$presentation1.'</td>
             <td>'.$presentation3.'</td>
                 <td>'.$presentation5.'</td>
                     <td>'.$presentation7.'</td>
         <td>'.$presentationtotal.'</td>  
   
       </tr>  
       <tr>  
         <td>No of students</td>  
         <td>'.$countpresentation1.'</td>
             <td>'.$countpresentation2.'</td>
                 <td>'.$countpresentation3.'</td>
                     <td>'.$countpresentation4.'</td>
         <td>'.$count.'</td>  
   
       </tr>  
       
       <tr>  
         <td>Avg</td>  
         <td>'.$presentation1/$countpresentation1.'</td>
             <td>'.$presentation3/$countpresentation2.'</td>
                 <td>'.$presentation5/$countpresentation3.'</td>
                     <td>'.$presentation7/$countpresentation4.'</td>
         <td>'.$presentationtotal/$count.'</td>  
   
       </tr>  
       <tr>
            <td>Std dev</td>
            <td>'.$variance1.'</td>
            <td>'.$variance2.'</td>
            <td>'.$variance3.'</td>
            <td>'.$variance4.'</td>
             <td>'.$variance5.'</td>
        </tr>
        <tr>
            <td>Upper range</td>
            <td>'.$upperrange1.'</td>
            <td>'.$upperrange2.'</td>
            <td>'.$upperrange3.'</td>
            <td>'.$upperrange4.'</td>
             <td>'.$upperrange5.'</td>
        </tr>    
        <tr>
            <td>Lower range</td>
            <td>'.$lowerrange1.'</td>
            <td>'.$lowerrange2.'</td>
            <td>'.$lowerrange3.'</td>
            <td>'.$lowerrange4.'</td>
             <td>'.$lowerrange5.'</td>
        </tr>    
        ';  
     
     $query1 = "Insert into presentationattainment(sum,noofstudentpresent,average,stddev,upperrange,lowerrange,presentationid)values($quiztotal,$count,$average,$variance5,$upperrange5,$lowerrange5,$presentationid)";
     mysqli_query($con, $query1);
     
     $sql1 = "SELECT * FROM presentationattainment where presentationid='$presentationid'";
     $result1 = mysqli_query($con, $sql1);
     
     while($row1 = mysqli_fetch_array($result1))  
     {  
         $idpresentationattainment=$row1['idpresentationattainment'];
     }
     
     $_SESSION['presentation']=$idpresentationattainment;
     
     $query3 = "Insert into ISEattainmentPresentation (CO1,CO2,CO3,CO4,idpresentationattainment)values('$co1','$co1','$co1','$co1',$idpresentationattainment)";
     mysqli_query($con, $query3);
     
     ?>
    </table>
    <br />
    <input id="pdf-button" type="button" value="Download PDF" onclick="downloadPDF()" />
    <!--<form method="post" action="export-student.php">
     <input type="submit" name="export" class="btn btn-success" value="Export" />
    </form>-->
   </div>  
  </div>  
<br>
<?php
require "footer.php";
?> 
</body>
</html> 
 