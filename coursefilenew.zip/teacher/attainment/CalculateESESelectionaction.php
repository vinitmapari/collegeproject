<?php
session_start(); 
require('db27.php');
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
<style>
.button {
  padding: 15px 45px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color:#D3D3D3;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
  
}

.button:hover {background-color:#B0C4DE; }

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
td{
    padding: 20px;
}
th{
    font-size: 24px;
    text-align: center;
}
</style>
  

</head>
<body>

<?php
require "teachmenu.php";
//require "addinfosidenav27.php";
?>

<?php
	
      
        $class=$_POST['class'];
        $subject=$_POST['subject'];
        $year=$_POST['year'];
        $semester=$_POST['semester'];
        $attainment=$_POST['quizno'];
        //=$_POST['attainment'];
        
        $_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
        //$_SESSION['quizno']=$quizno;
        $_SESSION['attainment']=$attainment;
        $tid= $_SESSION['tid'];

$sql = "SELECT * FROM  ese where class='$class' and subject='$subject' and year='$year' and semester='$semester' and tid='$tid'";
$result = mysqli_query($con, $sql);

while($row = mysqli_fetch_assoc($result))
        {
				
             $eseid=$row['eseid'];
	}

$sql1 = "SELECT * FROM  esemarks where eseid='$eseid'";
$result1 = mysqli_query($con, $sql1);

?>

<br><br><br><br><br> 
  <div class="container">  
   <br />  
   <br />  
   <br />  
   <div class="table-responsive">  
       <table border="0">
           <tr>
               <td><img src="img/spitlogo.png" width="100"></td>
               <td colspan="4"> <h3>______Sardar Patel Institute of Technology_____ </h3></td>
               
       </tr>
       <tr>
           <?php
          echo' 
           <td></td>
           <td>Subject='.$subject.'</td><td>  Class='.$class.'</td>
           <td>year='.$year.'</td>
           <td>attainment='.$attainment.'</td>'?>
       </tr>
       </table>
    <h2 align="center">Student Deatils </h2><br /> 
    <table class="table table-bordered">
           <tr>  
                         <th>Name</th>  
                         <th>UCID</th>  
                         <th>MSE</th> 
	                                     
           </tr>
     
    <?php
    //row addition
     $count=0;
     $msetotal=0;
     while($row = mysqli_fetch_array($result1))  
     {  
        echo '  
       <tr>  
         <td>'.$row["studentname"].'</td>  
         <td>'.$row["ucid"].'</td>  
         <td>'.$row["ese_marks"].'</td>   
       </tr>  
        ';  
     }
     ?>
                   
    </table>
     <h4>RESULT ANALYSIS FOR ATTAINMENT USING STANDARD DEVIATION				
</h4>
    <?php 
    //column addtion
        $sql = "SELECT * FROM esemarks where eseid='$eseid'";
        $result = mysqli_query($con, $sql);
    ?>
    <?php
    //row addition
     $quiz1=0;
    
     $countquiz1=0;
      
     $aboveaveragequiz1=0;
     
     while($row = mysqli_fetch_array($result))  
     {  
         
         $quiz2=$row["ese_marks"];
        
         if($quiz2!=0)
         {
             $countquiz1= $countquiz1+1;
         }
         $quiz1=$quiz1+$quiz2;
 
     }
     $temp1=0;
     
     for($i=1;$i<=$countquiz1;$i++)
     {
         $temp1=$temp1+pow(($i-$quiz1),2);
     }
    
     $variance1=(float)sqrt($temp1/$countquiz1);
     
     $upperrange1=(float)($quiz1/$countquiz1)+$variance1;
     
     $lowerrange1=(float)($quiz1/$countquiz1)-$variance1;
     
     ?>
    <table class="table table-bordered">
        <tr>  
             <th>sum</th>
	     <th>ese</th>
	</tr>
  <?php
     echo '  
       <tr>  
         <td>Sum</td>  
         <td>'.$quiz1.'</td>    
       </tr>  
       <tr>  
         <td>No of students</td>  
         <td>'.$countquiz1.'</td>
       </tr>  
       
       <tr>  
         <td>Avg</td>  
         <td>'.$quiz1/$countquiz1.'</td>
       </tr>  
       <tr>
            <td>Std dev</td>
            <td>'.$variance1.'</td>
                
        </tr>
        <tr>
            <td>Upper range</td>
            <td>'.$upperrange1.'</td>
        </tr>    
       <tr>
            <td>Lower range</td>
            <td>'.$lowerrange1.'</td>
        
        </tr>    
      
        ';  
     ?>
     <?Php
     /////////////////////////////////////////////////////////////////////////////////////
     $averagequiz1=$quiz1/$countquiz1;
     
     $sql1 = "SELECT * FROM esemarks where eseid='$eseid'";
        $result1 = mysqli_query($con, $sql1);
     
     while($row1 = mysqli_fetch_array($result1))  
     {  
         if($row1["ese_marks"]>$averagequiz1)
         {
             $aboveaveragequiz1=$aboveaveragequiz1+1;
         }
        
     }
     
     ////////////////////////////////////////////////////////////////////////////////////
     
     ?>
     <?Php
     echo '<td>Number of students above average</td>
            <td>'.$aboveaveragequiz1.'</td>
         
        </tr>    
      <tr>
            <td>CO ATTAINMENT</td>
            <td>'.($aboveaveragequiz1/$countquiz1)*100 .'</td>
            
        </tr>    
      '
     ;
     ?>
    </table>
    <br />
    <input id="pdf-button" type="button" value="Download PDF" onclick="downloadPDF()" />
    <!--<form method="post" action="export-student.php">
     <input type="submit" name="export" class="btn btn-success" value="Export" />
    </form>-->
   </div>  
  </div>  
<br>
<?php

?> 
</body>
</html> 
 