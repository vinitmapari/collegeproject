 <?php  
session_start();
//include('db.php');
require('db27.php');

$tid=$_SESSION["tid"];

                
$questionno=$_POST['questionno'];
$subquestion=$_POST['subquestion'];
$question=$_POST['question'];
$questionmarks=$_POST['questionmarks'];
$esequestionpaperid=$_SESSION["esequestionpaperid"];

$sql = "INSERT INTO  esepaperdescription(Questionno,subquestion,Question,QuestionMarks,esequestionpaperid)VALUES($questionno,'$subquestion','$question',$questionmarks,$esequestionpaperid);";
if(mysqli_query($con, $sql)){  
 echo "Record inserted successfully"; 
}else{  
echo "Could not insert record: ". mysqli_error($con);  
}  
  
mysqli_close($con); 
 
 
?>  