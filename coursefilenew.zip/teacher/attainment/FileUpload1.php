<?php
        session_start();
	include('db.php');
        $name=$_SESSION['name'];
        
        $class=$_SESSION['class'];
        $subject=$_SESSION['subject'];
        $year=$_SESSION['year'];
        $semester=$_SESSION['semester'];
        $assignment_no=$_SESSION['assignment_no'];
        $attainment=$_SESSION['attainment'];
        
        echo $class;
        echo $subject;
        echo $year;
        echo $semester;
        echo $assignment_no;
        echo $attainment; 
        
        if(isset($_FILES['UploadFileField']))
        {
            // Creates the Variables needed to upload the file
 
    $extension = end(explode(".", $_FILES["UploadFileField"]["name"])); // For getting Extension of selected file
    $allowed_extension = array("xls", "xlsx", "csv"); //allowed extension
 
 if(in_array($extension, $allowed_extension)) //check selected file extension is present in allowed extension array
 {
		$UploadName = $_FILES['UploadFileField']['name'];
                include("PHPExcel/IOFactory.php"); // Add PHPExcel Library in this code
                $objPHPExcel = PHPExcel_IOFactory::load($UploadName);
                $output .= "<label class='text-success'>Data Inserted</label><br /><table class='table table-bordered'>";
  foreach ($objPHPExcel->getWorksheetIterator() as $worksheet)
  {
   $highestRow = $worksheet->getHighestRow();
   for($row=2; $row<=$highestRow; $row++)
   {
    $output .= "<tr>";
    $name = mysqli_real_escape_string($connect, $worksheet->getCellByColumnAndRow(0, $row)->getValue());
    $UID = mysqli_real_escape_string($connect, $worksheet->getCellByColumnAndRow(1, $row)->getValue());
    $quiz1 = mysqli_real_escape_string($connect, $worksheet->getCellByColumnAndRow(2, $row)->getValue());
    $quiz2= mysqli_real_escape_string($connect, $worksheet->getCellByColumnAndRow(3, $row)->getValue());
    $quiz3 = mysqli_real_escape_string($connect, $worksheet->getCellByColumnAndRow(4, $row)->getValue());
    $quiz4 = mysqli_real_escape_string($connect, $worksheet->getCellByColumnAndRow(5, $row)->getValue());
    
    echo $name;
    
    $query = "update Assignment='$Assignment1',Assignment2='$Assignment2',Assignment3='$Assignment3',Assignment4='$Assignment4' from sdetail where class='$class' and subject='$subject' and year='$year' and semester='$semester' and email='$email' and name='$name' and UCID='$UID'";
    mysqli_query($connect, $query);
    $output .= '<td>'.$name.'</td>';
    $output .= '<td>'.$email.'</td>';
    $output .= '</tr>';
   }
  } 
  $output .= '</table>';
                
                
                $extension = pathinfo($_FILES["UploadFileField"]["name"], PATHINFO_EXTENSION);
		$UploadName = $subject.$semester.$attainment.$quizno.$class.$year.".".$extension;
		$UploadTmp = $_FILES['UploadFileField']['tmp_name'];
		$UploadType = $_FILES['UploadFileField']['type'];
		$FileSize = $_FILES['UploadFileField']['size'];
                
 

                $sql = "INSERT INTO file (filename) VALUES ('$UploadName')"; 
                mysqli_query($con, $sql);
		
		// Removes Unwanted Spaces and characters from the files names of the files being uploaded
		
		$UploadName = preg_replace("#[^a-z0-9.]#i", "", $UploadName);
		
		// Upload File Size Limit 
		
		if(($FileSize > 125000)){
			
			die("Error - File to Big");
			
		}
		
		// Checks a File has been Selected and Uploads them into a Directory on your Server
		
		if(!$UploadTmp){
			die("No File Selected, Please Upload Again");
		}else{
			move_uploaded_file($UploadTmp, "Upload/$name/$UploadName");
                        //echo "$name";
		}
	}
    }    
?>

