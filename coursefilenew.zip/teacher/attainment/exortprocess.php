<?php  
      //export.php  
session_start();
$email=$_SESSION["email"];
$year=$_SESSION["year"];
$class=$_SESSION["class"];
$semno=$_SESSION["semno"];
$quizno=$_SESSION["quizno"];
$subject=$_SESSION["subject"];

 if(isset($_POST["export"]))  
 {  
      $connect = mysqli_connect("localhost", "aartimka_course", "course_2018", "aartimka_course_file");  
      header('Content-Type: text/pdf; charset=utf-8');  
      header('Content-Disposition: attachment; filename=data.pdf');  
      $output = fopen("php://output", "w");  
      fputcsv($output, array('Qno', 'question', 'optionA', 'optionB', 'optionC', 'optionD','co_no'));  
      $query = "SELECT qno,question,optionA,optionB,optionC,optionD,co_no from addquestion where email='$email' and year='$year' and class='$class' and semno='$semno' and quizno='$quizno' and subject='$subject'";  
      $result = mysqli_query($connect, $query);  
      while($row = mysqli_fetch_assoc($result))  
      {  
           fputcsv($output, $row);  
      }  
      fclose($output);  
 }  
 ?>  
 
