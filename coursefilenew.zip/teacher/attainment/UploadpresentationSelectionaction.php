<?php
        session_start();
	include('db27.php');
        $name=$_SESSION['user_id'];
        
        $class=$_POST['class'];
        $subject=$_POST['subject'];
        $year=$_POST['year']; 
        $semester=$_POST['semester'];
        $presentationno=$_POST['presentationno'];
        //$attainment=$_POST['attainment'];
	$co=$_POST['co'];  
        
        //echo $class;
        //echo $subject;
        //echo $year;
        //echo $semester;
        //echo $presentationno;
        //echo $attainment;
        
        $_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
        $_SESSION['presentationno']=$presentationno;
        //$_SESSION['attainment']=$;
	$_SESSION['co']=$co;
		
        
        header("Location: studentlistuploadpresent.php");
?>