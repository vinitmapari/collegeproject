<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
</head>
<body>

<?php
require "teachmenu.php";
require "teachsidenav.php";
?>
  <div class="container">
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title"> MSE QUESTION PAPER Description </h1>
					</div>

  <div class="panel-body">
                    
						
<form class="form-horizontal" method="post" action="msepaperdescription_action.php" enctype="multipart/form-data">
						<br>
						  <div class="form-group">
  <label class="col-md-4 control-label" for="subject" style="text-align:center">Question No</label>  
  <div class="col-md-4">
  <input id="questionno" name="questionno" type="text" placeholder="questionno" class="form-control input-md" required>
    
  </div>
</div>
  
  
						<div class="form-group">
  <label class="col-md-4 control-label" for="subcode">SubQuestion No</label>  
  <div class="col-md-4">
  <input id="subquestion" name="subquestion" type="text" placeholder="" class="form-control input-md" required="">
  </div>
</div>

  <div class="form-group">
  <label class="col-md-4 control-label" for="subject" style="text-align:center">Enter Question</label>  
  <div class="col-md-4">
  <input id="question" name="question" type="text" placeholder="question" class="form-control input-md" required>
    
  </div>
</div>

  <div class="form-group">
  <label class="col-md-4 control-label" for="subject" style="text-align:center">Enter Question Marks</label>  
  <div class="col-md-4">
  <input id="questionmarks" name="questionmarks" type="text" placeholder="questionmarks" class="form-control input-md" required>
    
  </div>
</div>


<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" class="btn btn-default">Submit</button>
  </div>
</div>

<br>

</form>
  
</div>
</div><br><br>
</div>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>


<?php
require "footer.php";
?>
</body>
</html> 
