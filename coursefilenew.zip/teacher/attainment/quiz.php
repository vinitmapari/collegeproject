<?php
include("auth.php"); 
require 'db.php';
$email=$_SESSION["email"];
$sql=mysqli_query($con,"select *from user where email='$email'");

$s=mysqli_fetch_array($sql);

 ?>
<?php include 'Header.php';?>
<?php include 'navbarUser.php';?>
<br><br><br><br>
<?php include 'quizContent.php';?>
<br>
<?php include 'Footer.php';?>


       


