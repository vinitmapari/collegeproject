<?php
session_start(); 
require('db27.php');
$tid=$_SESSION['tid'] 
//$user=$_SESSION['user_id'];

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
<style>
.button {
  padding: 15px 45px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color:#D3D3D3;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
  
}

.button:hover {background-color:#B0C4DE; }

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
td{
    padding: 20px;
}
th{
    font-size: 24px;
    text-align: center;
}
</style>
  

</head>
<body>

<?php
require "teachmenu.php";
//require "addinfosidenav27.php";
?>

<?php
	
        $class=$_POST['class'];
        $subject=$_POST['subject'];
        $year=$_POST['year'];
        $semester=$_POST['semester'];
        $presentationno=$_POST['Presentationno'];
        //$attainment=$_POST['presentationno'];
        
      
        
        $_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
        $_SESSION['presentationno']=$presentationno;
        //$_SESSION['attainment']=$attainment;
        

$sql = "Insert into presentation(tid,class,subject,year,presentationno,semester)values($tid,'$class','$subject',$year,$presentationno,'$semester');";
$result = mysqli_query($con, $sql);

$sql1="select * from studentlist where class='$class' and year='$year';";
$result1 = mysqli_query($con, $sql1);



$Header = array('UCID', 'Name','presentation1','presentation2','presentation3','presentation4');
$data = array();

while($row = mysqli_fetch_array($result1))  
{ 
array_push($data, array($row["ucid"],$row["studentname"]));
}

$filename = write_excel1($data, $Header);


function write_excel1($data, $Header)
{
	//We are using PHPExcel Library for creating the Microsoft Excel file
	require_once  './PHPExcel1/Classes/PHPExcel.php';
	
	$objPHPExcel = new PHPExcel();
	//Activate the First Excel Sheet
	$ActiveSheet = $objPHPExcel->setActiveSheetIndex(0);
	
	
	//Write the Header
	$i=0;
	foreach($Header as $ind_el)
	{
		//Convert index to Excel compatible Location
		$Location = PHPExcel_Cell::stringFromColumnIndex($i) . '1';
		$ActiveSheet->setCellValue($Location, $ind_el);
		$i++;
	}
	
	//Insert that data from Row 2, Column A (index 0)
	$rowIndex=2;
	$columnIndex=0; //Column A
	foreach($data as $row)
	{			
		foreach($row as $ind_el)
		{
			$Location = PHPExcel_Cell::stringFromColumnIndex($columnIndex) . $rowIndex;
			//var_dump($Location);
			$ActiveSheet->setCellValue($Location, $ind_el); 	//Insert the Data at the specific cell specified by $Location
			$columnIndex++;
		}
		
		$rowIndex++;
		$columnIndex = 0;
	}		
	
        
        //sum
        /*$rowIndex = count($data) + 3;
	$Location = PHPExcel_Cell::stringFromColumnIndex(1) . $rowIndex;
	$ActiveSheet->setCellValue($Location, 'SUM'); 
	
	//Insert Average Formula -> AVERAGE(B2:B9)
	$start_row = 2;
	$end_row = count($data)+1;
	$formula = "=SUM(C" . $start_row . ":C" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
        
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=SUM(D" . $start_row . ":D" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(3) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
        
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=SUM(E" . $start_row . ":E" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(4) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
        
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=SUM(F" . $start_row . ":F" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(5) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        
        //count
        $rowIndex = count($data) + 4;
	$Location = PHPExcel_Cell::stringFromColumnIndex(1) . $rowIndex;
	$ActiveSheet->setCellValue($Location, 'COUNT'); 
	
	
	$start_row = 2;
	$end_row = count($data)+1;
	$formula = "=COUNT(C" . $start_row . ":C" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
        
        
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=COUNT(D" . $start_row . ":D" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(3) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
        
        
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=COUNT(E" . $start_row . ":E" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(4) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
        
        
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=COUNT(F" . $start_row . ":F" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(5) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
        
	
        
	//average
	//Compute Average by inserting Excel Formul
	$rowIndex = count($data) + 5;
	$Location = PHPExcel_Cell::stringFromColumnIndex(1) . $rowIndex;
	$ActiveSheet->setCellValue($Location, 'AVERAGE'); 
	
	//Insert Average Formula -> AVERAGE(B2:B9)
	$start_row = 2;
	$end_row = count($data)+1;
	$formula = "=AVERAGE(C" . $start_row . ":C" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
	$start_row = 2;
	$end_row = count($data)+1;
	$formula = "=AVERAGE(D" . $start_row . ":D" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(3) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = 2;
	$end_row = count($data)+1;
	$formula = "=AVERAGE(E" . $start_row . ":E" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(4) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = 2;
	$end_row = count($data)+1;
	$formula = "=AVERAGE(F" . $start_row . ":F" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(5) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
	//std.dev.   =ROUND(STDEV(C13:C69),2)
        $rowIndex = count($data) + 6;
	$Location = PHPExcel_Cell::stringFromColumnIndex(1) . $rowIndex;
	$ActiveSheet->setCellValue($Location, 'std.dev.'); 
	
	
	$start_row = 2;
	$end_row = count($data)+1;
	$formula = "=ROUND(STDEV(C" . $start_row . ":C" . $end_row  .  "),2)";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
	$start_row = 2;
	$end_row = count($data)+1;
	$formula = "=ROUND(STDEV(D" . $start_row . ":D" . $end_row  .  "),2)";
        $Location = PHPExcel_Cell::stringFromColumnIndex(3) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = 2;
	$end_row = count($data)+1;
	$formula = "=ROUND(STDEV(E" . $start_row . ":E" . $end_row  .  "),2)";
        $Location = PHPExcel_Cell::stringFromColumnIndex(4) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = 2;
	$end_row = count($data)+1;
	$formula = "=ROUND(STDEV(F" . $start_row . ":F" . $end_row  .  "),2)";
        $Location = PHPExcel_Cell::stringFromColumnIndex(5) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	 
        //Upper Range = Avg.+std
        
	$rowIndex = count($data) + 7;
	$Location = PHPExcel_Cell::stringFromColumnIndex(1) . $rowIndex;
	$ActiveSheet->setCellValue($Location, 'Upper Range = Avg.+std'); 
	
	
	$start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=C" . $start_row . "+C" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
	$start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=D" . $start_row . "+D" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(3) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=E" . $start_row . "+E" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(4) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=F" . $start_row . "+F" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(5) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
       
        //Lower Range = Avg. - std
        
	$rowIndex = count($data) + 8;
	$Location = PHPExcel_Cell::stringFromColumnIndex(1) . $rowIndex;
	$ActiveSheet->setCellValue($Location, 'Lower Range = Avg. - std'); 
	
	
	$start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=C" . $start_row . "-C" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
	$start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=D" . $start_row . "-D" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(3) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=E" . $start_row . "-E" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(4) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=F" . $start_row . "-F" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(5) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
       
        //No. of Students in (Upper to Lower )range   =COUNTIFS(C13:C69,">="&ROUND(C76,0),C13:C69,"<="&ROUND(C75,0))
        
	/*$rowIndex = count($data) + 9;
	$Location = PHPExcel_Cell::stringFromColumnIndex(1) . $rowIndex;
	$ActiveSheet->setCellValue($Location, 'No. of Students in (Upper to Lower )range'); */
	
	/*$Location
	$start_row1 = count($data) + 5;
	$end_row1 = count($data)+6;
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=COUNTIFS(C" . $start_row . ":C" . $end_row  . ">=&"."ROUND(C".$start_row1.",0),C".$start_row . ":C" . $end_row  . ",<=&"."ROUND(C".$start_row1.",0))";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);

	$start_row1 = count($data) + 5;
	$end_row1 = count($data)+6;
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=COUNTIFS(C" . $start_row . ":D" . $end_row  . ">=&ROUND(D".$start_row1.",0),D".$start_row . ":D" . $end_row  . ",<=&ROUND(D".$start_row1.",0))";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row1 = count($data) + 5;
	$end_row1 = count($data)+6;
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=COUNTIFS(E" . $start_row . ":E" . $end_row  . ">=&ROUND(E".$start_row1.",0),E".$start_row . ":E" . $end_row  . ",<=&ROUND(E".$start_row1.",0))";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
		
        $start_row1 = count($data) + 5;
	$end_row1 = count($data)+6;
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=COUNTIFS(F" . $start_row . ":F" . $end_row  . ">=&ROUND(F".$start_row1.",0),F".$start_row . ":F" . $end_row  . ",<=&ROUND(F".$start_row1.",0))";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	*/
	########### Optional    ##################
	########### Cell -Style ##################
	
	//1. Mark the Header Row  in Color Red
       
	$Range = 'A1:B1';
	$color = 'FFFF0000';
	$ActiveSheet->getStyle($Range)->getFill($Range)->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB($color);
	
	//2. Set the Column Width
	
	for($i=0; $i<count($Header);$i++)
	{
		$Location = PHPExcel_Cell::stringFromColumnIndex($i) ;
		$ActiveSheet->getColumnDimension($Location)->setAutoSize(true);	
	}
	
	
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	
	
	
	
	//Pre-requisites - Optional - Modify it as per your requirement
	$properties =  $objPHPExcel->getProperties();
	$properties->setCreator("SapnaEdu"); //Creator Name
	$properties->setLastModifiedBy("SapnaEdu");
	
	//Pre-requisites - Optional - Modify it as per your requirement
	$properties->setTitle("Report Generated by Sapnaedu");
	$properties->setSubject("Report Generated by Sapnaedu");
	$properties->setDescription("Report Generated by Sapnaedu");
	$properties->setKeywords("Excel Member Report");
	$properties->setCategory("Member Report");

	

	//Result File name
        $name1=$_SESSION['name'];
	$randno = rand(100000, 999999);

	$fileName = "$name1" . $randno . ".xlsx";
	$folder = "Result";

	//Create the Result Directory if Directory is not created already
	if (!file_exists($folder))
		mkdir($folder);

	$fullpath = $folder . '/' . $fileName;

	$objWriter->save($fullpath);
	
	return $fullpath;
	
}


	
header('Location: exportrawmsg.php');

?>
 

<?php
require "footer.php";
?> 
</body>
</html> 
 