<?php include 'db.php';?>
<?php include 'Header.php';?>
<?php
include("auth.php"); 
require 'db.php';
$email=$_SESSION["email"];

$sql=mysqli_query($con,"select *from user where email='$email'");

$s=mysqli_fetch_array($sql);
$_SESSION['name']=$s['name'];

 ?>
<?php include 'navbarPresentation.php';?>
<?php
	include('db.php');
      
        $class=$_POST['class'];
        $subject=$_POST['subject'];
        $year=$_POST['year'];
        $semester=$_POST['semester'];
        $attainment=$_POST['Presentationno'];
        //=$_POST['attainment'];
        
        $_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
        //$_SESSION['quizno']=$quizno;
        $_SESSION['attainment']=$attainment;
        
$connect = mysqli_connect("localhost:3308", "root", "", "mca");
$sql = "SELECT * FROM sdetail where class='$class' and subject='$subject' and year='$year' and semester='$semester'";
$result = mysqli_query($connect, $sql);
?>

<br><br><br><br><br> 
  <div class="container">  
   <br />  
   <br />  
   <br />  
   <div class="table-responsive">  
       <table border="0">
           <tr>
               <td><img src="img/spitlogo.png" width="100"></td>
               <td colspan="4"> <h1>______Sardar Patel Institute of Technology_____ </h1></td>
       </tr>
       <tr>
           <?php
          echo' 
           <td></td>
           <td>Subject='.$subject.'</td><td>  Class='.$class.'</td>
           <td>year='.$year.'</td>
           <td>attainment='.$attainment.'</td>'?>
       </tr>
       </table>
    <h2 align="center">Student Deatils </h2><br /> 
    <table class="table table-bordered">
     <tr>  
                         <th>Name</th>  
                         <th>UCID</th>  
                         <th>Presentation1</th> 
						 <th>Presentation2</th>
						 <th>Presentation3</th>
						 <th>Presentation4</th>
                                                 <th>Total</th>
                                                 
                    </tr>
     
    <?php
    //row addition
     $count=0;
     $quiztotal=0;
     while($row = mysqli_fetch_array($result))  
     {  
         
         $Presentation1=$row["Presentation1"]+$row["Presentation2"]+$row["Presentation3"]+$row["Presentation4"];
        echo '  
       <tr>  
         <td>'.$row["name"].'</td>  
         <td>'.$row["UCID"].'</td>  
         <td>'.$row["Presentation1"].'</td>  
		 <td>'.$row["Presentation2"].'</td> 
		 <td>'.$row["Presentation3"].'</td> 
		 <td>'.$row["Presentation4"].'</td> 
                 <td>'.$Presentation1.'</td> 
   
       </tr>  
        ';  
        if($quiz1!=0)
        {
            $count++;
        }
        $presentationtotal=$presentationtotal+$Presentation1;
     }
     ?>
                   
    </table>
     <h4>RESULT ANALYSIS FOR ATTAINMENT USING STANDARD DEVIATION				
</h4>
    <?php 
    //column addtion
        $sql = "SELECT Presentation1,Presentation2,Presentation3,Presentation4 FROM pdetail where class='$class' and subject='$subject' and year='$year' and semester='$semester'";
        $result = mysqli_query($connect, $sql);
    ?>
    <?php
    //row addition
     $Presentation1=0;
     $Presentation3=0;
     $Presentation5=0;
     $Presentation7=0;
      $countPresentation1=0;
       $countPresentation2=0;
        $countPresentation3=0;
         $countPresentation4=0;
         
     while($row = mysqli_fetch_array($result))  
     {  
         
         $Presentation2=$row["Presentation1"];
        
         if($Presentation2!=0)
         {
             $countPresentation1= $countPresentation1+1;
         }
         $Presentation1=$Presentation1+$Presentation2;
         
          $Presentation4=$row["Presentation2"];
         
         if($Presentation4!=0)
         {
             $countPresentation2++;
         }
         $Presentation3=$Presentation3+$Presentation4;
         
          $Presentation6=$row["Presentation3"];
         
         if($Presentation6!=0)
         {
             $countPresentation3++;
         }
         $Presentation5=$Presentation5+$Presentation6;
         
          $Presentation8=$row["Presentation4"];
         
         if($Presentation8!=0)
         {
             $countPresentation4++;
         }
         $Presentation7=$Presentation7+$Presentation8;
        
     }
     ?>
    <table class="table table-bordered">
         <tr>  
                         			 <th>sum</th>
						 <th>Presentation1</th>
						 <th>Presentation2</th>
                                                 <th>Presentation3</th>
                                                 <th>Presentation4</th>
                                                 <th>total</th>
                    </tr>
  <?php
     echo '  
       <tr>  
         <td>Sum</td>  
         <td>'.$Presentation1.'</td>
             <td>'.$Presentation3.'</td>
                 <td>'.$Presentation5.'</td>
                     <td>'.$Presentation7.'</td>
         <td>'.$Presentationtotal.'</td>  
   
       </tr>  
       <tr>  
         <td>No of students</td>  
         <td>'.$countPresentation1.'</td>
             <td>'.$countPresentation2.'</td>
                 <td>'.$countPresentation3.'</td>
                     <td>'.$countPresentation4.'</td>
         <td>'.$count.'</td>  
   
       </tr>  
       
       <tr>  
         <td>Avg</td>  
         <td>'.$Presentation1/$countPresentation1.'</td>
             <td>'.$Presentation3/$countPresentation2.'</td>
                 <td>'.$Presentation5/$countPresentation3.'</td>
                     <td>'.$Presentation7/$countPresentation4.'</td>
         <td>'.$Presentationtotal/$count.'</td>  
   
       </tr>  
        ';  
     
     
     ?>
    </table>
    <br />
    <!--<form method="post" action="export-student.php">
     <input type="submit" name="export" class="btn btn-success" value="Export" />
    </form>-->
   </div>  
  </div>  
<br>

<a href="..//Mcadepartment/pdfoop.php">Click here to download PDF</a>


 <?php include 'Footer.php';?>
 