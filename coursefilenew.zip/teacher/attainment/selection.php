<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
<style>
.button {
  padding: 15px 45px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color:#D3D3D3;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
  
}

.button:hover {background-color:#B0C4DE; }

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
td{
    padding: 20px;
}
th{
    font-size: 24px;
    text-align: center;
}
</style>
  

</head>
<body>

<?php
require "teachmenu.php";
//require "addinfosidenav27.php";
?>
    <table>
        <tr>
            <th>Download</th>
            <th>Upload</th>
            <th>Calculate</th>
        </tr>
        <tr>
            <td><a href="Downloadquizselection.php"><button class="button">Quiz Attainment</button></a></td>
            <td><a href="UploadQuizSelection.php"><button class="button">Quiz Attainment with marks</button></a></td>
            <td><a href="CalculateQuizSelection.php"><button class="button">Quiz Attainment</button></a></td>
        </tr>
        <tr>
            <td><a href="Downloadassignmentselection.php"><button class="button">Assignment Attainment</button></a></td>
            <td><a href="UploadassignmentSelection.php"><button class="button">Assignment Attainment with marks</button></a></td>
            <td><a href="CalculateassignmentSelection.php"><button class="button">Assignment Attainment</button></a></td>
        </tr>
        <tr>
            <td><a href="DownloadpresentationSelection.php"><button class="button">Presentation Attainment</button></a></td>
            <td><a href="UploadPresentationSelection.php"><button class="button">Presentation Attainment with marks</button></a></td>
            <td><a href="CalculatePresentationSelection.php"><button class="button">Presentation Attainment</button></a></td>
        </tr>
         <tr>
             <td><a href="DownloadMSEselection.php"><button class="button">MSE Attainment</button></a></td>
            <td><a href="UploadMSESelection.php"><button class="button">MSE Attainment with marks-calculation</button></a></td>
            
        </tr>
         <tr>
            <td><a href="DownloadESESelection.php"><button class="button">ESE Attainment</button></a></td>
            <td><a href="UploadESESelection.php"><button class="button">ESE Attainment with marks-calulation</button></a></td>
       
            <td rowspan="3"><a href="CalculateAverageSelection.php"><button class="button">Calculate final attainment</button></a></td>
        </tr>
      
    </table>
    



<?php

?> 
</body>
</html> 
