<?php

                        session_start();
                        require('db27.php');
                     
                        $tid=$_SESSION["tid"];
                        $class=$_POST['class'];
                        $subjectid=$_POST['subjectid'];
                        $year=$_POST['year'];
                        $totalmarks=$_POST['totalmarks'];
            
                        $_SESSION["class"] = "$class";
                        $_SESSION["subject"] = "$subjectid";
                        $_SESSION["year"] = "$year";
                        $_SESSION["totalmarks"] = "$totalmarks";
                        
                  
$sql = "INSERT INTO  msequestionpaper(subjectid,year,class,totalmarks,tid)VALUES($subjectid,$year,'$class',$totalmarks,$tid);";

if(mysqli_query($con, $sql)){  
  echo "Record inserted successfully"; 
}else{  
echo "Could not insert record: ". mysqli_error($con);  
}  
  
 $query = "select * from msequestionpaper where subjectid='$subjectid' and year='$year' and  class='$class' and  totalmarks='$totalmarks'";
 $results = mysqli_query($con,$query);

 while ($rows = mysqli_fetch_assoc($results)){ 
       $msequestionpaperid=$rows['idmsequestionpaper'];                     
 }     
 
 $_SESSION["msequestionpaperid"] = "$msequestionpaperid";
 header('Location: msepaperdescription.php'); 
 ?>
