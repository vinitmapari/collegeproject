<?php include 'db.php';?>
<?php include 'Header.php';?>
<?php
include("auth.php"); 
require 'db.php';
$email=$_SESSION["email"];

$sql=mysqli_query($con,"select *from user where email='$email'");

$s=mysqli_fetch_array($sql);
$_SESSION['name']=$s['name'];

 ?>
<?php include 'navbarESE.php';?>
<?php
	include('db.php');
      
        $class=$_POST['class'];
        $subject=$_POST['subject'];
        $year=$_POST['year'];
        $semester=$_POST['semester'];
        $attainment=$_POST['attainment'];
        
        $_SESSION['class']=$class;
        $_SESSION['subject']=$subject;
        $_SESSION['year']=$year;
        $_SESSION['semester']=$semester;
        $_SESSION['attainment']=$attainment;
        
$connect = mysqli_connect("localhost", "root", "", "mca");
$sql = "SELECT * FROM esedetail where class='$class' and subject='$subject' and year='$year' and semester='$semester'";
$result = mysqli_query($connect, $sql);
?>
<?php
$Header = array('Name', 'UCID','sem1','sem2','sem3','sem4','sem5');
$data = array();

while($row = mysqli_fetch_array($result))  
{ 
array_push($data, array($row["name"],$row["UCID"],$row["sem1"],$row["sem2"],$row["sem3"],$row["sem4"],$row["sem5"]));
}

$filename = write_excel1($data, $Header);


function write_excel1($data, $Header)
{
	//We are using PHPExcel Library for creating the Microsoft Excel file
	require_once  './PHPExcel1/Classes/PHPExcel.php';
	
	$objPHPExcel = new PHPExcel();
	//Activate the First Excel Sheet
	$ActiveSheet = $objPHPExcel->setActiveSheetIndex(0);
	
	
	//Write the Header
	$i=0;
	foreach($Header as $ind_el)
	{
		//Convert index to Excel compatible Location
		$Location = PHPExcel_Cell::stringFromColumnIndex($i) . '1';
		$ActiveSheet->setCellValue($Location, $ind_el);
		$i++;
	}
	
	//Insert that data from Row 2, Column A (index 0)
	$rowIndex=2;
	$columnIndex=0; //Column A
	foreach($data as $row)
	{			
		foreach($row as $ind_el)
		{
			$Location = PHPExcel_Cell::stringFromColumnIndex($columnIndex) . $rowIndex;
			//var_dump($Location);
			$ActiveSheet->setCellValue($Location, $ind_el); 	//Insert the Data at the specific cell specified by $Location
			$columnIndex++;
		}
		
		$rowIndex++;
		$columnIndex = 0;
	}		
	
        
        //sum
        $rowIndex = count($data) + 3;
	$Location = PHPExcel_Cell::stringFromColumnIndex(1) . $rowIndex;
	$ActiveSheet->setCellValue($Location, 'SUM'); 
	
	//Insert Average Formula -> AVERAGE(B2:B9)
	$start_row = 2;
	$end_row = count($data)+1;
	$formula = "=SUM(C" . $start_row . ":C" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
        
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=SUM(D" . $start_row . ":D" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(3) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
        
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=SUM(E" . $start_row . ":E" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(4) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
        
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=SUM(F" . $start_row . ":F" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(5) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        
        //count
        $rowIndex = count($data) + 4;
	$Location = PHPExcel_Cell::stringFromColumnIndex(1) . $rowIndex;
	$ActiveSheet->setCellValue($Location, 'COUNT'); 
	
	
	$start_row = 2;
	$end_row = count($data)+1;
	$formula = "=COUNT(C" . $start_row . ":C" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
        
        
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=COUNT(D" . $start_row . ":D" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(3) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
        
        
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=COUNT(E" . $start_row . ":E" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(4) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
        
        
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=COUNT(F" . $start_row . ":F" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(5) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
        
	
        
	//average
	//Compute Average by inserting Excel Formul
	$rowIndex = count($data) + 5;
	$Location = PHPExcel_Cell::stringFromColumnIndex(1) . $rowIndex;
	$ActiveSheet->setCellValue($Location, 'AVERAGE'); 
	
	//Insert Average Formula -> AVERAGE(B2:B9)
	$start_row = 2;
	$end_row = count($data)+1;
	$formula = "=AVERAGE(C" . $start_row . ":C" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
	$start_row = 2;
	$end_row = count($data)+1;
	$formula = "=AVERAGE(D" . $start_row . ":D" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(3) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = 2;
	$end_row = count($data)+1;
	$formula = "=AVERAGE(E" . $start_row . ":E" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(4) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = 2;
	$end_row = count($data)+1;
	$formula = "=AVERAGE(F" . $start_row . ":F" . $end_row  .  ")";
        $Location = PHPExcel_Cell::stringFromColumnIndex(5) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
	//std.dev.   =ROUND(STDEV(C13:C69),2)
        $rowIndex = count($data) + 6;
	$Location = PHPExcel_Cell::stringFromColumnIndex(1) . $rowIndex;
	$ActiveSheet->setCellValue($Location, 'std.dev.'); 
	
	
	$start_row = 2;
	$end_row = count($data)+1;
	$formula = "=ROUND(STDEV(C" . $start_row . ":C" . $end_row  .  "),2)";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
	$start_row = 2;
	$end_row = count($data)+1;
	$formula = "=ROUND(STDEV(D" . $start_row . ":D" . $end_row  .  "),2)";
        $Location = PHPExcel_Cell::stringFromColumnIndex(3) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = 2;
	$end_row = count($data)+1;
	$formula = "=ROUND(STDEV(E" . $start_row . ":E" . $end_row  .  "),2)";
        $Location = PHPExcel_Cell::stringFromColumnIndex(4) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = 2;
	$end_row = count($data)+1;
	$formula = "=ROUND(STDEV(F" . $start_row . ":F" . $end_row  .  "),2)";
        $Location = PHPExcel_Cell::stringFromColumnIndex(5) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	 
        //Upper Range = Avg.+std
        
	$rowIndex = count($data) + 7;
	$Location = PHPExcel_Cell::stringFromColumnIndex(1) . $rowIndex;
	$ActiveSheet->setCellValue($Location, 'Upper Range = Avg.+std'); 
	
	
	$start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=C" . $start_row . "+C" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
	$start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=D" . $start_row . "+D" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(3) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=E" . $start_row . "+E" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(4) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=F" . $start_row . "+F" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(5) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
       
        //Lower Range = Avg. - std
        
	$rowIndex = count($data) + 8;
	$Location = PHPExcel_Cell::stringFromColumnIndex(1) . $rowIndex;
	$ActiveSheet->setCellValue($Location, 'Lower Range = Avg. - std'); 
	
	
	$start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=C" . $start_row . "-C" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
	$start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=D" . $start_row . "-D" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(3) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=E" . $start_row . "-E" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(4) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row = count($data) + 5;
	$end_row = count($data)+6;
	$formula = "=F" . $start_row . "-F" . $end_row  . "";
        $Location = PHPExcel_Cell::stringFromColumnIndex(5) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
       
        //No. of Students in (Upper to Lower )range   =COUNTIFS(C13:C69,">="&ROUND(C76,0),C13:C69,"<="&ROUND(C75,0))
        
	/*$rowIndex = count($data) + 9;
	$Location = PHPExcel_Cell::stringFromColumnIndex(1) . $rowIndex;
	$ActiveSheet->setCellValue($Location, 'No. of Students in (Upper to Lower )range'); */
	
	/*$Location
	$start_row1 = count($data) + 5;
	$end_row1 = count($data)+6;
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=COUNTIFS(C" . $start_row . ":C" . $end_row  . ">=&"."ROUND(C".$start_row1.",0),C".$start_row . ":C" . $end_row  . ",<=&"."ROUND(C".$start_row1.",0))";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);

	$start_row1 = count($data) + 5;
	$end_row1 = count($data)+6;
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=COUNTIFS(C" . $start_row . ":D" . $end_row  . ">=&ROUND(D".$start_row1.",0),D".$start_row . ":D" . $end_row  . ",<=&ROUND(D".$start_row1.",0))";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	
        $start_row1 = count($data) + 5;
	$end_row1 = count($data)+6;
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=COUNTIFS(E" . $start_row . ":E" . $end_row  . ">=&ROUND(E".$start_row1.",0),E".$start_row . ":E" . $end_row  . ",<=&ROUND(E".$start_row1.",0))";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
		
        $start_row1 = count($data) + 5;
	$end_row1 = count($data)+6;
        $start_row = 2;
	$end_row = count($data)+1;
        $formula = "=COUNTIFS(F" . $start_row . ":F" . $end_row  . ">=&ROUND(F".$start_row1.",0),F".$start_row . ":F" . $end_row  . ",<=&ROUND(F".$start_row1.",0))";
        $Location = PHPExcel_Cell::stringFromColumnIndex(2) . $rowIndex;
	$ActiveSheet->setCellValue($Location, $formula);
	*/
	########### Optional    ##################
	########### Cell -Style ##################
	
	//1. Mark the Header Row  in Color Red
	$Range = 'A1:B1';
	$color = 'FFFF0000';
	$ActiveSheet->getStyle($Range)->getFill($Range)->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB($color);
	
	//2. Set the Column Width
	
	for($i=0; $i<count($Header);$i++)
	{
		$Location = PHPExcel_Cell::stringFromColumnIndex($i) ;
		$ActiveSheet->getColumnDimension($Location)->setAutoSize(true);	
	}
	
	
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	
	
	
	
	//Pre-requisites - Optional - Modify it as per your requirement
	$properties =  $objPHPExcel->getProperties();
	$properties->setCreator("SapnaEdu"); //Creator Name
	$properties->setLastModifiedBy("SapnaEdu");
	
	//Pre-requisites - Optional - Modify it as per your requirement
	$properties->setTitle("Report Generated by Sapnaedu");
	$properties->setSubject("Report Generated by Sapnaedu");
	$properties->setDescription("Report Generated by Sapnaedu");
	$properties->setKeywords("Excel Member Report");
	$properties->setCategory("Member Report");

	

	//Result File name
        $name1=$_SESSION['name'];
	$randno = rand(100000, 999999);

	$fileName = "$name1" . $randno . ".xlsx";
	$folder = "ResultESE";

	//Create the Result Directory if Directory is not created already
	if (!file_exists($folder))
		mkdir($folder);

	$fullpath = $folder . '/' . $fileName;

	$objWriter->save($fullpath);
	
	return $fullpath;
	
}


	
header('Location: ESEexportrawmsg.php');

?>

 <?php include 'Footer.php';?>
 