<?php  
      //export.php  
session_start();
$email=$_SESSION["email"];
$year=$_SESSION["year"];
$class=$_SESSION["class"];
$semno=$_SESSION["semno"];
$subject=$_SESSION["subject"];

 if(isset($_POST["export"]))  
 {  
      $connect = mysqli_connect("localhost", "root", "", "mca");  
      header('Content-Type: text/csv; charset=utf-8');  
      header('Content-Disposition: attachment; filename=data.csv');  
      $output = fopen("php://output", "w");  
      fputcsv($output, array('Qno', 'question','co_no'));  
      $query = "SELECT qno,question,co_no from addmseques where email='$email' and year='$year' and class='$class' and semno='$semno' and subject='$subject'";  
      $result = mysqli_query($connect, $query);  
      while($row = mysqli_fetch_assoc($result))  
      {  
           fputcsv($output, $row);  
      }  
      fclose($output);  
 }  
 ?>  