<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "theader.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
<style>
.button {
  padding: 15px 45px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color:#D3D3D3;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
  
}

.button:hover {background-color:#B0C4DE; }

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
td{
    padding: 20px;
}
th{
    font-size: 24px;
    text-align: center;
}
</style>
  

</head>
<body>

<?php
require "teachmenu.php";
//require "addinfosidenav27.php";
?>
    <form class="form-horizontal" action="DownloadMSEselectionaction.php" method="POST">
    
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            
           <div class="panel panel-default">
                <div class="panel-heading">Please select following </div>

                <div class="panel-body">
                   
                      
                        
                        

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">Class</label>

                            <div class="col-md-6">
                                <select class="form-control" id="LoginType" name="class">
                                    <option value="FY">Fy</option>
                                    <option value="SY">Sy</option>
                                    <option value="TY">Ty</option>
                                </select>

                                
                                    <span class="help-block">
                                       <strong></strong>
                                    </span>
                                
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Subject</label>

                            <div class="col-md-6">
                               
                                    <select name="subject"  class="form-control">
 <?Php 
 require "db27.php";
 $query = "select * from subject";
 $results = mysqli_query($con,$query);

    while ($rows = mysqli_fetch_assoc(@$results)){ 
    ?>
                                        
      <option value="<?php echo $rows['idsubject'];?>"><?php echo $rows['subjectname'];?></option>
	 
 <?php
 
    } 
    
 ?>
 
                                    </select>
                                    
                              
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>


                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">Year</label>

                            <div class="col-md-6">
                                <select class="form-control" id="LoginType" name="year">
                                    <option value="2018">2018</option>
                                    <option value="2017">2017</option>
                                    
                                </select>

                                
                                    <span class="help-block">
                                       <strong></strong>
                                    </span>
                                
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Semester</label>

                            <div class="col-md-6">
                               
                                    <select name="semester" size="1" class="form-control">
                                        <option selected="selected" value="">Semno</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                    </select>
                             
                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>
                   
                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                               
                                <input type="submit" class="btn-primary">
                                                                
                            </div>
                        </div>
                   
                </div>
            </div>
       
        </div>
    </div>
</div>
</form>



<?php

?> 
</body>
</html> 
