<?php
        session_start();
	include('db.php');
        $name=$_SESSION['user_id'];
        $tid=$_SESSION['tid'];
        //echo $tid;
        $class=$_POST['class'];
        //echo $class;
        $subject=$_POST['subject'];
        //echo $subject;
        $year=$_POST['year'];
        //echo $year;
        $semester=$_POST['semester'];
         
        
        echo $class;
        echo $subject;
        echo $year;
        echo $semester;
        //echo $quizno;
        //echo $attainment;
   $sql8="select * from subject where idsubject=$subject";
     $result=mysqli_query($con, $sql8);
    while($row = mysqli_fetch_assoc($result)) {
		$subjectname = $row['subjectname'];
		}  
        
   echo $subjectname;
   
   $sql11="select * from quiz where class='$class' and subjectid='$subjectname' and year='$year' and semester='$semester' and tid=$tid ";
     $result=mysqli_query($con, $sql11);
    while($row = mysqli_fetch_assoc($result)) {
		$quizid = $row['idquiz'];
		}

   /* $sql12="select * from assignment where class='$class' and subjectid=$subjectname and year=$year and semester=$semester and tid=$tid ";
     $result=mysqli_query($con, $sql12);
    while($row = mysqli_fetch_assoc($result)) {
		$assignmentid = $row['idassignment'];
		}

    $sql13="select * from presentation where class='$class' and subjectid=$subjectname and year=$year and semester=$semester and tid=$tid ";
     $result=mysqli_query($con, $sql13);
    while($row = mysqli_fetch_assoc($result)) {
		$presentationid = $row['idpresentation'];
		}
*/
  echo $quizid;
 // echo $assignmentid;
 // echo $presentationid;
  
  $sql14="select * from quizattainment where quizid=$quizid ";
     $result=mysqli_query($con, $sql1);
    while($row = mysqli_fetch_assoc($result)) {
		$idquizattainment = $row['idquizattainment'];
		}
   echo $idquizattainment;
  /*            
  $sql15="select * from assignmentattainment where assignmentid=$assignmentid ";
     $result=mysqli_query($con, $sql1);
    while($row = mysqli_fetch_assoc($result)) {
		$idassignmentattainment = $row['idassignmentattainment'];
		}
          
  $sql16="select * from presentationattainment where presentationid=$presentationid ";
     $result=mysqli_query($con, $sql1);
    while($row = mysqli_fetch_assoc($result)) {
		$idpresentationattainment = $row['idpresentationattainment'];
		}
                            

  $sql1 = "SELECT * FROM ISEattainmentAssignment where idassignmentattainment='$idassignmentattainment'";
     $result1 = mysqli_query($con, $sql1);
     
     while($row1 = mysqli_fetch_array($result1))  
     {  
         $idassignmentattainment=$row1['idassignmentattainment'];
         $aco1=$row1['CO1'];
         $aco2=$row1['CO2'];
         $aco3=$row1['CO3'];
         $aco4=$row1['CO4'];
        
     }
     ///////////////////////////////////////////////////////////////////////////////////////////////////////
     $sql2 = "SELECT * FROM ISEattainmentQuiz where idassignmentattainment='$idquizattainment'";
     $result2 = mysqli_query($con, $sql2);
     
     while($row2 = mysqli_fetch_array($result2))  
     {  
         $idquizattainment=$row1['idquizattainment'];
         $qco1=$row2['CO1'];
         $qco2=$row2['CO2'];
         $qco3=$row2['CO3'];
         $qco4=$row2['CO4'];
        
     }
     ////////////////////////////////////////////////////////////////////////////////////////////////////////
     $sql1 = "SELECT * FROM ISEattainmentPresentation where idpresentationattainment='$idpresentationattainment'";
     $result1 = mysqli_query($con, $sql1);
     
     while($row1 = mysqli_fetch_array($result1))  
     {  
         $idpresentationattainment=$row1['idpresentationattainment'];
         $pco1=$row1['CO1'];
         $pco2=$row1['CO2'];
         $pco3=$row1['CO3'];
         $pco4=$row1['CO4'];
        
     }
 /////////////////////////////////////////////////////////////////////////////////////////////////////////
 
     $average_co1=($aco1+$qco1+$pco1)/4;
     $average_co2=($aco2+$qco2+$pco2)/4;
     $average_co3=($aco3+$qco3+$pco3)/4;
     $average_co4=($aco4+$qco4+$pco4)/4;
     
     $query1 = "Insert into AverageISEAttainment(CO1,CO2,CO3,CO4,ISEattainmentQuiz,ISEattainmentAttainment,ISEattainmentPresentation)values('$average_co1','$average_co2','$average_co3','$average_co4',$idquizattainment,$idassignmentattainment, $idpresentationattainment)";
     mysqli_query($con, $query1);
    */ 
     $iseco=Array('CO1','CO2','CO3','CO4');
     $isecoavgmarks=Array('5','7.26','8.26','9.56');
     $isecoquemarks=Array('5','10','10','10');
     
     
     $mseco=Array('CO1','CO2','CO3','CO4');
     $msecoavgmarks=Array('5','7.26','8.26','9.56');
     $msecoquemarks=Array('5','5','5','5');
     
     
     $eseco=Array('CO1','CO2','CO3','CO4');
     $esecoavgmarks=Array('9.39','13.5','12.41','0.89');
     $esecoquemarks=Array('20','20','20','20');
     
     
     $totalisemarks=Array();
     $totalmsemarks=Array();
     $totalesemarks=Array();
     
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Attainment</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Attainment</h2>
 
  <table class="table">
    <thead>
      <tr>
        <th>CL</th>
        <th>IE</th>
        <th>MSE</th>
        <th>ESE</th>
        <th>Average</th>
      </tr>
    </thead>
    <tbody>
<?Php  
for($i=0;$i<sizeof($iseco);$i++){

?>
      <tr>
        <td><?Php echo $iseco[$i];?></td> 
        <td><?Php echo $isecoavgmarks[$i]/$isecoquemarks[$i];?></td>
        <td><?Php echo $msecoavgmarks[$i]/$msecoquemarks[$i];?></td>
        <td><?Php echo $esecoavgmarks[$i]/$esecoquemarks[$i];?></td>
        <?php  
                
        ?>
        <td><?Php $total=$isecoavgmarks[$i]+$msecoavgmarks[$i]+$esecoavgmarks[$i];
                    $totalno=$isecoquemarks[$i]+$msecoquemarks[$i]+$esecoquemarks[$i];
                    
                    echo $total/$totalno;
                
                ;?></td>
      </tr>
<?Php }   ?>     
    </tbody>
  </table>
</div>

<?Php 
$isepercentage=Array('100','46','80','98.04');
$msepercentage=Array('56.17','44.96','80','98.04');
$esepercentage=Array('36.96','60.46','60.80','55.04');
$directattainment=Array();
?>    
    
    
<div class="container">
  <h2>VI.COMPUTATION OF CO DIRECT ATTAINMENT IN THE COURSE STRENGTH OF MATERIALS</h2>
 
  <table class="table">
    <thead>
      <tr>
        <th>CL</th>
        <th>IE</th>
        <th>MSE</th>
        <th>ESE</th>
        <th>Direct CO Attainment
(0.10 IE Cl. Avg.) + (0.30*MSE Cl. Avg.)+ (0.60*ESE Cl. Avg.)</th>
      </tr>
    </thead>
    <tbody>
<?Php  
for($i=0;$i<sizeof($iseco);$i++){

?>
      <tr>
        <td><?Php echo $iseco[$i];?></td> 
        <td><?Php echo $isepercentage[$i];?></td>
        <td><?Php echo $msepercentage[$i];?></td>
        <td><?Php echo $esepercentage[$i];?></td>
        
        <td><?Php 
        $isetotal=0.1*(float)$isepercentage[$i];
        //echo $isetotal;
        $msetotal=0.3*(float)$msepercentage[$i];
        //echo $msetotal;
        $esetotal=0.6*(float)$esepercentage[$i];
        //echo $esetotal;
        $total=$isetotal+$msetotal+$esetotal;
                    
           $directattainment[$i]=$total;         
                   echo $total;
                
                ;?></td>
      </tr>
<?Php }   ?>     
    </tbody>
  </table>
</div>
    
<div class="container">
  <h2>VII.CO ATTAINMENT AND ATTAINMENT GAP /MODIFICATION OF TARGET WHERE ACHIEVED</h2>
 
  <table class="table">
    <thead>
      <tr>
        <th>CL</th>
        <th>Direct Co attainment</th>
        <th>CO target</th>
        <th>CO Attainment gap</th>
        <th>Required to Modify target Yes/No</th>
      </tr>
    </thead>
    <tbody>
<?Php  
for($i=0;$i<sizeof($iseco);$i++){

?>
      <tr>
        <td><?Php echo $iseco[$i];?></td> 
        <td><?Php echo $directattainment[$i];?></td>
        <td>60</td>
        <td><?Php $gap=60-(float)$directattainment[$i];
                    echo $gap;
        ?></td>
        
        <td><?Php 
                    if($gap>0)
                    {
                        echo 'yes';
                    }
                   else{
                       echo 'no';
                   }
                
                ;?></td>
      </tr>
<?Php }   ?>     
    </tbody>
  </table>
</div>
    
<div class="container">
  <h2>VIII.PO ATTAINMENT (DIRECT METHOD)</h2>
 
  <table class="table">
    <thead>
      <tr>
        <th>CO</th>
        <th>Description</th>
        <th>Attainment</th>
       </tr>
    </thead>
    <tbody>
<?Php  
 


for($i=0;$i<sizeof($iseco);$i++){

?>
      <tr>
        <td><?Php echo $iseco[$i];?></td> 
        <td><?Php 
        $sql="select * from co where cono='$iseco[$i]' and subjectid=$subject and tid=$tid; ";
     $result=mysqli_query($con, $sql);
    while($row = mysqli_fetch_assoc($result)) {
		$description = $row['description'];
                
		}
                
                if($description!="")
                {
                    echo $description;
                }
    
        //echo $description;?></td>
        <td><?Php echo $directattainment[$i]; ?></td>
        
      </tr>
<?Php }   ?>     
    </tbody>
  </table>
  <center><a href="CalculateAverageSelection.php" class="btn btn-info" role="button">Previous</a>
                     <input type="submit" name="exportpdf" value="PDF" class="btn btn-success" />
                     <a href="../courseexitform.php" class="btn btn-info" role="button">Next</a></center>
<br>
</div>
    
    
    
</body>
</html>

