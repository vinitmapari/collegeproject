<?php
require('fpdf/fpdf.php');

$db = new PDO('mysql:host=localhost;dbname=project','root','');

class myPDF extends FPDF{
	var $average = [];
	var $sum = [];
	var $sd = [];
	var $noOfStudent;
	var $count1=0;
	var $count2=0;
	var $count3=0;
	var $count4=0;
	var $count5=0;
	var $cnt=0;

	function header(){
		$this->Ln(10);
		$this->Image('logo.jpg',20,15,35);
		$this->SetFont('Times','B',13);
		$this->Cell(276,5,'BHARTIYA VIDYA BHAVANS',0,0,'C');
		$this->Ln(10);
		$this->SetFont('Times','B',18);
		$this->Cell(276,5,'SARDAR PATEL INSTITUTE OF TECHNOLOGY',0,0,'C');
		$this->Ln();
		$this->SetFont('Times','',12);
		$this->Cell(276,10,'Munshi Nagar, Andheri West, Mumbai, Maharashtra 400058',0,0,'C');
		$this->Ln(20);
		
	}

	function intro(){
		$this->Ln(10);
		$this->setFont('Arial','',12);
		$this->Cell(0,5,'Faculty Name : Mrs. Pooja Raundale',0,0,'L');
		$this->Cell(0,5,'Year : 2017-18',0,0,'R');
		$this->Ln(10);
		$this->Cell(0,5,'Class : F.Y.M.C.A',0,0,'L');
		$this->Cell(0,5,'Semester : I',0,0,'R');
		$this->Ln(10);
		$this->SetFont('Times','B',14);
		$this->Cell(276,10,'OBJECT ORIENTED PROGRAMMING MSE RESULT',0,0,'C');
		$this->Ln(20);
	}

	function footer(){
		$this->SetY(-15);
		$this->SetFont('Arial','',0);
		$this->Cell(0,10,'Page'.$this->PageNo().'/{nb}',0,0,'C');

	}

	function headerTable(){
		$this->SetFont('Times','B',12);
		$this->Cell(40,10,'Student UID',1,0,'C');
		$this->Cell(40,10,'Name',1,0,'C');
		$this->Cell(40,10,'Question 1',1,0,'C');
		$this->Cell(40,10,'Question 2',1,0,'C');
		$this->Cell(40,10,'Question 3',1,0,'C');
		$this->Cell(40,10,'Question 4',1,0,'C');
		$this->Cell(40,10,'Question 5',1,0,'C');
		$this->Ln();
	}

	function viewTable($db){
		$this->SetFont('Times','',12);
		$stmt = $db->query('select * from oop');
		while($data = $stmt->fetch(PDO::FETCH_OBJ)){
			$this->Cell(40,10,$data->uid,1,0,'C');
			$this->Cell(40,10,$data->name,1,0,'C');
			$this->Cell(40,10,$data->q1,1,0,'C');
			$this->Cell(40,10,$data->q2,1,0,'C');
			$this->Cell(40,10,$data->q3,1,0,'C');
			$this->Cell(40,10,$data->q4,1,0,'C');
			$this->Cell(40,10,$data->q5,1,0,'C');

			$this->Ln();
		}
	}

	function addAverage($db){
		$this->SetFont('Times','',12);
		$stmt = $db->query('select AVG(q1) as avgq1,AVG(q2) as avgq2,AVG(q3) as avgq3,AVG(4) as avgq4,AVG(q5) as avgq5 from oop');
		$this->Cell(80,10,'Average',1,0,'C');
		while($data = $stmt->fetch(PDO::FETCH_OBJ)){
			$this->Cell(40,10,$data->avgq1,1,0,'C');
			$this->Cell(40,10,$data->avgq2,1,0,'C');
			$this->Cell(40,10,$data->avgq3,1,0,'C');
			$this->Cell(40,10,$data->avgq4,1,0,'C');
			$this->Cell(40,10,$data->avgq5,1,0,'C');
			
			$this->average[0]=$data->avgq1;
			$this->average[1]=$data->avgq2;
			$this->average[2]=$data->avgq3;
			$this->average[3]=$data->avgq4;
			$this->average[4]=$data->avgq5;
			
			//print_r($average);
//			$this->upper($data);
			$this->Ln();
		}
	 }


	 function addSum($db)
	 {
	 	$this->SetFont('Times','',12);
	 	$stmt = $db->query('select SUM(q1) as sumq1,SUM(q2) as sumq2,SUM(q3) as sumq3,SUM(q4) as sumq4,SUM(q5) as sumq5 from oop');
	 	$this->Cell(80,10,'Sum',1,0,'C');
	 	while($data = $stmt->fetch(PDO::FETCH_OBJ)){
			$this->Cell(40,10,$data->sumq1,1,0,'C');
			$this->Cell(40,10,$data->sumq2,1,0,'C');
			$this->Cell(40,10,$data->sumq3,1,0,'C');
			$this->Cell(40,10,$data->sumq4,1,0,'C');
			$this->Cell(40,10,$data->sumq5,1,0,'C');
			$this->sum[0]=$data->sumq1;
			$this->sum[1]=$data->sumq2;
			$this->sum[2]=$data->sumq3;
			$this->sum[3]=$data->sumq4;
			$this->sum[4]=$data->sumq5;
		
			$this->Ln();
		}
	 }

	 function countStudents($db)
	 {
	 	$this->SetFont('Times','',12);
	 	$stmt = $db->query('select count(*) as totalstud from oop');
	 	$this->Cell(80,10,'Students present',1,0,'C');
	 	while($data = $stmt->fetch(PDO::FETCH_OBJ)){
	 		$this->Cell(200,10,$data->totalstud,1,0,'C');
	 		//$this->cnt=$data->totalstud;
	 		$this->Ln();
	 	}
//	 	print_r($this->cnt);
	 }

	 function SD($db)
	 {
	 	$this->SetFont('Times','',12);
	 	$stmt = $db->query('select STDDEV_POP(q1) as sdq1,STDDEV_POP(q2) as sdq2,STDDEV_POP(q3) as sdq3,STDDEV_POP(q4) as sdq4,STDDEV_POP(q5) as sdq5 from oop');
	 	$this->Cell(80,10,'Standard Deviation',1,0,'C');
	 	while($data = $stmt->fetch(PDO::FETCH_OBJ)){
			$this->Cell(40,10,$data->sdq1,1,0,'C');
			$this->Cell(40,10,$data->sdq2,1,0,'C');
			$this->Cell(40,10,$data->sdq3,1,0,'C');
			$this->Cell(40,10,$data->sdq4,1,0,'C');
			$this->Cell(40,10,$data->sdq5,1,0,'C');
			$this->sd[0]=$data->sdq1;
			$this->sd[1]=$data->sdq2;
			$this->sd[2]=$data->sdq3;
			$this->sd[3]=$data->sdq4;
			$this->sd[4]=$data->sdq5;

//			$this->upper($data);
			$this->Ln();
		}	
	 }

	 function upper()
	 {
	 	
	 	$this->SetFont('Times','',12);
	 	$this->Cell(80,10,'Upper Range',1,0,'C');
	 	//print_r($this->average[0]+$this->sd[0]);
	 	
			$this->Cell(40,10,($this->average[0]+$this->sd[0]),1,0,'C');
			$this->Cell(40,10,($this->average[1]+$this->sd[1]),1,0,'C');
			$this->Cell(40,10,($this->average[2]+$this->sd[2]),1,0,'C');
			$this->Cell(40,10,($this->average[3]+$this->sd[3]),1,0,'C');
			$this->Cell(40,10,($this->average[4]+$this->sd[4]),1,0,'C');

			$this->Ln();
		

	 }

	 function lower()
	 {
	 	
	 	$this->SetFont('Times','',12);
	 	$this->Cell(80,10,'Lower Range',1,0,'C');
	 	//print_r($this->average[0]+$this->sd[0]);
	 	
			$this->Cell(40,10,($this->average[0]-$this->sd[0]),1,0,'C');
			$this->Cell(40,10,($this->average[1]-$this->sd[1]),1,0,'C');
			$this->Cell(40,10,($this->average[2]-$this->sd[2]),1,0,'C');
			$this->Cell(40,10,($this->average[3]-$this->sd[3]),1,0,'C');
			$this->Cell(40,10,($this->average[4]-$this->sd[4]),1,0,'C');

			$this->Ln();
		

	 }

	 function studentrange($db)
	 {
	 	$this->SetFont('Times','',12);
	 	$this->Cell(80,10,'Students in range',1,0,'C');
	 	$stmt = $db->query('select * from oop');
	 	while($data = $stmt->fetch(PDO::FETCH_OBJ)){
	 		if((($data->q1) > ($this->sd[0]) )&& (($data->q1) < ($this->average[0])))
	 			$this->count1++;
	 	}
	 	$this->Cell(40,10,($this->count1),1,0,'C');
	 	
	 	while($data = $stmt->fetch(PDO::FETCH_OBJ)){
	 		if((($data->q2) > ($this->sd[1])) && (($data->q2) < ($this->average[1])))
	 			$this->count2++;
	 	}
	 	$this->Cell(40,10,($this->count2),1,0,'C');
	 	
	 	while($data = $stmt->fetch(PDO::FETCH_OBJ)){
	 		if((($data->q3) > ($this->sd[2])) && (($data->q3) < ($this->average[2])))
	 			$this->count3++;
	 	}
	 	$this->Cell(40,10,($this->count3),1,0,'C');
	 	
	 	while($data = $stmt->fetch(PDO::FETCH_OBJ)){
	 		if((($data->q4) > ($this->sd[3]) )&& (($data->q4) < ($this->average[3])))
	 			$this->count4++;
	 	}
	 	$this->Cell(40,10,($this->count4),1,0,'C');
	 	
	 	while($data = $stmt->fetch(PDO::FETCH_OBJ)){
	 		if((($data->q5) > ($this->sd[4]) )&& (($data->q5) < ($this->average[4])))
	 			$this->count5++;
	 	}
	 	$this->Cell(40,10,($this->count5),1,0,'C');
	 		
	 	
	 	}


	 	// function attainCO()
	 	// {
	 	// 	$this->SetFont('Times','',12);
	 	// 	$this->Cell(80,10,'Attainment CO',1,0,'C');
	 	// 	//$stmt = $db->query('select * from oop');
	 	// 	$this->Cell(40,10,(($this->count1)/($this->cnt)),1,0,'C');		
	 	// }



}

$pdf = new myPDF();
$pdf->AliasNbPages();
$pdf->AddPage('P','A3',0);
$pdf->intro();
$pdf->headerTable();
$pdf->viewTable($db);
$pdf->addAverage($db);
$pdf->addSum($db);
$pdf->SD($db);
$pdf->upper();
$pdf->lower();
$pdf->studentrange($db);
//$pdf->attainCO();
$pdf->countStudents($db);
$pdf->Output();
?>