<html>
    <head>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    </head>
    <body>
        
               <img src="image/spitlogo.png" width="100">
               <h3>______Sardar Patel Institute of Technology_____ </h3>
                
        <table class="table">
           
               
<?php
session_start();
$con = mysqli_connect("localhost:3308","root","","mcadatabase");
// Check connection
if (mysqli_connect_errno())
{
  mysqli_connect_error();
}

$class=$_SESSION['class'];
$subject=$_SESSION['subject'];
$year=$_SESSION['year'];
$semester=$_SESSION['semester'];
$tid=$_SESSION['tid'];
$msequestionpaperid=$_SESSION['msequestionpaperid'];   
//echo $msequestionpaperid;             
//-----------------------------------uploading code---------------------------------------->                        
        
if(isset($_POST["import"]))
{

$co=array(); 
$coidarray=array();
$comarks=array();
$sumtotal=0;
$sql3="select * from msepaperdescription where msequestionpaperid='$msequestionpaperid';";
$result3 = mysqli_query($con, $sql3);
$i=0;
echo "<thead>";
echo "<tr>";
echo "<th>UCID</th><th>Name</th>";
while($row = mysqli_fetch_array($result3))  
{ 
$Questionno=$row["Questionno"];
$subquestion=$row["subquestion"];
$coid=$row["coid"];
$coidarray[$i]=$coid;
$comark=0;
$sql10="select * from msepaperdescription where msequestionpaperid='$msequestionpaperid' and coid=$coid;";
$result10 = mysqli_query($con, $sql10);
while($row = mysqli_fetch_array($result10))  
{ 
$comark=$comark+$row["QuestionMarks"];
}
$comarks[$i]=$comark;
//echo $coid;
echo "<th>".$Questionno."-".$subquestion."</th>";

$sql4="select * from CO where idco='$coid' and tid='$tid';";
$result4 = mysqli_query($con, $sql4);
while($row = mysqli_fetch_array($result4))  
{ 
$cono=$row["cono"];
}
$co[$i]=$cono;
$questionarray[$i]="$Questionno"."-"."$subquestion";
$i++;
}
echo "<th>total</th><th>Revise marks</th>";
echo "</tr>";
echo "</thead>";
echo "<tr>";
echo "<td></td><td></td>";
for($i=0;$i<sizeof($co);$i++)
    {
         echo "<td>";echo $co[$i]; echo "</td>";   
    }
    
echo "</tr>";


$Header = array('UCID', 'Name');
$total=array("total","revise marks"); 
$Header= array_merge($Header, $questionarray);
$Header= array_merge($Header, $total);
   
 $extension = end(explode(".", $_FILES["excel"]["name"])); // For getting Extension of selected file
 $allowed_extension = array("xls", "xlsx", "csv"); //allowed extension
  
 if(in_array($extension, $allowed_extension)) //check selected file extension is present in allowed extension array
 {

  $file = $_FILES["excel"]["tmp_name"]; // getting temporary source of excel file
  include("PHPExcel/IOFactory.php"); // Add PHPExcel Library in this code
  $objPHPExcel = PHPExcel_IOFactory::load($file); // create object of PHPExcel library by using load() method and in load method define path of selected file
    
  foreach ($objPHPExcel->getWorksheetIterator() as $worksheet)
  {
   $highestRow = $worksheet->getHighestRow();
   $Column = $worksheet->getHighestDataColumn();
   $highestColumn = PHPExcel_Cell::columnIndexFromString($Column);
   
  //echo "Highest Row";
  //echo $highestRow;
  //echo "Highest Column";
  //echo $highestColumn;
   
  $strtemp=Array();
  $countsta=Array();
  $temparray=Array();
  $numberstudent=Array();
  $variance=Array();
  $average=Array();
  $upperrange=Array();
  $lowerrange=Array();
  //$aboveraverage=Array();
  
   for($i=2;$i<$highestColumn-2;$i++)
    {
     $string1 = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow($i, 1)->getValue());
     $str_arr1 = explode ("-", $string1); 
     $strtemp=array_merge($strtemp,$str_arr1);
    }
     
   $total=0;
   $countst=0;
  //echo "<br>";
   for($rowtable=3; $rowtable<=$highestRow; $rowtable++)
   {
       echo "<tr>";
    //print_r($strtemp);   
    ?>
            
    <?Php
    
    $UID = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(0, $rowtable)->getValue());
    $name = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(1, $rowtable)->getValue());
    
    
     //$query22 = "Insert into msemarks(ucid,studentname,idmsequestionpaper)values($UID,'$name',$msequestionpaperid)";
     //mysqli_query($con, $query22);
     
     ?><?Php //echo $UID; ?><?Php //echo $name; ?><?Php
     $strvalue=Array();
    $aboveaverage=array();
    for($k=2;$k<$highestColumn-2;$k++)
    {
      
     $str_arr = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow($k, $rowtable)->getValue());
    
     $strvalue=array_merge($strvalue,(array)$str_arr);
     
      $aboveaverage=array_merge($aboveaverage,$strvalue);
      //print_r($aboveaverage);
    }
   
    
    //echo "strvalue array";
    //print_r($strvalue);
    //echo "<br>";
    $total = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow($highestColumn-1, $rowtable)->getValue());
    $revisemark = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow($highestColumn, $rowtable)->getValue());
    //echo "<tr>";
    echo "<td>".$UID."</td>";
    echo "<td>".$name."</td>";
    //echo $total;
    //echo $revisemark;
    //echo "end";
    //echo "<br>";
    $j=0;
    //echo "Size of strvalue ";
    //echo sizeof($strvalue);
    
           $temparray = array_map(function () {
           return array_sum(func_get_args());
           }, $temparray, $strvalue);
    
    for($i=0;$i<sizeof($strvalue);$i++)
    {
            $numberstudent[$i]=$highestRow-2;
            if($strvalue[$i]=='0')
            {
                $countst++;
                $countsta[$i]=$countst;
                
            }
            else{
                $countsta[$i]='0';
            }
          
    }
    //print_r($countsta);
    
    
    for($i=0;$i<sizeof($strvalue);$i++)
    {
        //echo "<br>";
        //echo "value of i";
        //echo $i;
        //echo "<br>";
     
        
    while($j<sizeof($strtemp))
    {
                
        $c=$j+1;
        //echo "question";
        //echo "<td>";echo $strtemp[$j];echo "</td>";
        //echo "<br>";
        //echo "subquestion";
        //echo "<td>";echo $strtemp[$c];echo "</td>";
        //echo "<br>";
         
     $sql1="select * from msepaperdescription where Questionno=$strtemp[$j] and subquestion='$strtemp[$c]' and msequestionpaperid=$msequestionpaperid ";
     $result=mysqli_query($con, $sql1);
    while($row = mysqli_fetch_assoc($result)) {
		$idmsequestionpaperDescription = $row['msequestionpaperdescriptionId'];
		}
        
       //echo "strvalue marks";
       //echo $strvalue[$i];
       
        $sql11="select * from msemarks where ucid=$UID and studentname='$name' and idmsequestionpaper=$msequestionpaperid";
     $result=mysqli_query($con, $sql11);
    while($row = mysqli_fetch_assoc($result)) {
		$msemarksid = $row['Idmsemarks'];
		}
        
     
       //echo "msemarkid".$msemarksid;
       //echo "msequestionpaperdescriptionid".$idmsequestionpaperDescription;
       //echo "actual marks".$strvalue[$i];
                
                
                
                $total=$total+$strvalue[$i];
                $sumtotal=$sumtotal+$strvalue[$i];
                ?><?Php echo "<td>".$strvalue[$i]."</td>"; ?><?Php
      //$query7 = "Insert into msequestionmarksjoiner (msemarksid,msequestionpaperdescriptionid,actualmarks)values($msemarksid,$idmsequestionpaperDescription,'$strvalue[$i]')";
       //mysqli_query($con, $query7);
       
       //echo "value of j-";
       //echo $j;
       //echo "value of c-";
       //echo $c;
       break;
         
    }
       
     $j=$j+2;    
     //echo $j;  
    
    }
    
    ?><?Php 
    if($total=='')
    {
    echo 0;}
    else{
        echo "<td>".$total."</td>";
    }
    
    ?><?Php if($total=='')
    { echo "AB";} 
    else{
       echo "<td>".$total."</td>";
        
    }
    
    ?><?Php
    //echo "<br>";
         //echo "end of the loop";
         //echo "row ".$rowtable;
        //echo "<br>";
    ?><?Php
   $total=0; 
   
   echo "</tr>";
   }
  
   echo"<tr>";
   echo "<td></td><td>Sum</td>";
   for($i=0;$i<sizeof($temparray);$i++)
    {
        
           echo "<td>".$temparray[$i]."</td>";
            
          
    }
     echo "<td>".$sumtotal."</td>";
     echo "<td>".$sumtotal."</td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td></td>";
    echo "<td>No of students present</td>";
    //print_r($numberstudent);
    //print_r($countsta);
     
    foreach ($numberstudent as $key => $value) {
    if(array_key_exists($key, $countsta) && array_key_exists($key, $numberstudent))
        $numberstudent[$key] = $numberstudent[$key] - $countsta[$key];
}
   for($i=0;$i<sizeof($countsta);$i++)
    {
        
           echo "<td>".$numberstudent[$i]."</td>";
                     
    }
    echo "<td>".$numberstudent[1]."</td>";
    echo "<td>".$numberstudent[1]."</td>";
    echo "</tr>";
   
    echo "<tr>";
    echo "<td></td>";
    echo "<td>Avg</td>";
    for($i=0;$i<sizeof($countsta);$i++)
    {
         echo "<td>".$temparray[$i]/$numberstudent[$i]."</td>";
         $average[$i]=$temparray[$i]/$numberstudent[$i];
    }

    echo "</tr>";
    
    echo "<tr>";
    echo "<td></td>";
    echo "<td>Variance</td>";
    for($i=0;$i<sizeof($countsta);$i++)
    {
         echo "<td>".pow($i-($temparray[$i]/$numberstudent[$i]),2)."</td>";
         $variance[$i]=pow($i-($temparray[$i]/$numberstudent[$i]),2);
    }

    echo "</tr>";
    
     $upperrange = array_map(function () {
           return array_sum(func_get_args());
           }, $variance, $average);
    
   foreach ($variance as $key => $value) {
    if(array_key_exists($key, $average) && array_key_exists($key, $variance))
        $lowerrange[$key] = $variance[$key] - $average[$key];        
   } 
    echo "<tr>";
    echo "<td></td>";
    echo "<td>Upper range</td>";
    for($i=0;$i<sizeof($countsta);$i++)
    {
         echo "<td>".$upperrange[$i]."</td>";
         
    }

    echo "</tr>";
    
    
    echo "<tr>";
    echo "<td></td>";
    echo "<td>Lower range</td>";
    for($i=0;$i<sizeof($countsta);$i++)
    {
         echo "<td>".$lowerrange[$i]."</td>";
         
    }

    echo "</tr>";
    //print_r($average);
    //print_r($aboveaverage);
    $aboveaveragecount=Array();
    echo "<tr>";
    echo "<td></td>";
    echo "<td>above average</td>";
    
    $j=0;
    $aboveavgcount=0;
    for($i=0;$i<sizeof($countsta);$i++)
    {
        echo "<td>1</td>";
            if($j==3)
            {
                $j=0;
            }
            if($aboveaverage[$i]>$average[$j])
            {
                
                $aboveavgcount++;
                $aboveaveragecount[$j]=$aboveavgcount;
                $j++;
            }   
        //echo "<td>".$lowerrange[$i]."</td>";
         
    }
    //print_r($aboveaverage);
    
    echo "</tr>";
    
    echo "</tr>";
    //print_r($average);
    //print_r($aboveaverage);
    $aboveaveragecount=Array();
    echo "<tr>";
    echo "<td></td>";
    echo "<td>CO attainment</td>";
    
    echo "<td>50</td>";
       echo "<td>50</td>";
         echo "<td>50</td>";
        //echo "<td>".$lowerrange[$i]."</td>";
         
    
    //print_r($aboveaverage);
    
    echo "</tr>";
    
    
    $covalue=Array('20','20','20','20');
    for($i=0;$i<sizeof($coidarray);$i++)
    {
        $query7 = "Insert into mseco(coid,covalue,msequestionpaperid)values($coidarray[$i],$covalue[$i],$msequestionpaperid)";
        mysqli_query($con, $query7);
    }
    
     $_SESSION["average"] = Array();
     $_SESSION["co"] =Array();
     $_SESSION["comarks"] =   Array();     
             
     array_push($_SESSION["average"], $average);
     array_push($_SESSION["co"], $co);
     array_push($_SESSION["comarks"], $comarks);
    //print_r($variance);
    //print_r($average);
  } 
            
}
}
?>
</table>
    </body>
</html>    
 