
<?php
        session_start();
	$con = mysqli_connect("localhost:3308","root","","mcadatabase");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
	
        $class=$_SESSION['class'];
        $subject=$_SESSION['subject'];
        $year=$_SESSION['year'];
        $semester=$_SESSION['semester'];
        $attainment=$_SESSION['assignmentno'];
        $tid=$_SESSION['tid'];
	$co=$_SESSION['co'];   
        
        echo $class;
        echo $subject;
        echo $co;
        echo $semester;
        echo $attainment;
        echo $year;
        echo $tid;

if(isset($_POST["import"]))
{
 $extension = end(explode(".", $_FILES["excel"]["name"])); // For getting Extension of selected file
 $allowed_extension = array("xls", "xlsx", "csv"); //allowed extension
 
 if(in_array($extension, $allowed_extension)) //check selected file extension is present in allowed extension array
 {

  $file = $_FILES["excel"]["tmp_name"]; // getting temporary source of excel file
  include("PHPExcel/IOFactory.php"); // Add PHPExcel Library in this code
  $objPHPExcel = PHPExcel_IOFactory::load($file); // create object of PHPExcel library by using load() method and in load method define path of selected file

 $sql1="select * from assignment where class='$class' and subject='$subject' and year='$year' and semester='$semester' and tid='$tid' ";
     $result=mysqli_query($con, $sql1);
     while($row = mysqli_fetch_assoc($result)) {
				$assignmentid = $row['idassignment'];
		}
     //echo "quiz id";	
                echo $assignmentid;                   
                        
   $sql3="select * from assingmentmarks where assignmentid='$assignmentid' ";
     $result2=mysqli_query($con, $sql3);
     $num=mysqli_num_rows($result2);
     echo "number of rows";
     echo $num;
     
  foreach ($objPHPExcel->getWorksheetIterator() as $worksheet)
  {
   $highestRow = $worksheet->getHighestRow();
   for($row=2; $row<=$highestRow; $row++)
   {
   
    $UID = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(0, $row)->getValue());
    $name = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(1, $row)->getValue());
    $assignment1 = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(2, $row)->getValue());
    $assignment2= mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(3, $row)->getValue());
    $assignment3 = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(4, $row)->getValue());
    $assignment4 = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(5, $row)->getValue());
    
    echo $UID;
    echo $name;
    //echo $class;
    //echo $name;
    
      if($num==0)
    {
           echo"I am in insert";
        $query = "Insert into assignmentmarks (ucid,studentname,assign1,assign2,assign3,assign4,assignid)values($UID,'$name',$assignment1,$assignment2,$assignment3,$assignment4,$assignmentid)";
    mysqli_query($con, $query);
          
    }
 else {
    echo"I am in update";
    $query = "update assignmentmarks set assign1=$assignment1,assign2=$assignment2,assign3=$assignment3,assign4=$assignment4 where assignid=$assignmentid and ucid=$UID and studentname='$name'";
    mysqli_query($con, $query);
    }
    
   }
  } 
            
  $output = '<label class="text-danger">Data inserted successfully</label>'; 
  $file = $subject.$semester.$attainment.$class.$year.$co.".".$extension;
   //echo $file;
   $UploadTmp = $_FILES['excel']['tmp_name'];
    //$sql = "INSERT INTO file (filename) VALUES ('$file')"; 
    //mysqli_query($con, $sql);
		$user=$_SESSION['user_id'];
   move_uploaded_file($UploadTmp,"Upload/$user/$file");
   $output = '<label class="text-danger">File Uploaded</label>'; 
    //echo "inserted";
  //Header('Location: admin/adminaddstudent.php');
 }
 else
 {
  $output = '<label class="text-danger">Invalid File</label>';
 }
}
?>
    <label><?Php $output ?></label>   
 