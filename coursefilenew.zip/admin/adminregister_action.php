<?php
session_start();
require "../db.php";

if(isset($_POST['fname'])&&
isset($_POST['lname'])&&
isset($_POST['password'])&&
isset($_POST['confirm']) &&
isset($_POST['email']))
{
	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$password=$_POST['password'];
	$confirm=$_POST['confirm'];
	$cno=$_POST['no'];
	$email=$_POST['email'];
	$branch = $_POST['branch'];
        
       
        
	if(!empty($fname) && !empty($lname) &&!empty($password) && !empty($confirm)&& !empty($cno)&& !empty($email) && !empty($branch)){
		if($password!=$confirm){
			echo'passwords do not match';
		}else{
			$query="select adminemail from admin where adminemail='$email'";
			$query_run=mysqli_query($con,$query);
			if(mysqli_num_rows($query_run) == 1) {
				echo 'The email id already exist';
			}
			else{
				$query="insert into admin(adminfirstname, adminlastname, admincontact, adminemail, password, branch) values('".$fname."','".$lname."','".$cno."','".$email."','".$password."','".$branch."')";
				if($query_run=mysqli_query($con,$query)){
					$sql="select * from admin where adminemail='".$email."' and password='$password' limit 1";
					if($query1=mysqli_query($con,$sql)){
						while($row = mysqli_fetch_assoc($query1)) {
							$user_id = $row['adminfirstname'];
							$adminid=$row['Id'];
						}
					}
					//session_start();
					$_SESSION['user_id']=$user_id;
					$_SESSION['adminid']=$adminid;
					mkdir("../Upload/$user_id");
					mkdir("../Upload/$user_id/FY");
					mkdir("../Upload/$user_id/SY");
					mkdir("../Upload/$user_id/TY");
					header('location: adminalotteach.php');
				}else
				{
					echo 'sorry';
				}
			}
			
		}
	}else {
		echo 'all fields are required';
	}
	

}

?>
