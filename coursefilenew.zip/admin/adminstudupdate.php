<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "header.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
</head>
<body>

<?php
require "adminmenu.php";
require "adminsidenav.php";
?>
  <div class="container">
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title">Update Student Detail</h1>
					</div>
<form class="form-horizontal" onsubmit="return submitForm(this);" method="post" action="adminstudupdate_action.php">
<br>
   <!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="ucid">UCID</label>
  <div class="col-md-4">
    <select id="ucid" name="ucid" class="form-control" style="height:35px">
	<?php
	require "../db.php";
    $query = "select * from studentlist";
    $results = mysqli_query($con,$query);

    while ($rows = mysqli_fetch_assoc(@$results)){ 
    ?>
      <option value="<?php echo $rows['ucid'];?>"><?php echo $rows['ucid'];?></option>
	  <?php
    } 
    ?>
    </select>
  </div>
</div>
  
  <div class="form-group">
  <label class="col-md-4 control-label" for="name">Name</label>  
  <div class="col-md-4">
  <input id="name" name="name" type="text" placeholder="" class="form-control input-md" required="">
  </div>
  </div>
  
  <div class="form-group">
  <label class="col-md-4 control-label" for="class">Class</label>  
  <div class="col-md-4">
  <input id="class" name="class" type="text" placeholder="" class="form-control input-md" required="">
  </div>
  </div>

   <div class="form-group">
  <label class="col-md-4 control-label" for="class">Year</label>  
  <div class="col-md-4">
  <input id="yr" name="yr" type="text" placeholder="" class="form-control input-md" required="">
  </div>
  </div>
  
  <div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submitup" name="submitup" class="btn btn-default">Update</button>
  </div>
</div><br>

</form>

</div>
</div><br><br>

						
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>

<?php
require "footer.php";
?>
</body>
</html> 