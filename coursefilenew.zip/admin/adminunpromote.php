<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "header.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
</head>
<body>

<?php
require "adminmenu.php";
require "adminsidenav.php";
?>
  <div class="container">
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title">Unpromoted Students</h1>
					</div>

  <div class="panel-body">
  
<?php
function unpromoted(){
	require "../db.php";
$get_cats="select * from studentlist where fladkt='yes'";
//$con=mysqli_connect("localhost","root","","test2")or die("could not connect!");
$run=mysqli_query($con,$get_cats)or die("could not search!");
if(mysqli_num_rows($run)!==0){
	echo "
	<form class='form-horizontal' method='post' action='adminunpromote_action.php'>
	<div class='table-responsive' style='height:300px;width:400px;margin-left:70px'>       
  <table class='table table-hover' Style='float:left; width:200px;align:center;'>
    <thead>
      <tr>
	  <th>Select</th>
        <th>UCID</th>
        <th>Name</th>
		<th>Class</th>
      </tr>
    </thead>
    <tbody>
      <tr>";
while($row_cats = mysqli_fetch_array($run)){

$ucid=$row_cats['ucid'];
$name=$row_cats['studentname'];
$class=$row_cats['class'];

echo "<td><input type='checkbox' name='check_list[]' value=".$ucid." />&nbsp;</td>
 <td>$ucid</td>
 <td>$name</td>
 <td>$class</td>
 </tr><tr>
 ";
}
echo"<br>
      </tr>
    </tbody>
	</table>
	</div><br>
<div class='form-group'>
  <label class='col-md-4 control-label' for='submit'></label>
  <div class='col-md-4'>
    <button id='submit_unpromoted' name='submit_unpromoted' value='Submit' class='btn btn-default'>Promote</button>
  </div>
</div>
  </form>";
}
else{
	echo "no list found";
}
} 
?>
  <?php unpromoted()?>


</div>
</div><br><br>
</div>
						
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>

<?php
require "footer.php";
?>
</body>
</html> 
