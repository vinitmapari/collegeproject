<?php
require "../db.php";
	if(isset($_POST['delucid']))
	{
	 $no=$_POST['delucid'];
	}
	$query = "delete from studentlist where ucid='$no'";
    $sql=mysqli_query($con, $query);
	Header('Location: admindelstudent.php');
?>