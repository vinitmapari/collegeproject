<?php
require "../db.php";
	if((isset($_POST['ucid'])) && (isset($_POST['name'])) && (isset($_POST['class'])) && (isset($_POST['yr'])))
	{
	 $no=$_POST['ucid'];
	 $name=$_POST['name'];
	 $cla=$_POST['class'];
	 $yr=$_POST['yr'];
	}
	$query = "update studentlist set studentname='$name', class='$cla', year='$yr' where ucid='$no'";
    $sql=mysqli_query($con, $query);
	Header('Location: adminstudupdate.php');
?>