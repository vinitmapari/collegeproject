<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "header.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
<title>Admin Register</title>
</head>
<body>
		<?php
require "adminlogmenu.php";
?>
  <div class="container"><br>
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title">Admin Registration</h1>
					</div>

  <div class="panel-body">
					<form class="form-horizontal" method="post" action="adminregister_action.php">
<br>
						<div class="form-group">
  <label class="col-md-4 control-label" for="username">First name</label>  
  <div class="col-md-4">
									<input type="text" class="form-control" name="fname" id="fname"  placeholder="Enter your Username"/>
								</div>
							</div>
							<div class="form-group">
  <label class="col-md-4 control-label" for="username">Last name</label>  
  <div class="col-md-4">
									<input type="text" class="form-control" name="lname" id="lname"  placeholder="Enter your Username"/>
								</div>
							</div>

						<div class="form-group">
  <label class="col-md-4 control-label" for="password">Password</label>  
  <div class="col-md-4">
									<input type="password" class="form-control" name="password" id="password"  placeholder="Enter your Password"/>
								</div>
							</div>

						<div class="form-group">
  <label class="col-md-4 control-label" for="confirm">Confirm Password</label>  
  <div class="col-md-4">
									<input type="password" class="form-control" name="confirm" id="confirm"  placeholder="Confirm your Password"/>
								</div>
							</div>
						
						<div class="form-group">
  <label class="col-md-4 control-label" for="no">Contact</label>  
  <div class="col-md-4">
									<input type="text" class="form-control" name="no" id="no"  placeholder="Enter your Name"/>
								</div>
							</div>

						<div class="form-group">
  <label class="col-md-4 control-label" for="email">Email</label>  
  <div class="col-md-4">
									<input type="text" class="form-control" name="email" id="email"  placeholder="Enter your Email"/>
								</div>
							</div>
						<!-- Select Basic -->
						<div class="form-group">
  <label class="col-md-4 control-label" for="branch">Branch</label>
  <div class="col-md-4">
								<select id="branch" name="branch" class="form-control" style="height:35px">
									<option value="MCA">MCA</option>
									<option value="EXTC">EXTC</option>
									<option value="ERTC">ERTC</option>
									<option value="Computer Science">Computer Science</option>
									<option value="IT">IT</option>
								</select>
							</div>
							</div>

						<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" value="Submit" class="btn btn-default">Register</button>
						</div>
						</div>
						<div class="login-register" align="center">
				            <a href="logintest.php">Login</a>
				         </div>
						 
					</form>
</div>
</div><br><br>
</div>

		<script type="text/javascript" src="assets/js/bootstrap.js"></script>
		<?php
require "footer.php";
?> 
	</body>
</html>