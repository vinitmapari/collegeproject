<?php
session_start();
$user=$_SESSION['adminid'];
require "../db.php";

	if(isset($_POST['subsel'])&& isset($_POST['teachsel'])&& isset($_POST['radios']))
{
$subcode=$_POST['subsel'];
$teach=$_POST['teachsel'];
$share=$_POST['radios'];
$query="insert into transactionadmin values('','".$teach."','".$subcode."','".$share."','".$user."')";
mysqli_query($con,$query);
}
else
{
	echo "Could not update";
}
Header('location:adminalotteach.php');
?>