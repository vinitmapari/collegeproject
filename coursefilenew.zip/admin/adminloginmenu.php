<div class="clearfix" style="background-image: url(blurteach.jpg);background-size:100% 100%;background-repeat:no-repeat;height:90px;" id='header'>
<img src="../image/spitlogo.png" alt="SPIT College" width="100" height="80" style="margin-left:100px;float:left"><label style="float:left;color:black"><h1> S.P.I.T. College</h1></label>
&nbsp;&nbsp;&nbsp;
</div>

<nav>
    <div class="toggle">
        <i class="fa fa-bars menu" aria-hidden="true"></i>
    </div>
    <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
    </ul>
</nav>