<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<?php
require "header.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
</head>
<body>

<?php
require "adminmenu.php";
require "adminsidenav.php";
?>
  <div class="container">
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title">Alot teachers</h1>
					</div>

  <div class="panel-body">
  
  <form class="form-horizontal" method="post" action="adminalotteach_action.php">
						<br>
  
  <!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="subsel">Subject</label>
  <div class="col-md-4">
    <select id="subsel" name="subsel" class="form-control" style="height:35px">
	<?php
	require "../db.php";
    $query = "select * from subject";
    $results = mysqli_query($con,$query);

    while ($rows = mysqli_fetch_assoc(@$results)){ 
    ?>
      <option value="<?php echo $rows['idsubject'];?>"><?php echo $rows['subjectname'];?></option>
	  <?php
    } 
    ?>
    </select>
  </div>
</div>
  
  <!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="teachsel">Teacher</label>
  <div class="col-md-4">
    <select id="teachsel" name="teachsel" class="form-control" style="height:35px">
	<?php
	require "../db.php";
    $query = "select * from teacher";
    $results = mysqli_query($con,$query);

    while ($rows = mysqli_fetch_assoc(@$results)){ 
    ?>
      <option value="<?php echo $rows['idteacher'];?>"><?php echo $rows['teacherfirstname'];?></option>
	  <?php
    } 
    ?>
    </select>
  </div>
</div>

  
  <!-- Multiple Radios (inline) -->
<div class="form-group">
  <label class="col-md-4 control-label" for="radios">Sharing</label>
  <div class="col-md-4"> 
    <label class="radio-inline" for="radios-0">
      <input type="radio" name="radios" id="radios-0" value="1">
      Yes
    </label> 
    <label class="radio-inline" for="radios-1">
      <input type="radio" name="radios" id="radios-1" value="0" checked="checked">
      No
    </label>
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" class="btn btn-default">Submit</button>
  </div>
</div><br>
</form>
						
</div>
</div><br><br>
</div>
						
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>

<?php
require "footer.php";
?> 
</body>
</html> 
