<?php
require "../db.php";
if(isset($_POST['submit_fy'])){//to run PHP script on submit
if(!empty($_POST['check_list'])){
// Loop to store and display values of individual checked checkbox.
foreach($_POST['check_list'] as $selected){
//echo $selected."</br>";
$query = "update studentlist set class='SY' where ucid='$selected'";
    mysqli_query($con, $query);
}
}
$query1 = "update studentlist set fladkt='yes' where class='FY'";
    mysqli_query($con, $query1);
}
Header('Location: adminpromote.php');
?>

<?php
require "../db.php";
if(isset($_POST['submit_sy'])){//to run PHP script on submit
if(!empty($_POST['check_list'])){
// Loop to store and display values of individual checked checkbox.
foreach($_POST['check_list'] as $selected){
//echo $selected."</br>";
$query = "update studentlist set class='TY' where ucid='$selected'";
    mysqli_query($con, $query);
}
}
$query1 = "update studentlist set fladkt='yes' where class='SY'";
    mysqli_query($con, $query1);
}
Header('Location: adminpromote.php');
?>

<?php
require "../db.php";
if(isset($_POST['submit_ty'])){//to run PHP script on submit
if(!empty($_POST['check_list'])){
// Loop to store and display values of individual checked checkbox.
foreach($_POST['check_list'] as $selected){
//echo $selected."</br>";
$query = "update studentlist set class='PASSED' where ucid='$selected'";
    mysqli_query($con, $query);
}
}
$query1 = "update studentlist set fladkt='yes' where class='TY'";
    mysqli_query($con, $query1);
}
Header('Location: adminpromote.php');
?>