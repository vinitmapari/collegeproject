<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "header.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
</head>
<body>

<?php
require "adminmenu.php";
require "adminsidenav.php";
?>
  <div class="container">
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title">Add Students</h1>
					</div>

  <div class="panel-body">
  
<form class="form-horizontal" method="post" action="../excelupload.php" enctype="multipart/form-data">
<br>
<div class="form-group">
  <label class="col-md-4 control-label" for="subcode">Year</label>  
  <div class="col-md-4">
  <input id="yr" name="yr" type="text" placeholder="" class="form-control input-md" required="">
  </div>
</div>
<label class="col-md-4 control-label" for="file-button-browse">Upload details</label>
<div class="input-group">
    <span class="input-group-btn">
		<button id="file-button-browse" type="button" class="btn btn-default">
			<span class="glyphicon glyphicon-file"></span>
		</button>
	</span>
	<input type="file" id="files-input-upload" name="excel" style="display:none">
	<input type="text" id="file-input-name" name="file-input-name" disabled="disabled" placeholder="File not selected" class="form-control">
	<span class="input-group-btn">
            <button type="submit" class="btn btn-default" name="import" disabled="disabled" id="file-button-upload">
			<span class="glyphicon glyphicon-upload"></span>
		</button>
	</span>
	<br>
</div>

<br>
</form>
  
  </div>
</div><br><br>
</div>
<script type="text/javascript">
// student list file upload
document.getElementById('file-button-browse').addEventListener('click', function() {
	document.getElementById('files-input-upload').click();
});

document.getElementById('files-input-upload').addEventListener('change', function() {
	document.getElementById('file-input-name').value = this.files[0].name;
	
	document.getElementById('file-button-upload').removeAttribute('disabled');
});

</script>
						
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>

 
</body>
<?php
require "footer.php";
?>
</html> 
