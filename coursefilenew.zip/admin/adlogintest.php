<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "header.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
<title>Admin Login</title>
</head>
<body>
		<?php
require "adminlogmenu.php";
?>
  <div class="container"><br>
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title">Admin Login</h1>
					</div>

  <div class="panel-body">
					<form class="form-horizontal" method="post" action="adlogintest_action.php">
<br>
						<div class="form-group">
  <label class="col-md-4 control-label" for="email">Email</label>  
  <div class="col-md-4">
									<input type="text" class="form-control" name="email" id="email"  placeholder="Enter your email id"/>
								</div>
							</div>

<div class="form-group">
  <label class="col-md-4 control-label" for="password">Password</label>  
  <div class="col-md-4">
									<input type="password" class="form-control" name="password" id="password"  placeholder="Enter your Password"/>
								</div>
							</div>
						

						<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit" name="submit" value="Submit" class="btn btn-default">Login</button>
						</div>
						</div>
						<!-- <div class="login-register">
				            <a href="index.php">Login</a>
				         </div> -->
						 
					</form>
</div>
</div><br><br>
</div>

		<script type="text/javascript" src="assets/js/bootstrap.js"></script>
		<?php
require "footer.php";
?> 
	</body>
</html>