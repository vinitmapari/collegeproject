<?php
$mysqli_host="localhost";
	$mysqli_user="root";
	$mysqli_pass="";
	$mysqli_db="test2";
	$con=mysqli_connect($mysqli_host,$mysqli_user,$mysqli_pass);
	mysqli_select_db($con,$mysqli_db);
if(isset($_POST['submit_fy'])){//to run PHP script on submit
if(!empty($_POST['check_list'])){
// Loop to store and display values of individual checked checkbox.
foreach($_POST['check_list'] as $selected){
//echo $selected."</br>";
$query = "update student set class='SY' where ucid='$selected'";
    mysqli_query($con, $query);
}
}
}
Header('Location: adminpromote.php');
?>