<?php
session_start();
$user=$_SESSION['adminid'];
require "../db.php";
	if(isset($_POST['branch'])&& isset($_POST['classsel'])&& isset($_POST['semester'])&& isset($_POST['subcode'])&& isset($_POST['subname']))
{
	$branch=$_POST['branch'];
$class=$_POST['classsel'];
$sem=$_POST['semester'];
$subcode=$_POST['subcode'];
$sub=$_POST['subname'];
//echo $branch." ".$class." ".$sem." ".$subcode." ".$sub." ".$user;
$query="insert into subject(subjectname, semester, branch, adminid, subjectcode) values('".$sub."','".$sem."','".$branch."','".$user."','".$subcode."')";
mysqli_query($con,$query);
//Header('location:adminaddsub.php');
}
else
{
	echo "Could not update";
}
Header('location:adminaddsub.php');
?>