<?php
session_start();
require "../db.php";

if(isset($_POST['email'])&& isset($_POST['password'])){
	$email=$_POST['email'];
	$password=$_POST['password'];
	
if(!empty($email) && !empty($password)){
		$sql="select adminemail from admin where adminemail='".$email."' and password='$password' limit 1";
		if($query=mysqli_query($con,$sql)){
			$query_run=mysqli_num_rows($query);
			if($query_run==0)
			{
				echo "<script>alert('Invalid Email or Password')</script>";				
			}
		elseif($query_run==1)
		{
			$sql1="select * from admin where adminemail='".$email."' and password='$password' limit 1";
			if($query1=mysqli_query($con,$sql1)){
			while($row = mysqli_fetch_assoc($query1)) {
				$adminid=$row['Id'];
				$user_id = $row['adminfirstname'];
			}
				
			}
				//echo $user_id=mysql_result($query,0,'id');
				$_SESSION['user_id']=$user_id;//setting up session variables.
				$_SESSION['adminid']=$adminid;
				Header('Location: adminalotteach.php');
		}
	}
}
	else
	{
		echo 'please supply email id and password.';
	}
}
?>