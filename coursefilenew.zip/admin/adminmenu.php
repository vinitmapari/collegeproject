<div class="clearfix" style="background-image: url(blurteach.jpg);background-size:100% 100%;background-repeat:no-repeat;height:90px;" id='header'>
<img src="../image/spitlogo.png" alt="SPIT College" width="100" height="80" style="margin-left:100px;float:left"><label style="float:left;color:black"><h1> S.P.I.T. College</h1></label>
&nbsp;&nbsp;&nbsp;<a href="../logout.php"><button type="button" id="submit-btn" class="btn btn-default" align="right" style="float:right">Logout</button></a>
</div>
<?php
		$user=$_SESSION['user_id'];
		echo "<p style='color:white;float:right;margin-right:50px;margin-top:18px'>".$user;?>
<nav>
    <div class="toggle">
        <i class="fa fa-bars menu" aria-hidden="true"></i>
    </div>
    <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
    </ul>
</nav>