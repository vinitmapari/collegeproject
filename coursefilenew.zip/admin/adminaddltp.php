<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "header.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
</head>
<body>
<?php
require "adminmenu.php";
require "adminsidenav.php";
?>
  <div class="container">
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title">Add Subject Details</h1>
					</div>

  <div class="panel-body">
  
<form class="form-horizontal" method="post" action="adminaddltp_action.php">
						<br>
<div class="form-group">
  <label class="col-md-4 control-label" for="yr">Year</label>  
  <div class="col-md-4">
  <input id="yr" name="yr" type="text" placeholder="" class="form-control input-md" required="">
  </div>
</div>
<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="classsel">Class</label>
  <div class="col-md-4">
    <select id="classsel" name="classsel" class="form-control" style="height:35px">
      <option value="FY">FY</option>
      <option value="SY">SY</option>
      <option value="TY">TY</option>
    </select>
  </div>
</div>
  <!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="semester">Semester</label>
  <div class="col-md-4">
    <select id="semester" name="semester" class="form-control" style="height:35px">
      <option value="1">1</option>
      <option value="2">2</option>
      <option value="3">3</option>
      <option value="4">4</option>
      <option value="5">5</option>
      <option value="6">6</option>
    </select>
  </div>
</div>
<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="subsel">Subject Name</label>
  <div class="col-md-4">
    <select id="subsel" name="subsel" class="form-control" style="height:35px">
	<?php
	require "../db.php";
    $query = "select * from subject";
    $results = mysqli_query($con,$query);

    while ($rows = mysqli_fetch_assoc(@$results)){ 
    ?>
      <option value="<?php echo $rows['idsubject'];?>"><?php echo $rows['subjectname'];?></option>
	  <?php
    } 
    ?>
    </select>
  </div>
</div>

  <div class="form-group">
  <label class="col-md-4 control-label" for="credit">Credit</label>  
  <div class="col-md-4">
  <input id="credit" name="credit" type="text" placeholder="" class="form-control input-md" required="">
  </div>
</div>
  <div class="form-group">
  <label class="col-md-4 control-label" for="session">Session</label>  
  <div class="col-md-4">
  <input id="session" name="session" type="text" placeholder="" class="form-control input-md" required="">
  </div>
</div>
  
  <!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="lecture">Lecture</label>  
  <div class="col-md-4">
  <input id="lecture" name="lecture" type="text" placeholder="" class="form-control input-md" required="">
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="tutorial">Tutorial</label>  
  <div class="col-md-4">
  <input id="tutorial" name="tutorial" type="text" placeholder="" class="form-control input-md" required="">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="practical">Practical</label>  
  <div class="col-md-4">
  <input id="practical" name="practical" type="text" placeholder="" class="form-control input-md" required="">
    
  </div>
</div>
  <br>
  
  <!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submit2" name="submit" class="btn btn-default">Submit</button>
  </div>
</div><br>
  
  </form>
  
  </div>
</div><br><br>
</div>
						
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>

<?php
require "footer.php";
?>
</body>
</html> 
