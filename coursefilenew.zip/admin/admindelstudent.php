<?php
session_start();
//$user=$_SESSION['user_id'];
//echo $user;
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
require "header.php";
?>
<script>
$(document).ready(function() {
    $('.menu').click(function() {
        $('ul').toggleClass('active');
    });
});
</script>
</head>
<body>

<?php
require "adminmenu.php";
require "adminsidenav.php";
?>
  <div class="container">
<div class="panel panel-default">
                <div class="panel-heading">
                    <h1 class="panel-title">Delete Students</h1>
					</div>

  <div class="panel-body">
  
<form class="form-horizontal" onsubmit="return submitForm(this);" method="post" action="admindelstudent_action.php">
<br>
<div class="form-group">
  <label class="col-md-4 control-label" for="delucid">UCID</label>  
  <div class="col-md-4">
  <input id="delucid" name="delucid" type="text" placeholder="" class="form-control input-md">
  </div>
</div>
<div class="form-group">
  <label class="col-md-4 control-label" for="submit"></label>
  <div class="col-md-4">
    <button id="submitdel" name="submitdel" class="btn btn-default">Delete</button>
  </div>
</div><br>

</form>

</div>
</div><br><br>
</div>		
<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
}
</script>
<script>
function submitForm() {
  return confirm('Do you really want to submit the form?');
}
</script>
<?php
require "footer.php";
?>
</body>
</html> 
