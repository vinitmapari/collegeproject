<?php
session_start();
$user=$_SESSION['adminid'];
require "../db.php";
if(isset($_POST['yr'])&& 
isset($_POST['credit']) && 
isset($_POST['session'])&& 
isset($_POST['lecture'])&& 
isset($_POST['tutorial'])&& 
isset($_POST['practical']) && 
isset($_POST['classsel'])&& isset($_POST['subsel'])&& isset($_POST['semester']))
{
$yr=$_POST['yr'];
$class=$_POST['classsel'];
$session=$_POST['session'];
$subcode=$_POST['subsel'];
$lec=$_POST['lecture'];
$tut=$_POST['tutorial'];
$prac=$_POST['practical'];
$cred=$_POST['credit'];
$sem=$_POST['semester'];
$query="insert into cognitive values('','".$subcode."','".$user."','".$cred."','".$session."','".$lec."','".$tut."','".$prac."','".$class."','".$yr."','".$sem."')";
mysqli_query($con,$query);
}
else
{
	echo "Could not update";
}
Header('location:adminaddltp.php');
?>