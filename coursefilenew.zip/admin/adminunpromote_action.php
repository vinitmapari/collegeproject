<?php
require "../db.php";
if(isset($_POST['submit_unpromoted'])){//to run PHP script on submit
if(!empty($_POST['check_list'])){
// Loop to store and display values of individual checked checkbox.
foreach($_POST['check_list'] as $selected){
$query = "select * from studentlist where ucid='$selected'";
    $sql=mysqli_query($con, $query);
	$cla = mysqli_fetch_array($sql);
	$row = $cla['class'];
	if($row=="FY")
	{
		$cl="SY";
	}
	else if($row=="SY")
	{
		$cl="TY";
	}
	else
	{
		$cl="PASSED";
	}
	$query1 = "update studentlist set class='$cl', fladkt='no' where ucid='$selected'";
	mysqli_query($con, $query1);
}
}
}
Header('Location: adminunpromote.php');
?>