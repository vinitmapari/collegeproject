<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="adminalotteach.php">Alot Teacher</a>
  <a href="adminaddsub.php">Add Subjects</a>
  <a href="adminaddltp.php">Add Subject Details</a>
  <a href="adminaddstudent.php">Upload Student Details</a>
  <a href="admindelstudent.php">Delete Student Details</a>
  <a href="adminpromote.php">Promote Students</a>
  <a href="adminunpromote.php">View Unpromoted Students</a>
  <a href="adminstudupdate.php">Update Student Details</a>
</div>

<div id="main">
  <span style="font-size:20px;cursor:pointer" onclick="openNav()">&#9776;</span>