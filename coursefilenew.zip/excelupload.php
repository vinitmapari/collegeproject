<?php
    session_start();
    $adminid=$_SESSION['adminid'];
   $con = mysqli_connect("localhost:3306","root","","mcadatabase");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
	
        $uname=$_SESSION['user_id'];
	 $yr=$_POST['yr'];
         echo $uname;
         echo $yr;

if(isset($_POST["import"]))
{
 $extension = end(explode(".", $_FILES["excel"]["name"])); // For getting Extension of selected file
 $allowed_extension = array("xls", "xlsx", "csv"); //allowed extension
 
 if(in_array($extension, $allowed_extension)) //check selected file extension is present in allowed extension array
 {

  $file = $_FILES["excel"]["tmp_name"]; // getting temporary source of excel file
  include("PHPExcel/IOFactory.php"); // Add PHPExcel Library in this code
  $objPHPExcel = PHPExcel_IOFactory::load($file); // create object of PHPExcel library by using load() method and in load method define path of selected file

 
  
  foreach ($objPHPExcel->getWorksheetIterator() as $worksheet)
  {
   $highestRow = $worksheet->getHighestRow();
   for($row=2; $row<=$highestRow; $row++)
   {
   
    $roll = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(0, $row)->getValue());
    $name = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(1, $row)->getValue());
    $class = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(2, $row)->getValue());
   
    echo $roll;
    echo $name;
    echo $class;
    
    $query = "insert into studentlist(ucid,studentname,fladkt,class,year,adminid) values ($roll,'$name','no','$class','$yr',$adminid)";
    mysqli_query($con, $query);
  
   }
  } 
            
   echo "inserted";
  Header('Location: adminaddstudent.php');
 }
 else
 {
  echo "not inserted";
 }
}
?>
