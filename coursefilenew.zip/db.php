<?php
$mysqli_host="localhost:3308";
	$mysqli_user="root";
	$mysqli_pass="";
	$mysqli_db="mcadatabase";
	$con=mysqli_connect($mysqli_host,$mysqli_user,$mysqli_pass);
	mysqli_select_db($con,$mysqli_db);
?>