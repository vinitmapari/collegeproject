<?php
echo substr(sprintf('%o', fileperms('Upload/')), -4);
echo " ";
echo substr(sprintf('%o', fileperms('Upload/teach1')), -4);
echo " ";
echo substr(sprintf('%o', fileperms('Upload/teach1/FY')), -4);
?>