
<?php
        session_start();
	$con = mysqli_connect("localhost:3306","root","","mcadatabase");
// Check connection
if (mysqli_connect_errno())
  {
  mysqli_connect_error();
  }
	
        $class=$_SESSION['class'];
        $subject=$_SESSION['subject'];
        $year=$_SESSION['year'];
        $semester=$_SESSION['semester'];
        $attainment=$_SESSION['quizno'];
        $tid=$_SESSION['tid'];
	$co=$_SESSION['co'];   
        
        
if(isset($_POST["import"]))
{
 $extension = end(explode(".", $_FILES["excel"]["name"])); // For getting Extension of selected file
 $allowed_extension = array("xls", "xlsx", "csv"); //allowed extension
 
 if(in_array($extension, $allowed_extension)) //check selected file extension is present in allowed extension array
 {

  $file = $_FILES["excel"]["tmp_name"]; // getting temporary source of excel file
  include("PHPExcel/IOFactory.php"); // Add PHPExcel Library in this code
  $objPHPExcel = PHPExcel_IOFactory::load($file); // create object of PHPExcel library by using load() method and in load method define path of selected file

 $sql1="select * from quiz where class='$class' and subject='$subject' and year='$year' and semester='$semester' and tid='$tid' ";
     $result=mysqli_query($con, $sql1);
     while($row = mysqli_fetch_assoc($result)) {
				$quizid = $row['idquiz'];
		}
                  
                        
   $sql3="select * from quizmarks where quizid='$quizid' ";
     $result2=mysqli_query($con, $sql3);
     $num=mysqli_num_rows($result2);
    
     
  foreach ($objPHPExcel->getWorksheetIterator() as $worksheet)
  {
   $highestRow = $worksheet->getHighestRow();
   for($row=2; $row<=$highestRow; $row++)
   {
   
    $UID = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(0, $row)->getValue());
    $name = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(1, $row)->getValue());
    $quiz1 = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(2, $row)->getValue());
    $quiz2= mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(3, $row)->getValue());
    $quiz3 = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(4, $row)->getValue());
    $quiz4 = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(5, $row)->getValue());
    
 
    
      if($num==0)
    {
         
        $query = "Insert into quizmarks (ucid,studentname,quiz1,quiz2,quiz3,quiz4,quizid)values($UID,'$name',$quiz1,$quiz2,$quiz3,$quiz4,$quizid)";
    mysqli_query($con, $query);
          
    }
 else {
   
    $query = "update quizmarks set quiz1=$quiz1,quiz2=$quiz2,quiz3=$quiz3,quiz4=$quiz4 where quizid=$quizid and ucid=$UID and studentname='$name'";
    mysqli_query($con, $query);
    }
    
   }
  } 
            
  $output = '<label class="text-danger">Data inserted successfully</label>'; 
  $file = $subject.$semester.$attainment.$class.$year.$co.".".$extension;
   //echo $file;
   $UploadTmp = $_FILES['excel']['tmp_name'];
    //$sql = "INSERT INTO file (filename) VALUES ('$file')"; 
    //mysqli_query($con, $sql);
		$user=$_SESSION['user_id'];
   move_uploaded_file($UploadTmp,"Upload/$user/$file");
   $output = '<label class="text-danger">File Uploaded</label>'; 
    //echo "inserted";
  //Header('Location: admin/adminaddstudent.php');
 }
 else
 {
  $output = '<label class="text-danger">Invalid File</label>';
 }
}
?>
    <label><?Php $output ?></label>   
 